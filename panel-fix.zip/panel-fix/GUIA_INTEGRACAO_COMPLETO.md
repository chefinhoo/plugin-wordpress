# 🔧 GUIA COMPLETO DE INTEGRAÇÃO - PÁGINAS CUSTOMIZADAS

## 📌 Visão Geral

Este guia mostra como integrar os 11 templates de página customizados ao seu plugin principal `panel-administrativo.php`.

**Arquivos a integrar:**
- ✅ 1 Classe (`class-admin-pages.php`)
- ✅ 13 Templates de página (`includes/pages/*.php`)
- ✅ 3 Arquivos CSS (`assets/css/pages/*.css`)

---

## 📂 Estrutura de Diretórios

Certifique-se que sua estrutura seja assim:

```
wp-content/plugins/panel-administrativo/
├── panel-administrativo.php          (plugin principal)
├── readme.txt
├── assets/
│   ├── css/
│   │   ├── admin-style.css           (global)
│   │   └── pages/
│   │       ├── admin-pages.css       (genérico para todas)
│   │       ├── config-geral.css
│   │       └── person-cores.css
│   └── js/
│       ├── admin-script.js           (global)
│       └── pages/
│           └── (JavaScript específico)
├── includes/
│   ├── class-admin-pages.php         ⭐ NOVO
│   └── pages/                        ⭐ NOVO
│       ├── config-geral.php
│       ├── config-streaming.php
│       ├── config-avancado.php
│       ├── config-utilidades.php
│       ├── config-privacidade.php
│       ├── person-cores.php
│       ├── person-home.php
│       ├── person-modulos.php
│       ├── person-slider.php
│       ├── person-internas.php
│       ├── person-widgets.php
│       ├── person-menus.php
│       └── person-redes.php
└── docs/
    ├── README.md
    ├── GUIA_IMPLEMENTACAO.md
    └── EXEMPLOS_SEGURANCA.md
```

---

## 🚀 Passo-a-Passo de Integração

### PASSO 1: Copiar Arquivos

1. Copie a pasta `includes/` para seu plugin
2. Copie os arquivos CSS da pasta `assets/css/pages/`
3. Estruture como acima

### PASSO 2: Atualizar `panel-administrativo.php`

No seu arquivo principal, procure pela seção de **callbacks de menu** e faça as seguintes alterações:

#### **Antes (atual):**

```php
add_submenu_page( 'config-gerais-custom', 'Configurações', 'Configurações', 'manage_options', 'config-geral', '__return_false' );
```

#### **Depois (novo):**

```php
add_submenu_page( 
    'config-gerais-custom', 
    'Configurações', 
    'Configurações', 
    'manage_options', 
    'config-geral', 
    function() { 
        global $hoost_admin_pages;
        $hoost_admin_pages->render_page( 'config-geral' );
    }
);
```

### PASSO 3: Carregar a Classe

No **topo do arquivo `panel-administrativo.php`** (após os hooks iniciais), adicione:

```php
// ═══════════════════════════════════════════════════════════════════════
// Carregar classe de gerenciamento de páginas administrativas
// ═══════════════════════════════════════════════════════════════════════

require_once HOOST_PLUGIN_PATH . 'includes/class-admin-pages.php';

global $hoost_admin_pages;
$hoost_admin_pages = new HOOST_Admin_Pages( HOOST_PLUGIN_PATH, HOOST_PLUGIN_URL );
```

### PASSO 4: Enfileirar CSS Global

No hook `admin_enqueue_scripts`, adicione:

```php
// Enfileirar CSS genérico de páginas
wp_enqueue_style( 'hoost-pages-css', HOOST_PLUGIN_URL . 'assets/css/pages/admin-pages.css', [], HOOST_PLUGIN_VERSION );
```

---

## 📋 Mapeamento Completo de Callbacks

Aqui está o **mapeamento completo** de todas as páginas que precisam ser atualizadas:

### **CONFIGURAÇÕES GERAIS**

```php
// Configurações Gerais
add_submenu_page( 'config-gerais-custom', 'Configurações', 'Configurações', 'manage_options', 'config-geral', function() { global $hoost_admin_pages; $hoost_admin_pages->render_page( 'config-geral' ); } );

// Streaming e Player
add_submenu_page( 'config-gerais-custom', 'Streaming e player', 'Streaming e player', 'manage_options', 'config-streaming', function() { global $hoost_admin_pages; $hoost_admin_pages->render_page( 'config-streaming' ); } );

// Avançado
add_submenu_page( 'config-gerais-custom', 'Avançado', 'Avançado', 'manage_options', 'config-avancado', function() { global $hoost_admin_pages; $hoost_admin_pages->render_page( 'config-avancado' ); } );

// Utilidades
add_submenu_page( 'config-gerais-custom', 'Utilidades', 'Utilidades', 'manage_options', 'config-utilidades', function() { global $hoost_admin_pages; $hoost_admin_pages->render_page( 'config-utilidades' ); } );

// Privacidade
add_submenu_page( 'config-gerais-custom', 'Privacidade', 'Privacidade', 'manage_options', 'config-privacidade', function() { global $hoost_admin_pages; $hoost_admin_pages->render_page( 'config-privacidade' ); } );
```

### **PERSONALIZAÇÃO**

```php
// Cores e Estilos
add_submenu_page( 'personalizacao-custom', 'Cores e estilos', 'Cores e estilos', 'manage_options', 'person-cores', function() { global $hoost_admin_pages; $hoost_admin_pages->render_page( 'person-cores' ); } );

// Página Inicial
add_submenu_page( 'personalizacao-custom', 'Página Inicial', 'Página Inicial', 'manage_options', 'person-home', function() { global $hoost_admin_pages; $hoost_admin_pages->render_page( 'person-home' ); } );

// Módulos
add_submenu_page( 'personalizacao-custom', 'Página inicial: Módulos', 'Página inicial: Módulos', 'manage_options', 'person-modulos', function() { global $hoost_admin_pages; $hoost_admin_pages->render_page( 'person-modulos' ); } );

// Slider
add_submenu_page( 'personalizacao-custom', 'Página inicial: Slider', 'Página inicial: Slider', 'manage_options', 'person-slider', function() { global $hoost_admin_pages; $hoost_admin_pages->render_page( 'person-slider' ); } );

// Páginas Internas
add_submenu_page( 'personalizacao-custom', 'Páginas Internas', 'Páginas Internas', 'manage_options', 'person-internas', function() { global $hoost_admin_pages; $hoost_admin_pages->render_page( 'person-internas' ); } );

// Widgets
add_submenu_page( 'personalizacao-custom', 'Widgets', 'Widgets', 'manage_options', 'person-widgets', function() { global $hoost_admin_pages; $hoost_admin_pages->render_page( 'person-widgets' ); } );

// Menus
add_submenu_page( 'personalizacao-custom', 'Menus', 'Menus', 'manage_options', 'person-menus', function() { global $hoost_admin_pages; $hoost_admin_pages->render_page( 'person-menus' ); } );

// Redes Sociais
add_submenu_page( 'personalizacao-custom', 'Redes Sociais', 'Redes Sociais', 'manage_options', 'person-redes', function() { global $hoost_admin_pages; $hoost_admin_pages->render_page( 'person-redes' ); } );
```

---

## 🔍 Exemplo Prático Completo

### Antes (arquivo atual):

```php
add_menu_page( 'Configurações gerais', 'Configurações gerais', 'manage_options', 'config-gerais-custom', '__return_false', 'dashicons-admin-generic', 50 );
add_submenu_page( 'config-gerais-custom', 'Streaming e player', 'Streaming e player', 'manage_options', 'config-streaming', '__return_false' );
add_submenu_page( 'config-gerais-custom', 'Configurações', 'Configurações', 'manage_options', 'config-geral', '__return_false' );
```

### Depois (novo com callbacks reais):

```php
add_menu_page( 'Configurações gerais', 'Configurações gerais', 'manage_options', 'config-gerais-custom', '__return_false', 'dashicons-admin-generic', 50 );

add_submenu_page( 
    'config-gerais-custom', 
    'Streaming e player', 
    'Streaming e player', 
    'manage_options', 
    'config-streaming', 
    function() { 
        global $hoost_admin_pages;
        $hoost_admin_pages->render_page( 'config-streaming' );
    }
);

add_submenu_page( 
    'config-gerais-custom', 
    'Configurações', 
    'Configurações', 
    'manage_options', 
    'config-geral', 
    function() { 
        global $hoost_admin_pages;
        $hoost_admin_pages->render_page( 'config-geral' );
    }
);
```

---

## 📊 Checklist de Integração

- [ ] Copiei todos os arquivos da pasta `includes/`
- [ ] Copiei todos os arquivos CSS de `assets/css/pages/`
- [ ] Carreguei a classe `HOOST_Admin_Pages` no arquivo principal
- [ ] Atualizei todos os callbacks das páginas (13 submenu_pages)
- [ ] Enfileirei o CSS global `admin-pages.css`
- [ ] Testei cada página para verificar se renderiza
- [ ] Testei responsividade (mobile, tablet, desktop)
- [ ] Verifiquei se não há erros no console/debug.log

---

## 🧪 Como Testar

### 1. **Verificar se Página Carrega**

Acesse cada página via menu e verifique:
- ✅ Página carrega sem erros
- ✅ Formulários aparecem corretamente
- ✅ CSS está aplicado
- ✅ Sem mensagens de erro no debug.log

### 2. **Testar Formulários**

```php
// Em config-geral.php, por exemplo:
if ( isset( $_POST['hoost_config_nonce'] ) ) {
    // Verificar nonce
    // Sanitizar dados
    // Salvar com update_option()
}
```

### 3. **Console do Navegador** (F12)

Procure por:
- ❌ Erros de JavaScript
- ❌ Erros de CSS (404)
- ❌ Avisos de segurança (CORS, CSP)

---

## 🔧 Troubleshooting

### **Problema: "Página não encontrada"**

**Solução:** Verifique se o arquivo existe em `includes/pages/[page-slug].php`

```php
// Dentro de render_page():
if ( ! file_exists( $template_file ) ) {
    wp_die( 'Arquivo não encontrado: ' . $template_file );
}
```

### **Problema: "Erro 403 - Acesso Negado"**

**Solução:** Verifique se está usando `current_user_can( 'manage_options' )`

```php
if ( ! current_user_can( 'manage_options' ) ) {
    wp_die( 'Acesso negado.' );
}
```

### **Problema: CSS não está carregando**

**Solução:** Verifique se enfileirou corretamente no hook `admin_enqueue_scripts`

```php
wp_enqueue_style( 'hoost-pages-css', HOOST_PLUGIN_URL . 'assets/css/pages/admin-pages.css', [], HOOST_PLUGIN_VERSION );
```

### **Problema: Dados não salvam**

**Solução:** Verifique se tem nonce e está fazendo `update_option()`

```php
if ( isset( $_POST['hoost_config_nonce'] ) ) {
    if ( ! wp_verify_nonce( ... ) ) wp_die( 'Nonce falhou' );
    update_option( 'hoost_titulo_site', $valor );
}
```

---

## 📈 Próximas Melhorias (Opcional)

1. **Criar JavaScript específico** para cada página
2. **Adicionar validação cliente** (JavaScript)
3. **Criar AJAX handlers** para salvar sem reload
4. **Adicionar animações** com CSS/JS
5. **Criar sistema de tema** (light/dark mode)

---

## 📞 Suporte

Se tiver dúvidas:

1. Verifique o código da classe `HOOST_Admin_Pages`
2. Consulte exemplos em `config-geral.php` ou `person-cores.php`
3. Veja documentação WordPress: https://developer.wordpress.org/plugins/

---

**Status:** ✅ **PRONTO PARA INTEGRAÇÃO**

Siga este guia passo-a-passo e todas as páginas funcionarão perfeitamente!

