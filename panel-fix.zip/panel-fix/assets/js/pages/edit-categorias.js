/**
 * Hoost Admin — Categorias de Notícias / Blog
 * Baseado no HTML de referência (documento 4)
 * Injeta: header, barra de busca/bulk, layout dois colunas, rodapé
 */
(function () {
    'use strict';

    document.addEventListener('DOMContentLoaded', function () {

        // Detecta se estamos na página de taxonomias (edit-tags.php)
        var body = document.body;
        var isCatNoticias = body.classList.contains('edit-tags-php') &&
            (body.classList.contains('post-type-noticias') || body.classList.contains('taxonomy-noticia') ||
             body.classList.contains('taxonomy-categoria_noticias'));
        var isCatBlog = body.classList.contains('edit-tags-php') &&
            (body.classList.contains('post-type-blog') || body.classList.contains('taxonomy-categoria_blog'));

        if (!isCatNoticias && !isCatBlog) return;

        var wrap = document.querySelector('.wrap');
        if (!wrap) return;

        // ── COLETAR ELEMENTOS NATIVOS ──────────────────────────────────────

        var wpH1         = wrap.querySelector('h1.wp-heading-inline');
        var wpAddForm    = wrap.querySelector('#addtag');              // form nativo de adicionar
        var wpListForm   = wrap.querySelector('#posts-filter');        // form nativo da tabela
        var wpBulkSel    = wrap.querySelector('#bulk-action-selector-top');
        var wpSearchInp  = wrap.querySelector('#tag-search-input, input[name="s"]');
        var wpDispNum    = wrap.querySelector('.displaying-num');
        var wpTable      = wrap.querySelector('.wp-list-table');

        if (!wpTable) return;

        // Título
        var titleText = wpH1 ? wpH1.textContent.trim() : 'Categorias';

        // Contagem de itens
        var itemCountText = '';
        if (wpDispNum) {
            itemCountText = wpDispNum.textContent.trim();
        } else {
            var rowCount = wpTable.querySelectorAll('tbody tr:not(.no-items)').length;
            itemCountText = rowCount + ' ' + (rowCount === 1 ? 'item' : 'itens');
        }

        // Clonar bulk select
        var bulkSelClone = null;
        if (wpBulkSel) {
            bulkSelClone = wpBulkSel.cloneNode(true);
            bulkSelClone.id = 'hoost-cat-bulk-select';
        }

        // ── CONSTRUÇÃO DO DOM ──────────────────────────────────────────────

        // 1. HEADER
        var header = el('div', 'hoost-page-header');
        var h1 = el('h1');
        h1.textContent = titleText;
        header.appendChild(h1);

        // 2. COL-CONTAINER
        var colContainer = el('div', 'hoost-col-container');

        // COL ESQUERDA: formulário de adicionar
        var colLeft = el('div', 'hoost-col-left');
        var formCard = el('div', 'hoost-form-card');
        var cardTitle = el('h2');
        cardTitle.textContent = 'Adicionar nova categoria';
        formCard.appendChild(cardTitle);

        if (wpAddForm) {
            // Mover o form nativo para dentro do card
            formCard.appendChild(wpAddForm);
        }

        colLeft.appendChild(formCard);

        // COL DIREITA: barra de busca + tabela
        var colRight = el('div', 'hoost-col-right');

        // Barra topo (bulk + pesquisa)
        var filterBar = el('div', 'hoost-cat-filter-bar');

        // Bulk lado esquerdo
        var filterLeft = el('div', 'hoost-cat-filter-left');
        var bulkSel;
        if (bulkSelClone) {
            bulkSel = bulkSelClone;
            filterLeft.appendChild(bulkSel);
        } else {
            bulkSel = el('select');
            bulkSel.innerHTML = '<option>Ações em massa</option><option value="delete">Excluir</option>';
            filterLeft.appendChild(bulkSel);
        }
        var applyTopBtn = el('button', 'hoost-cat-apply-btn');
        applyTopBtn.type = 'button';
        applyTopBtn.textContent = 'Aplicar';
        applyTopBtn.addEventListener('click', function () {
            var orig = document.getElementById('bulk-action-selector-top');
            if (orig && bulkSel) orig.value = bulkSel.value;
            var doBtn = document.getElementById('doaction');
            if (doBtn) doBtn.click();
        });
        filterLeft.appendChild(applyTopBtn);

        // Pesquisa lado direito
        var searchWrap = el('div', 'hoost-cat-search-wrap');
        var searchInp = el('input', 'hoost-cat-search-input');
        searchInp.type = 'search';
        searchInp.placeholder = 'Pesquisar categorias...';
        if (wpSearchInp && wpSearchInp.value) searchInp.value = wpSearchInp.value;

        var searchBtn = el('button', 'hoost-cat-search-btn');
        searchBtn.type = 'button';
        searchBtn.textContent = 'Pesquisar';
        searchBtn.addEventListener('click', function () { doSearch(searchInp.value); });
        searchInp.addEventListener('keydown', function (e) {
            if (e.key === 'Enter') { e.preventDefault(); doSearch(searchInp.value); }
        });

        searchWrap.appendChild(searchInp);
        searchWrap.appendChild(searchBtn);

        filterBar.appendChild(filterLeft);
        filterBar.appendChild(searchWrap);

        // Tabela (mover form nativo para cá)
        if (wpListForm) {
            colRight.appendChild(filterBar);
            colRight.appendChild(wpListForm);
        } else if (wpTable) {
            colRight.appendChild(filterBar);
            colRight.appendChild(wpTable.closest('form') || wpTable);
        }

        // RODAPÉ
        var footer = el('div', 'hoost-cat-footer');
        var bulkWrapFoot = el('div', 'hoost-cat-bulk-wrap');

        var bulkSelFoot = el('select');
        bulkSelFoot.innerHTML = bulkSel ? bulkSel.innerHTML : '<option>Ações em massa</option><option value="delete">Excluir</option>';

        var applyFootBtn = el('button', 'hoost-cat-apply-footer-btn');
        applyFootBtn.type = 'button';
        applyFootBtn.textContent = 'Aplicar';
        applyFootBtn.addEventListener('click', function () {
            var orig = document.getElementById('bulk-action-selector-top');
            if (orig) orig.value = bulkSelFoot.value;
            var doBtn = document.getElementById('doaction');
            if (doBtn) doBtn.click();
        });

        bulkWrapFoot.appendChild(bulkSelFoot);
        bulkWrapFoot.appendChild(applyFootBtn);

        var itemCountSpan = el('span', 'hoost-cat-item-count');
        itemCountSpan.textContent = itemCountText;

        footer.appendChild(bulkWrapFoot);
        footer.appendChild(itemCountSpan);

        colRight.appendChild(footer);

        // Montar col-container
        colContainer.appendChild(colLeft);
        colContainer.appendChild(colRight);

        // ── INSERIR NO DOM ─────────────────────────────────────────────────
        // Limpar o wrap e reinserir apenas o que queremos
        // (os elementos nativos já foram movidos para dentro dos novos containers)
        wrap.appendChild(header);
        wrap.appendChild(colContainer);

        // Ocultar o título nativo (h1) que ficou no wrap
        if (wpH1 && wpH1.parentNode === wrap) {
            wpH1.style.display = 'none';
        }
        // Ocultar o hr nativo
        var hr = wrap.querySelector('hr.wp-header-end');
        if (hr) hr.style.display = 'none';

        // Ocultar formulário de busca nativo (substituído pelo nosso)
        var wpSearchForm = wrap.querySelector('.search-form.wp-clearfix, form.search-form');
        if (wpSearchForm && !wpSearchForm.id.includes('addtag') && !wpSearchForm.id.includes('posts-filter')) {
            wpSearchForm.style.display = 'none';
        }

        // Ocultar o #ajax-response
        var ajaxResp = wrap.querySelector('#ajax-response');
        if (ajaxResp) ajaxResp.style.display = 'none';

        // ── HELPERS ────────────────────────────────────────────────────────

        function el(tag, cls) {
            var e = document.createElement(tag);
            if (cls) e.className = cls;
            return e;
        }

        function doSearch(val) {
            // Preenche o campo nativo e faz submit do form de pesquisa
            if (wpSearchInp) wpSearchInp.value = val;
            // Tentar encontrar e submeter o form de busca nativo
            var searchForm = wrap.querySelector('form.search-form') ||
                             wrap.querySelector('form[method="get"]');
            if (searchForm) {
                var s = searchForm.querySelector('input[name="s"]');
                if (s) s.value = val;
                searchForm.submit();
            }
        }

    });
})();
