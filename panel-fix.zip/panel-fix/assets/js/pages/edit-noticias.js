/**
 * Hoost Admin — Lista de Notícias / Blog
 * Baseado no HTML de referência do Stitch (documento 3)
 */
(function () {
    'use strict';

    document.addEventListener('DOMContentLoaded', function () {

        var body = document.body;
        var isNoticias = body.classList.contains('post-type-noticias');
        var isBlog     = body.classList.contains('post-type-blog');
        if (!isNoticias && !isBlog) return;

        var wrap = document.querySelector('#wpcontent .wrap');
        if (!wrap) wrap = document.querySelector('.wrap');
        if (!wrap) return;

        var wpTable = wrap.querySelector('.wp-list-table');
        if (!wpTable) return;

        // ── COLETAR ELEMENTOS NATIVOS ──────────────────────────────────────
        var wpH1          = wrap.querySelector('h1.wp-heading-inline');
        var wpAddBtn      = wrap.querySelector('a.page-title-action');
        var subsubsub     = wrap.querySelector('.subsubsub');
        var dispNum       = wrap.querySelector('.displaying-num');
        var wpBulkSel     = wrap.querySelector('#bulk-action-selector-top');
        var wpSearch      = wrap.querySelector('#post-search-input, input[name="s"]');
        var seoFilterSel  = wrap.querySelector('#wpseo-filter, select[name="seo_filter"]');
        var readFilterSel = wrap.querySelector('#wpseo-readability-filter, select[name="readability_filter"]');

        // --- TÍTULO ---
        var titleText = wpH1 ? wpH1.textContent.trim() : (isNoticias ? 'Notícias' : 'Blog');
        var addHref   = wpAddBtn ? wpAddBtn.href : '#';

        // --- PILLS ---
        var pillData = [];
        if (subsubsub) {
            subsubsub.querySelectorAll('li').forEach(function (li) {
                var a   = li.querySelector('a');
                if (!a) return;
                var raw = a.textContent.replace(/\s*\|\s*$/, '').trim();
                var ok  = /^(tudo|todos|publicado|conteúdo estrutural)/i.test(raw.toLowerCase());
                if (!ok) return;
                pillData.push({
                    label  : raw,
                    href   : a.href,
                    active : a.classList.contains('current'),
                    isBlue : /publicad/i.test(raw)
                });
            });
        }
        if (pillData.length === 0) {
            var base = window.location.href.split('?')[0];
            var pt   = (window.location.href.match(/post_type=([^&]+)/) || [,'noticias'])[1];
            pillData = [
                { label: 'Todos',               href: base+'?post_type='+pt,                         active: true,  isBlue: false },
                { label: 'Publicados',           href: base+'?post_status=publish&post_type='+pt,     active: false, isBlue: true  },
                { label: 'Conteúdo estrutural',  href: '#',                                           active: false, isBlue: false }
            ];
        }

        // --- CLONAR SELECTS ---
        var seoSelClone  = seoFilterSel  ? seoFilterSel.cloneNode(true)  : null;
        var readSelClone = readFilterSel ? readFilterSel.cloneNode(true) : null;
        var bulkSelClone = wpBulkSel     ? wpBulkSel.cloneNode(true)     : null;

        if (seoSelClone)  seoSelClone.id  = 'hoost-filter-seo';
        if (readSelClone) readSelClone.id = 'hoost-filter-readability';
        if (bulkSelClone) bulkSelClone.id = 'hoost-bulk-select';

        // --- ITEM COUNT ---
        var itemCountText = '';
        if (dispNum) {
            itemCountText = dispNum.textContent.trim();
        } else {
            var rowCount = wpTable.querySelectorAll('tbody tr:not(.no-items)').length;
            itemCountText = rowCount + ' itens';
        }

        // ── CONSTRUÇÃO DO DOM ──────────────────────────────────────────────

        // 1. HEADER
        var header = el('div', 'hoost-noticias-header');
        var h1Node = el('h1');
        h1Node.textContent = titleText;
        var addBtn = el('a', 'hoost-add-btn');
        addBtn.href = addHref;
        addBtn.textContent = 'Adicionar nova';
        header.appendChild(h1Node);
        header.appendChild(addBtn);

        // 2. PILLS
        var pillsRow = el('div', 'hoost-tab-pills');
        pillData.forEach(function (p) {
            var pill = el('a', 'hoost-tab-pill');
            pill.href = p.href;
            pill.textContent = p.label;
            if (p.active)      pill.classList.add('active');
            else if (p.isBlue) pill.classList.add('blue');
            pillsRow.appendChild(pill);
        });

        // 3. FILTER BAR
        var filterBar  = el('div', 'hoost-filter-bar');
        var filterLeft = el('div', 'hoost-filter-left');

        // Select SEO
        if (seoSelClone) {
            filterLeft.appendChild(seoSelClone);
            seoSelClone.addEventListener('change', submitForm);
        } else {
            var fallSeo = el('select');
            fallSeo.innerHTML =
                '<option value="">Todas as pontuações de SEO</option>' +
                '<option value="bad">SEO: Precisa melhorar</option>' +
                '<option value="ok">SEO: OK</option>' +
                '<option value="good">SEO: Bom</option>' +
                '<option value="na">SEO: No Focus Keyphrase</option>';
            filterLeft.appendChild(fallSeo);
        }

        // Select Legibilidade
        if (readSelClone) {
            filterLeft.appendChild(readSelClone);
            readSelClone.addEventListener('change', submitForm);
        } else {
            var fallRead = el('select');
            fallRead.innerHTML =
                '<option value="">Todas as pontuações de legibilidade</option>' +
                '<option value="bad">Legibilidade: Precisa melhorar</option>' +
                '<option value="ok">Legibilidade: OK</option>' +
                '<option value="good">Legibilidade: Bom</option>';
            filterLeft.appendChild(fallRead);
        }

        // Botão Filtrar
        var filtrarBtn = el('button', 'hoost-filter-btn');
        filtrarBtn.type = 'button';
        filtrarBtn.textContent = 'Filtrar';
        filtrarBtn.addEventListener('click', submitForm);
        filterLeft.appendChild(filtrarBtn);

        // Pesquisa
        var searchWrap = el('div', 'hoost-search-wrap');
        var searchInp  = el('input', 'hoost-search-input');
        searchInp.type = 'search';
        searchInp.name = 's';
        searchInp.placeholder = 'Pesquisar notícias';
        if (wpSearch && wpSearch.value) searchInp.value = wpSearch.value;

        var searchBtn = el('button', 'hoost-search-btn');
        searchBtn.type = 'button';
        searchBtn.textContent = 'Pesquisar notícias';
        searchBtn.addEventListener('click', function () { submitSearch(searchInp.value); });
        searchInp.addEventListener('keydown', function (e) {
            if (e.key === 'Enter') { e.preventDefault(); submitSearch(searchInp.value); }
        });

        searchWrap.appendChild(searchInp);
        searchWrap.appendChild(searchBtn);
        filterBar.appendChild(filterLeft);
        filterBar.appendChild(searchWrap);

        // 4. FOOTER (ações em massa + contador)
        var footer   = el('div', 'hoost-noticias-footer');
        var bulkWrap = el('div', 'hoost-bulk-wrap');

        var bulkSelNode;
        if (bulkSelClone) {
            bulkSelNode = bulkSelClone;
        } else {
            bulkSelNode = el('select');
            bulkSelNode.innerHTML =
                '<option>Ações em massa</option>' +
                '<option value="edit">Editar</option>' +
                '<option value="trash">Mover para a lixeira</option>';
        }
        bulkWrap.appendChild(bulkSelNode);

        var applyBtn = el('button', 'hoost-apply-btn');
        applyBtn.type = 'button';
        applyBtn.textContent = 'Aplicar';
        applyBtn.addEventListener('click', function () {
            var origSel = document.getElementById('bulk-action-selector-top');
            if (origSel) origSel.value = bulkSelNode.value;
            var doBtn = document.getElementById('doaction');
            if (doBtn) doBtn.click();
        });
        bulkWrap.appendChild(applyBtn);

        var itemCount = el('span', 'hoost-item-count');
        itemCount.textContent = itemCountText;
        footer.appendChild(bulkWrap);
        footer.appendChild(itemCount);

        // ── INSERIR NO DOM ─────────────────────────────────────────────────
        // Estratégia: inserir tudo como filhos diretos do wrap, na ordem certa.
        // O form (#posts-filter) já está no wrap — inserimos antes e depois dele.

        var form = wrap.querySelector('#posts-filter');
        if (!form) form = wpTable.closest('form') || wpTable.parentNode;

        // header → pillsRow → filterBar → [form existente] → footer
        wrap.insertBefore(header,    form);   // antes do form
        wrap.insertBefore(pillsRow,  form);   // antes do form (após header)
        wrap.insertBefore(filterBar, form);   // imediatamente antes do form

        // footer: após o form
        if (form.nextSibling) {
            wrap.insertBefore(footer, form.nextSibling);
        } else {
            wrap.appendChild(footer);
        }

        // ── HELPERS ────────────────────────────────────────────────────────
        function el(tag, cls) {
            var e = document.createElement(tag);
            if (cls) e.className = cls;
            return e;
        }

        function submitForm() {
            var f = document.getElementById('posts-filter') || wrap.querySelector('form');
            if (f) f.submit();
        }

        function submitSearch(val) {
            var f = document.getElementById('posts-filter') || wrap.querySelector('form');
            if (!f) return;
            var s = f.querySelector('input[name="s"]');
            if (s) s.value = val;
            f.submit();
        }

    });
})();
