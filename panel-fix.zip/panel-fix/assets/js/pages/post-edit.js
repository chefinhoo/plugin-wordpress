/**
 * Hoost Admin — Tela de Edição de Post (post-new.php / post.php)
 * Apenas remove o separador | entre título e botão. Layout fica com o WP/CSS.
 */
(function () {
    'use strict';

    document.addEventListener('DOMContentLoaded', function () {

        var body = document.body;
        var isPostNew  = body.classList.contains('post-new-php');
        var isPostEdit = body.classList.contains('post-php');
        if (!isPostNew && !isPostEdit) return;

        var wrap = document.querySelector('#wpcontent .wrap');
        if (!wrap) return;

        // Remover text nodes que são apenas "|" ou "&nbsp;|&nbsp;" entre h1 e .page-title-action
        wrap.childNodes.forEach(function (node) {
            if (node.nodeType === 3 && /^\s*\|\s*$/.test(node.textContent.replace(/\u00a0/g, ' '))) {
                node.textContent = '';
            }
        });

    });
})();
