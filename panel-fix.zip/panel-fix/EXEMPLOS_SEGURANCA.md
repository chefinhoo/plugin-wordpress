# 🔒 EXEMPLOS PRÁTICOS: SEGURANÇA E MULTISITE

## 1. COMO ADICIONAR FORMULÁRIO COM SEGURANÇA

### ❌ INSEGURO (NÃO FAÇA)

```php
function meu_form_inseguro() {
    ?>
    <form method="POST">
        <input type="text" name="titulo" value="<?php echo $_POST['titulo']; ?>">
        <button>Salvar</button>
    </form>
    <?php
    
    if ( isset( $_POST['titulo'] ) ) {
        update_option( 'meu_titulo', $_POST['titulo'] );
    }
}
```

**Problemas:**
- Sem nonce → CSRF attack
- `$_POST` direto → XSS attack
- Sem sanitização → SQL injection / malware

---

### ✅ SEGURO (FAÇA ASSIM)

```php
function meu_form_seguro() {
    // Verificar permissão
    if ( ! current_user_can( 'manage_options' ) ) {
        wp_die( 'Acesso negado' );
    }
    
    // Processar formulário
    if ( $_SERVER['REQUEST_METHOD'] === 'POST' ) {
        // 1. Verificar nonce
        if ( !isset( $_POST['meu_form_nonce'] ) || 
             !wp_verify_nonce( $_POST['meu_form_nonce'], 'meu_form_action' ) ) {
            wp_die( 'Verificação de segurança falhou' );
        }
        
        // 2. Sanitizar dados
        $titulo = isset( $_POST['titulo'] ) 
            ? sanitize_text_field( $_POST['titulo'] ) 
            : '';
        
        // 3. Validar dados
        if ( empty( $titulo ) ) {
            wp_die( 'Título é obrigatório' );
        }
        
        // 4. Processar com segurança
        update_option( 'meu_titulo', $titulo );
        echo '<div class="updated"><p>Salvo com sucesso!</p></div>';
    }
    
    // 5. Recuperar dados com escape
    $titulo = get_option( 'meu_titulo', '' );
    
    ?>
    <form method="POST">
        <!-- 6. Adicionar nonce field -->
        <?php wp_nonce_field( 'meu_form_action', 'meu_form_nonce' ); ?>
        
        <!-- 7. Escapar output -->
        <input type="text" name="titulo" value="<?php echo esc_attr( $titulo ); ?>">
        <button type="submit">Salvar</button>
    </form>
    <?php
}
```

---

## 2. VALIDAÇÃO DE DADOS (CORRETO)

### Email

```php
$email = isset( $_POST['email'] ) ? sanitize_email( $_POST['email'] ) : '';

// Validar
if ( !is_email( $email ) ) {
    wp_die( 'Email inválido' );
}
```

### Número

```php
$numero = isset( $_POST['numero'] ) ? intval( $_POST['numero'] ) : 0;

// Validar
if ( $numero <= 0 || $numero > 100 ) {
    wp_die( 'Número deve estar entre 1 e 100' );
}
```

### Texto longo

```php
$conteudo = isset( $_POST['conteudo'] ) 
    ? wp_kses_post( $_POST['conteudo'] ) 
    : '';

// wp_kses_post() permite HTML seguro (tags wp_kses_allowed_html)
```

### Escolha de lista

```php
$tipo = isset( $_POST['tipo'] ) ? sanitize_text_field( $_POST['tipo'] ) : 'padrao';

// Validar contra whitelist
$tipos_validos = [ 'padrao', 'premium', 'teste' ];
if ( !in_array( $tipo, $tipos_validos, true ) ) {
    wp_die( 'Tipo inválido' );
}
```

---

## 3. MULTISITE: DIFERENTES COMPORTAMENTOS POR SITE

### ❌ ANTES: Menu só no site principal

```php
function meu_menu() {
    if ( ! hoost_is_main() ) return; // ← Subsites não veem nada
    
    add_menu_page( 'Meu Menu', 'Meu Menu', 'manage_options', 'meu-menu', ... );
}
```

---

### ✅ DEPOIS: Menu em todos os sites (com ajustes)

```php
function meu_menu() {
    // Aplicar para TODOS os sites
    add_menu_page( 'Meu Menu', 'Meu Menu', 'manage_options', 'meu-menu', ... );
}

function meu_menu_conteudo() {
    if ( hoost_is_main() ) {
        // Site principal vê tudo
        ?>
        <h2>Configurações globais da rede</h2>
        <p>Aqui você pode gerenciar todos os subsites</p>
        <?php
    } else {
        // Subsites veem apenas seu conteúdo
        ?>
        <h2>Configurações do seu site</h2>
        <p>Aqui você pode gerenciar apenas seu site</p>
        <?php
    }
}
```

---

## 4. MULTISITE: CAPABILIDADES POR SITE

### Restringir função apenas para Super Admin

```php
function funcao_so_super_admin() {
    // Apenas Super Admin da rede (não admin dos subsites)
    if ( ! is_super_admin() ) {
        wp_die( 'Apenas Super Admin pode fazer isso' );
    }
    
    // Código aqui roda só no Super Admin
}
```

### Permitir Admin do subsite MAS com restrições

```php
function funcao_admin_subsite() {
    // Admin do subsite atual OU Super Admin
    if ( ! current_user_can( 'manage_options' ) ) {
        wp_die( 'Acesso negado' );
    }
    
    $current_blog_id = get_current_blog_id();
    
    // Mais restrições...
    if ( hoost_is_main() ) {
        // Site principal: permitir tudo
    } else {
        // Subsite: permitir apenas coisas do subsite
        if ( ! current_user_can( 'edit_posts' ) ) {
            wp_die( 'Acesso negado' );
        }
    }
}
```

---

## 5. DADOS PRIVADOS vs PÚBLICOS EM MULTISITE

### ❌ COMPARTILHAR DADOS SEM QUERER

```php
function meu_funcao_ruim() {
    // Site 1 consegue acessar dados do Site 2 (PERIGOSO!)
    $users_site_2 = get_users( [
        'blog_id' => 2, // Site 2
        'role' => 'administrator'
    ] );
    
    // Se não verificar permissões, Site 1 vê tudo do Site 2
    foreach ( $users_site_2 as $user ) {
        echo $user->user_email; // EMAIL EXPOSTO!
    }
}
```

---

### ✅ ISOLAR DADOS POR SITE

```php
function meu_funcao_segura() {
    // Apenas dados do site ATUAL
    $current_blog_id = get_current_blog_id();
    
    // Opção 1: Dados por site (blog_id na chave)
    $opcao = get_option( 'meu_opcao_' . $current_blog_id );
    
    // Opção 2: Post type por site
    $meus_posts = get_posts( [
        'post_type' => 'meu_cpt',
        'posts_per_page' => -1
        // ↑ Automatically filters by current blog
    ] );
    
    // Opção 3: User meta por site
    $meu_user_meta = get_user_meta( get_current_user_id(), 'meu_meta' );
    
    // Verificar sempre se usuário pode acessar THIS site
    if ( !is_user_member_of_blog( get_current_user_id(), $current_blog_id ) ) {
        wp_die( 'Você não tem acesso a este site' );
    }
}
```

---

## 6. OPÇÕES GLOBAIS (NETWORK) vs OPÇÕES POR SITE

### Opção GLOBAL (afeta toda a rede)

```php
// Salvar
update_site_option( 'minha_opcao_global', 'valor' );

// Recuperar (funciona em qualquer site)
$valor = get_site_option( 'minha_opcao_global' );

// Apenas Super Admin pode fazer:
if ( ! is_super_admin() ) {
    wp_die( 'Apenas Super Admin' );
}
```

### Opção POR SITE (afeta apenas o site atual)

```php
// Salvar
update_option( 'minha_opcao_site', 'valor' );

// Recuperar (apenas do site atual)
$valor = get_option( 'minha_opcao_site' );

// Admin do subsite pode fazer:
if ( ! current_user_can( 'manage_options' ) ) {
    wp_die( 'Acesso negado' );
}
```

### Exemplo Prático: Cor do tema

```php
// Cor da rede (todos os sites usam a mesma)
$cor_rede = get_site_option( 'cor_primaria_rede', '#000000' );

// OU Cor individual (cada site sua cor)
$cor_site = get_option( 'cor_primaria_site', '#000000' );
```

---

## 7. TRANSIENTS (CACHE) CORRETO

### ❌ ERRADO

```php
function meu_funcao_lenta() {
    $resultado = fazer_algo_lento(); // Query pesada
    return $resultado;
}
// Toda chamada faz query pesada ❌
```

---

### ✅ CERTO COM TRANSIENT

```php
function meu_funcao_rapida() {
    // Tentar pegar do cache
    $resultado = get_transient( 'meu_resultado_cache' );
    
    if ( $resultado === false ) {
        // Cache expirou, fazer query
        $resultado = fazer_algo_lento();
        
        // Guardar no cache por 6 horas (21600 segundos)
        set_transient( 'meu_resultado_cache', $resultado, 21600 );
    }
    
    return $resultado;
}

// Invalidar cache quando há mudanças
add_action( 'save_post', 'limpar_cache' );
function limpar_cache() {
    delete_transient( 'meu_resultado_cache' );
}
```

### Transients em Multisite

```php
// Opção 1: Cache global (Network)
get_site_transient( 'meu_cache' );
set_site_transient( 'meu_cache', $valor, 3600 );

// Opção 2: Cache por site (isolado)
get_transient( 'meu_cache' ); // Automático por site
set_transient( 'meu_cache', $valor, 3600 );
```

---

## 8. AJAX COM SEGURANÇA

### Adicionar dados no frontend

```php
// No plugin PHP
wp_localize_script( 'meu-script', 'meuDados', [
    'nonce' => wp_create_nonce( 'meu_ajax_action' ),
    'ajaxUrl' => admin_url( 'admin-ajax.php' ),
] );
```

### Enviar AJAX com nonce

```javascript
// No arquivo admin-script.js
fetch(meuDados.ajaxUrl, {
    method: 'POST',
    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
    body: 'action=meu_ajax_action&nonce=' + meuDados.nonce + '&id=123'
})
.then(r => r.json())
.then(data => console.log(data));
```

### Processar AJAX com segurança

```php
// No plugin PHP
add_action( 'wp_ajax_meu_ajax_action', 'processar_meu_ajax' );
function processar_meu_ajax() {
    // 1. Verificar nonce
    if ( !isset( $_POST['nonce'] ) || !wp_verify_nonce( $_POST['nonce'], 'meu_ajax_action' ) ) {
        wp_send_json_error( 'Nonce inválido' );
    }
    
    // 2. Verificar permissão
    if ( !current_user_can( 'manage_options' ) ) {
        wp_send_json_error( 'Sem permissão' );
    }
    
    // 3. Sanitizar dados
    $id = isset( $_POST['id'] ) ? intval( $_POST['id'] ) : 0;
    
    // 4. Processar
    $post = get_post( $id );
    if ( !$post ) {
        wp_send_json_error( 'Post não encontrado' );
    }
    
    // 5. Responder com segurança
    wp_send_json_success( [
        'titulo' => esc_html( $post->post_title ),
        'conteudo' => wp_kses_post( $post->post_content ),
    ] );
}
```

---

## 9. CHECKLIST DE SEGURANÇA ANTES DE DEPLOY

```
CSRF Protection:
  [ ] Todos os formulários têm wp_nonce_field()?
  [ ] Todos os AJAX verificam wp_verify_nonce()?

Input Validation:
  [ ] Dados de POST/GET são sanitizados?
  [ ] Emails validados com is_email()?
  [ ] Números validados com intval()?
  [ ] Arrays validados com in_array( ..., true )?

Output Escaping:
  [ ] Texto usa esc_html()?
  [ ] Atributos usam esc_attr()?
  [ ] URLs usam esc_url()?
  [ ] JavaScript usa esc_js()?
  [ ] HTML rich text usa wp_kses_post()?

Permissions:
  [ ] Funções admin verificam current_user_can()?
  [ ] Super Admin funções usam is_super_admin()?
  [ ] Dados de outros sites isolados?

Database:
  [ ] Queries usam $wpdb->prepare()?
  [ ] Sem concatenação direta de SQL?

Performance:
  [ ] Queries caras têm cache com transients?
  [ ] Cache é invalidado ao publicar/deletar?

Multisite:
  [ ] Dados isolados por site?
  [ ] Não expõe dados de outros sites?
  [ ] Usa site_transients para global?
```

---

## 10. ESTRUTURA FINAL RECOMENDADA

```
seu-plugin/
├── seu-plugin.php              ← Plugin principal (carrega todo o resto)
├── includes/
│   ├── class-admin.php         ← Menu, dashboard, funções admin
│   ├── class-security.php      ← Nonce, sanitização, escapar
│   ├── class-multisite.php     ← CPTs, taxonomias, isolamento
│   ├── class-ajax.php          ← AJAX handlers
│   └── functions.php           ← Helpers e utilidades
├── assets/
│   ├── css/
│   │   ├── admin.css
│   │   └── admin.min.css
│   └── js/
│       ├── admin.js
│       └── admin.min.js
└── README.md                    ← Documentação

// seu-plugin.php exemplo:
<?php
define( 'SEU_PLUGIN_PATH', plugin_dir_path( __FILE__ ) );

// Security
require_once SEU_PLUGIN_PATH . 'includes/class-security.php';

// Multisite
require_once SEU_PLUGIN_PATH . 'includes/class-multisite.php';

// Admin
if ( is_admin() ) {
    require_once SEU_PLUGIN_PATH . 'includes/class-admin.php';
    require_once SEU_PLUGIN_PATH . 'includes/class-ajax.php';
}
?>
```

---

**Referências:**
- https://developer.wordpress.org/plugins/security/
- https://developer.wordpress.org/plugins/hooks/
- https://developer.wordpress.org/plugins/security/nonces/
- https://developer.wordpress.org/plugins/security/sanitizing-input/
- https://developer.wordpress.org/plugins/security/escaping-output/
