<?php
/**
 * Plugin Name: Panel Administrativo Danilo Ramos
 * Plugin URI:  https://daniloramos.dev.br
 * Description: Customização completa do painel administrativo. Suporta Multisite.
 * Version:     3.3
 * Author:      Danilo Ramos
 * Author URI:  https://daniloramos.dev.br
 * License:     GPL v2 or later
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain: hoost
 * Domain Path: /languages
 * Network:     true
 * 
 * 🔧 VERSÃO 3.2 - Mudanças principais:
 * ✅ Suporte completo a Multisite (CPTs + Menu em subsites)
 * ✅ Verificações de nonce e segurança (CSRF protection)
 * ✅ Sanitização de dados (XSS prevention)
 * ✅ Performance: CSS/JS em arquivos separados
 * ✅ Cache com transients para DB queries
 * ✅ Estrutura modular e escalável
 */

if ( ! defined( 'ABSPATH' ) ) { 
    exit; 
}

// ═══════════════════════════════════════════════════════════════════════
// Constantes e Configurações
// ═══════════════════════════════════════════════════════════════════════

define( 'HOOST_PLUGIN_PATH', plugin_dir_path( __FILE__ ) );
define( 'HOOST_PLUGIN_URL', plugin_dir_url( __FILE__ ) );
define( 'HOOST_PLUGIN_VERSION', '3.3' );

// ═══════════════════════════════════════════════════════════════════════
// Carregar classe de gerenciamento de páginas
// ═══════════════════════════════════════════════════════════════════════

require_once HOOST_PLUGIN_PATH . 'includes/class-admin-pages.php';

// Customizações de listas administrativas (colunas, estilos)
require_once HOOST_PLUGIN_PATH . 'includes/admin-list-customizations.php';

global $hoost_admin_pages;
$hoost_admin_pages = new HOOST_Admin_Pages( HOOST_PLUGIN_PATH, HOOST_PLUGIN_URL );

// ═══════════════════════════════════════════════════════════════════════
// MULTISITE — CONTROLE DE ATIVAÇÃO
// ═══════════════════════════════════════════════════════════════════════

add_filter( 'all_plugins', 'hoost_ocultar_plugin_subsites' );
function hoost_ocultar_plugin_subsites( $plugins ) {
    if ( ! is_multisite() ) return $plugins;
    if ( is_main_site() )   return $plugins;

    $plugin_file = plugin_basename( __FILE__ );
    unset( $plugins[ $plugin_file ] );
    return $plugins;
}

add_action( 'activate_' . plugin_basename( __FILE__ ), 'hoost_bloquear_ativacao_subsite' );
function hoost_bloquear_ativacao_subsite() {
    if ( is_multisite() && ! is_main_site() ) {
        deactivate_plugins( plugin_basename( __FILE__ ) );
        wp_die( esc_html__( 'Este plugin só pode ser ativado pelo site principal.', 'hoost' ) );
    }
}

// ═══════════════════════════════════════════════════════════════════════
// HELPER MULTISITE
// ═══════════════════════════════════════════════════════════════════════

function hoost_is_main() {
    if ( ! is_multisite() ) return true;
    return is_main_site();
}

// ═══════════════════════════════════════════════════════════════════════
// 1. REGISTRO DOS TIPOS DE POST (em TODOS os sites)
// ═══════════════════════════════════════════════════════════════════════

add_action( 'init', 'registrar_funcionalidades_hoost', 10 );
function registrar_funcionalidades_hoost() {

    $funcionalidades = [
        'noticias'         => [ 'Notícias',         'Notícia',          'dashicons-admin-post' ],
        'blog'             => [ 'Blog',             'Post do Blog',     'dashicons-admin-post' ],
        'programacao'      => [ 'Programação',      'Programa',         'dashicons-admin-post' ],
        'galeria_de_fotos' => [ 'Galeria de fotos', 'Galeria de Fotos', 'dashicons-admin-post' ],
        'eventos'          => [ 'Eventos',          'Evento',           'dashicons-admin-post' ],
        'videos'           => [ 'Vídeos',           'Vídeo',            'dashicons-admin-post' ],
        'equipe'           => [ 'Equipe',           'Membro',           'dashicons-admin-post' ],
        'promocoes'        => [ 'Promoções',        'Promoção',         'dashicons-admin-post' ],
        'poll'             => [ 'Enquetes',         'Votação',          'dashicons-chart-bar'  ],
    ];

    foreach ( $funcionalidades as $slug => $dados ) {
        register_post_type( $slug, [
            'labels'            => [
                'name'          => $dados[0],
                'singular_name' => $dados[1],
                'add_new_item'  => 'Adicionar ' . $dados[1],
                'all_items'     => 'Todos',
            ],
            'public'            => true,
            'show_ui'           => true,
            'show_in_menu'      => true,
            'show_in_admin_bar' => true,
            'show_in_nav_menus' => true,
            'has_archive'       => true,
            'menu_icon'         => $dados[2],
            'supports'          => [ 'title', 'editor', 'thumbnail', 'excerpt', 'comments' ],
            'taxonomies'        => [],
            'rewrite'           => [ 'slug' => $slug ],
            'capability_type'   => 'post',
            'map_meta_cap'      => true,
        ] );
    }

    // Taxonomia: Categorias de Notícias
    register_taxonomy( 'categoria_noticias', 'noticias', [
        'label'             => 'Categorias',
        'rewrite'           => [ 'slug' => 'categoria-noticia' ],
        'hierarchical'      => true,
        'show_admin_column' => true,
        'show_in_menu'      => false,
        'show_in_nav_menus' => true,
    ] );

    // Taxonomia: Categorias do Blog
    register_taxonomy( 'categoria_blog', 'blog', [
        'label'             => 'Categorias',
        'rewrite'           => [ 'slug' => 'categoria-blog' ],
        'hierarchical'      => true,
        'show_admin_column' => true,
        'show_in_menu'      => false,
        'show_in_nav_menus' => true,
    ] );
}

// Flush rewrite rules corretamente
add_action( 'admin_init', 'hoost_flush_rewrite_rules' );
function hoost_flush_rewrite_rules() {
    $option = get_option( 'hoost_flush_rewrite' );
    if ( $option === 'pending' ) {
        flush_rewrite_rules( false );
        update_option( 'hoost_flush_rewrite', 'done' );
    }
}

register_activation_hook( __FILE__, function () {
    registrar_funcionalidades_hoost();
    update_option( 'hoost_flush_rewrite', 'pending' );
    flush_rewrite_rules( false );
} );

register_deactivation_hook( __FILE__, function() {
    flush_rewrite_rules( false );
    delete_option( 'hoost_flush_rewrite' );
} );

// ═══════════════════════════════════════════════════════════════════════
// 2. REDIRECIONAR INÍCIO
// ═══════════════════════════════════════════════════════════════════════

add_action( 'admin_init', 'hoost_redirecionar_inicio' );
function hoost_redirecionar_inicio() {
    if ( ! hoost_is_main() ) return;
    global $pagenow;
    if ( $pagenow === 'index.php' && ! isset( $_GET['page'] ) ) {
        wp_safe_remote_post( admin_url( 'index.php?page=hoost-dashboard' ) );
        exit;
    }
}

// ═══════════════════════════════════════════════════════════════════════
// 3. CONFIGURAÇÃO DOS MENUS (em TODOS os sites)
// ═══════════════════════════════════════════════════════════════════════

add_action( 'admin_menu', 'configurar_menu_painel_hoost', 5 );
function configurar_menu_painel_hoost() {
    global $menu;

    add_submenu_page( 'index.php', 'Dashboard', 'Dashboard', 'manage_options', 'hoost-dashboard', 'renderizar_painel_customizado' );

    foreach ( $menu as $key => $item ) {
        if ( $item[2] === 'users.php'  ) $menu[$key][0] = 'ADM – Usuários';
        if ( $item[2] === 'themes.php' ) $menu[$key][0] = 'ADM – Temas';
    }

    // Garantir que os CPTs apareçam no menu (importante no Multisite)
    add_menu_page( 'Notícias', 'Notícias', 'edit_posts', 'edit.php?post_type=noticias', '', 'dashicons-admin-post', 6 );

    add_menu_page( 'Configurações gerais', 'Configurações gerais', 'manage_options', 'config-gerais-custom', function() { global $hoost_admin_pages; $hoost_admin_pages->render_page( 'config-geral' ); }, 'dashicons-admin-generic', 50 );
    add_submenu_page( 'config-gerais-custom', 'Streaming e player', 'Streaming e player', 'manage_options', 'config-streaming',   function() { global $hoost_admin_pages; $hoost_admin_pages->render_page( 'config-streaming' ); } );
    add_submenu_page( 'config-gerais-custom', 'Configurações',      'Configurações',      'manage_options', 'config-geral',       function() { global $hoost_admin_pages; $hoost_admin_pages->render_page( 'config-geral' ); } );
    add_submenu_page( 'config-gerais-custom', 'Avançado',           'Avançado',           'manage_options', 'config-avancado',    function() { global $hoost_admin_pages; $hoost_admin_pages->render_page( 'config-avancado' ); } );
    add_submenu_page( 'config-gerais-custom', 'Utilidades',         'Utilidades',         'manage_options', 'config-utilidades',  function() { global $hoost_admin_pages; $hoost_admin_pages->render_page( 'config-utilidades' ); } );
    add_submenu_page( 'config-gerais-custom', 'Privacidade',        'Privacidade',        'manage_options', 'config-privacidade', function() { global $hoost_admin_pages; $hoost_admin_pages->render_page( 'config-privacidade' ); } );

    add_menu_page( 'Personalização', 'Personalização', 'manage_options', 'personalizacao-custom', function() { global $hoost_admin_pages; $hoost_admin_pages->render_page( 'person-cores' ); }, 'dashicons-admin-appearance', 51 );
    add_submenu_page( 'personalizacao-custom', 'Cores e estilos',         'Cores e estilos',         'manage_options', 'person-cores',    function() { global $hoost_admin_pages; $hoost_admin_pages->render_page( 'person-cores' ); } );
    add_submenu_page( 'personalizacao-custom', 'Página Inicial',          'Página Inicial',          'manage_options', 'person-home',     function() { global $hoost_admin_pages; $hoost_admin_pages->render_page( 'person-home' ); } );
    add_submenu_page( 'personalizacao-custom', 'Página inicial: Módulos', 'Página inicial: Módulos', 'manage_options', 'person-modulos',  function() { global $hoost_admin_pages; $hoost_admin_pages->render_page( 'person-modulos' ); } );
    add_submenu_page( 'personalizacao-custom', 'Página inicial: Slider',  'Página inicial: Slider',  'manage_options', 'person-slider',   function() { global $hoost_admin_pages; $hoost_admin_pages->render_page( 'person-slider' ); } );
    add_submenu_page( 'personalizacao-custom', 'Páginas Internas',        'Páginas Internas',        'manage_options', 'person-internas', function() { global $hoost_admin_pages; $hoost_admin_pages->render_page( 'person-internas' ); } );
    add_submenu_page( 'personalizacao-custom', 'Widgets',                 'Widgets',                 'manage_options', 'person-widgets',  function() { global $hoost_admin_pages; $hoost_admin_pages->render_page( 'person-widgets' ); } );
    add_submenu_page( 'personalizacao-custom', 'Menus',                   'Menus',                   'manage_options', 'person-menus',    function() { global $hoost_admin_pages; $hoost_admin_pages->render_page( 'person-menus' ); } );
    add_submenu_page( 'personalizacao-custom', 'Redes Sociais',           'Redes Sociais',           'manage_options', 'person-redes',    function() { global $hoost_admin_pages; $hoost_admin_pages->render_page( 'person-redes' ); } );

    $menu[3]  = [ '', 'read', 'separator-custom-1', '', 'wp-menu-separator' ];
    $menu[21] = [ '', 'read', 'separator-custom-2', '', 'wp-menu-separator' ];
    $menu[26] = [ '', 'read', 'separator-custom-3', '', 'wp-menu-separator' ];
    $menu[61] = [ '', 'read', 'separator-custom-4', '', 'wp-menu-separator' ];
    $menu[71] = [ '', 'read', 'separator-custom-5', '', 'wp-menu-separator' ];

    add_menu_page( 'Precisa de Ajuda?', 'Precisa de Ajuda?', 'read', 'ajuda-hoost', function() { global $hoost_admin_pages; $hoost_admin_pages->render_page( 'config-geral' ); }, 'none', 99 );
}

// ═══════════════════════════════════════════════════════════════════════
// 4. LIMPEZA E RENOMEAÇÃO DOS SUBMENUS
// ═══════════════════════════════════════════════════════════════════════

add_action( 'admin_menu', 'limpeza_extrema_menu_hoost', 99999 );
function limpeza_extrema_menu_hoost() {
    if ( ! hoost_is_main() ) return;

    global $menu, $submenu;

    $menus_permitidos = [
        'index.php',
        'edit.php?post_type=noticias',
        'edit.php?post_type=blog',
        'edit.php?post_type=programacao',
        'edit.php?post_type=galeria_de_fotos',
        'edit.php?post_type=eventos',
        'edit.php?post_type=videos',
        'edit.php?post_type=equipe',
        'edit.php?post_type=promocoes',
        'edit.php?post_type=poll',
        'edit.php?post_type=page',
        'edit-comments.php',
        'upload.php',
        'config-gerais-custom',
        'personalizacao-custom',
        'users.php',
        'themes.php',
        'ajuda-hoost',
        'separator-custom-1',
        'separator-custom-2',
        'separator-custom-3',
        'separator-custom-4',
        'separator-custom-5',
    ];

    foreach ( $menu as $chave => $item ) {
        if ( ! in_array( $item[2], $menus_permitidos, true ) ) {
            unset( $menu[$chave] );
        }
    }

    foreach ( [ 'plugins.php', 'update-core.php' ] as $slug ) {
        unset( $submenu[$slug] );
    }

    hoost_renomear_submenu( 'index.php', [
        'index.php'                      => 'Início',
        'index.php?page=hoost-dashboard' => 'Dashboard',
    ] );
    if ( isset( $submenu['index.php'] ) ) {
        foreach ( $submenu['index.php'] as $k => $v ) {
            if ( strpos( $v[2], 'update' ) !== false || strpos( $v[0], 'Atuali' ) !== false ) {
                unset( $submenu['index.php'][$k] );
            }
        }
    }

    if ( ! isset( $submenu['edit.php?post_type=noticias'] ) ) {
        $submenu['edit.php?post_type=noticias'] = [];
    }
    hoost_limpar_e_renomear_submenu( 'edit.php?post_type=noticias', [
        'edit.php?post_type=noticias'     => 'Todas as notícias',
        'post-new.php?post_type=noticias' => 'Adicionar nova',
    ] );
    if ( ! hoost_submenu_existe( 'edit.php?post_type=noticias', 'edit-tags.php?taxonomy=categoria_noticias&post_type=noticias' ) ) {
        $submenu['edit.php?post_type=noticias'][] = [
            'Categorias', 'manage_options',
            'edit-tags.php?taxonomy=categoria_noticias&post_type=noticias',
        ];
    }

    if ( ! isset( $submenu['edit.php?post_type=blog'] ) ) {
        $submenu['edit.php?post_type=blog'] = [];
    }
    hoost_limpar_e_renomear_submenu( 'edit.php?post_type=blog', [
        'edit.php?post_type=blog'     => 'Todos os posts',
        'post-new.php?post_type=blog' => 'Adicionar novo',
    ] );
    if ( ! hoost_submenu_existe( 'edit.php?post_type=blog', 'edit-tags.php?taxonomy=categoria_blog&post_type=blog' ) ) {
        $submenu['edit.php?post_type=blog'][] = [
            'Categorias', 'manage_options',
            'edit-tags.php?taxonomy=categoria_blog&post_type=blog',
        ];
    }

    hoost_limpar_e_renomear_submenu( 'edit.php?post_type=programacao', [
        'edit.php?post_type=programacao'     => 'Todas',
        'post-new.php?post_type=programacao' => 'Adicionar novo',
    ] );

    hoost_limpar_e_renomear_submenu( 'edit.php?post_type=galeria_de_fotos', [
        'edit.php?post_type=galeria_de_fotos'     => 'Todas',
        'post-new.php?post_type=galeria_de_fotos' => 'Adicionar nova',
    ] );

    hoost_limpar_e_renomear_submenu( 'edit.php?post_type=eventos', [
        'edit.php?post_type=eventos'     => 'Todas',
        'post-new.php?post_type=eventos' => 'Adicionar novo',
    ] );

    hoost_limpar_e_renomear_submenu( 'edit.php?post_type=videos', [
        'edit.php?post_type=videos'     => 'Todos',
        'post-new.php?post_type=videos' => 'Adicionar vídeo',
    ] );

    hoost_limpar_e_renomear_submenu( 'edit.php?post_type=equipe', [
        'edit.php?post_type=equipe'     => 'Todos',
        'post-new.php?post_type=equipe' => 'Adicionar novo',
    ] );

    hoost_limpar_e_renomear_submenu( 'edit.php?post_type=promocoes', [
        'edit.php?post_type=promocoes'     => 'Todas',
        'post-new.php?post_type=promocoes' => 'Adicionar nova promoção',
    ] );

    hoost_limpar_e_renomear_submenu( 'edit.php?post_type=poll', [
        'edit.php?post_type=poll'     => 'Todas as votações',
        'post-new.php?post_type=poll' => 'Adicionar novo',
    ] );

    hoost_limpar_e_renomear_submenu( 'edit.php?post_type=page', [
        'edit.php?post_type=page'     => 'Todas as páginas',
        'post-new.php?post_type=page' => 'Adicionar nova',
    ] );

    hoost_renomear_submenu( 'edit-comments.php', [
        'edit-comments.php' => 'Todos os comentários',
    ] );
    if ( ! hoost_submenu_existe( 'edit-comments.php', 'edit-comments.php?comment_type=hoost_mural' ) ) {
        $submenu['edit-comments.php'][] = [ 'Mural de Recados', 'moderate_comments', 'edit-comments.php?comment_type=hoost_mural' ];
    }

    hoost_renomear_submenu( 'upload.php', [
        'upload.php'    => 'Biblioteca',
        'media-new.php' => 'Adicionar nova',
    ] );

    hoost_renomear_submenu( 'users.php', [
        'users.php'    => 'Todos os usuários',
        'user-new.php' => 'Adicionar novo',
        'profile.php'  => 'Seu perfil',
    ] );
}

function hoost_renomear_submenu( $menu_slug, $map ) {
    global $submenu;
    if ( ! isset( $submenu[$menu_slug] ) ) return;
    foreach ( $submenu[$menu_slug] as $k => $item ) {
        if ( isset( $map[$item[2]] ) ) {
            $submenu[$menu_slug][$k][0] = $map[$item[2]];
        }
    }
}

function hoost_limpar_e_renomear_submenu( $menu_slug, $map ) {
    global $submenu;
    if ( ! isset( $submenu[$menu_slug] ) ) return;
    foreach ( $submenu[$menu_slug] as $k => $item ) {
        if ( isset( $map[$item[2]] ) ) {
            $submenu[$menu_slug][$k][0] = $map[$item[2]];
        } else {
            unset( $submenu[$menu_slug][$k] );
        }
    }
}

function hoost_submenu_existe( $menu_slug, $submenu_slug ) {
    global $submenu;
    if ( ! isset( $submenu[$menu_slug] ) ) return false;
    foreach ( $submenu[$menu_slug] as $item ) {
        if ( $item[2] === $submenu_slug ) return true;
    }
    return false;
}

// ═══════════════════════════════════════════════════════════════════════
// 5. ORDENAÇÃO DO MENU
// ═══════════════════════════════════════════════════════════════════════

add_filter( 'custom_menu_order', function( $v ) { return hoost_is_main() ? true : $v; } );
add_filter( 'menu_order', 'ordenar_menu_exato_hoost' );
function ordenar_menu_exato_hoost( $menu_ordem ) {
    if ( ! hoost_is_main() || ! $menu_ordem ) return $menu_ordem;
    return [
        'index.php', 'separator-custom-1',
        'edit.php?post_type=noticias',    'edit.php?post_type=blog',
        'edit.php?post_type=programacao', 'edit.php?post_type=galeria_de_fotos',
        'edit.php?post_type=eventos',     'edit.php?post_type=videos',
        'edit.php?post_type=equipe',      'edit.php?post_type=promocoes',
        'edit.php?post_type=poll',        'edit.php?post_type=page',
        'separator-custom-2', 'edit-comments.php', 'upload.php',
        'separator-custom-3', 'config-gerais-custom', 'personalizacao-custom',
        'separator-custom-4', 'users.php', 'themes.php',
        'separator-custom-5', 'ajuda-hoost',
    ];
}

// ═══════════════════════════════════════════════════════════════════════
// 6. ENFILAR ESTILOS (CSS separado)
// ═══════════════════════════════════════════════════════════════════════

add_action( 'admin_enqueue_scripts', 'hoost_enfileirar_estilos' );
function hoost_enfileirar_estilos() {
    wp_enqueue_style( 'hoost-admin-style', HOOST_PLUGIN_URL . 'assets/css/admin-style.css', [], HOOST_PLUGIN_VERSION );
    wp_enqueue_style( 'hoost-pages-css', HOOST_PLUGIN_URL . 'assets/css/pages/admin-pages.css', [ 'hoost-admin-style' ], HOOST_PLUGIN_VERSION );
    wp_enqueue_style( 'bootstrap-grid-css', 'https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap-grid.min.css', [], '4.5.2' );
    wp_enqueue_style( 'font-awesome-css', 'https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css', [], '4.7.0' );
    wp_enqueue_style( 'lato-font', 'https://fonts.googleapis.com/css2?family=Lato:wght@300;400;500;600;700&display=swap', [], '1' );

    // Tela de edição/criação de post (post-new.php e post.php)
    global $pagenow;
    if ( in_array( $pagenow, [ 'post-new.php', 'post.php' ], true ) ) {
        wp_enqueue_style(
            'hoost-post-edit-css',
            HOOST_PLUGIN_URL . 'assets/css/pages/post-edit.css',
            [ 'hoost-admin-style' ],
            HOOST_PLUGIN_VERSION
        );
        wp_enqueue_script(
            'hoost-post-edit-js',
            HOOST_PLUGIN_URL . 'assets/js/pages/post-edit.js',
            [],
            HOOST_PLUGIN_VERSION,
            true
        );
    }
}

// ═══════════════════════════════════════════════════════════════════════
// 7. DADOS PARA JAVASCRIPT (Seguro com transients)
// ═══════════════════════════════════════════════════════════════════════

add_action( 'admin_head', 'hoost_preparar_dados_admin' );
function hoost_preparar_dados_admin() {
    $current_user = wp_get_current_user();
    
    if ( ! current_user_can( 'manage_options' ) ) {
        return;
    }

    $cached_data = get_transient( 'hoost_admin_stats' );
    if ( $cached_data === false ) {
        $num_comments_obj = wp_count_comments();
        $pending_comments = (int) $num_comments_obj->moderated;
        $total_comments   = (int) $num_comments_obj->approved;
        $num_attachments  = (int) wp_count_posts( 'attachment' )->inherit;
        $num_users        = (int) count_users()['total_users'];

        $cached_data = [
            'pending_comments' => $pending_comments,
            'total_comments'   => $total_comments,
            'num_attachments'  => $num_attachments,
            'num_users'        => $num_users,
        ];
        
        set_transient( 'hoost_admin_stats', $cached_data, 21600 );
    }

    $avatar_url       = esc_url( get_avatar_url( $current_user->ID, [ 'size' => 80 ] ) );
    $display_name     = esc_js( $current_user->display_name );
    $pending_comments = (int) $cached_data['pending_comments'];
    $num_attachments  = (int) $cached_data['num_attachments'];
    $num_users        = (int) $cached_data['num_users'];
    
    $is_main = hoost_is_main() ? 'true' : 'false';
    $site_name = esc_js( get_bloginfo( 'name' ) );

    if ( hoost_is_main() ) {
        $novo_items = [
            'Mídia'            => 'media-new.php',
            'Página'           => 'post-new.php?post_type=page',
            'Notícia'          => 'post-new.php?post_type=noticias',
            'Post do Blog'     => 'post-new.php?post_type=blog',
            'Galeria de Fotos' => 'post-new.php?post_type=galeria_de_fotos',
            'Programa'         => 'post-new.php?post_type=programacao',
            'Evento'           => 'post-new.php?post_type=eventos',
            'Vídeo'            => 'post-new.php?post_type=videos',
            'Equipe'           => 'post-new.php?post_type=equipe',
            'Promoção'         => 'post-new.php?post_type=promocoes',
            'Votação'          => 'post-new.php?post_type=poll',
            'Usuário'          => 'user-new.php',
        ];
    } else {
        $novo_items = [
            'Mídia'   => 'media-new.php',
            'Página'  => 'post-new.php?post_type=page',
            'Post'    => 'post-new.php',
            'Usuário' => 'user-new.php',
        ];
    }

    wp_localize_script( 'hoost-admin-script', 'hoostData', [
        'adminUrl'       => esc_url( admin_url() ),
        'avatarUrl'      => $avatar_url,
        'userName'       => $display_name,
        'numComments'    => $pending_comments,
        'numMedia'       => $num_attachments,
        'numUsers'       => $num_users,
        'isMain'         => $is_main,
        'siteName'       => $site_name,
        'novoLinks'      => $novo_items,
        'logoutUrl'      => esc_url( wp_logout_url( home_url() ) ),
    ] );
}

// ═══════════════════════════════════════════════════════════════════════
// 8. ENFILAR JAVASCRIPT (Arquivo separado com defer)
// ═══════════════════════════════════════════════════════════════════════

add_action( 'admin_enqueue_scripts', 'hoost_enfileirar_scripts' );
function hoost_enfileirar_scripts() {
    wp_enqueue_script(
        'hoost-admin-script',
        HOOST_PLUGIN_URL . 'assets/js/admin-script.js',
        [],
        HOOST_PLUGIN_VERSION,
        [ 'in_footer' => true, 'strategy' => 'defer' ]
    );
}

// ═══════════════════════════════════════════════════════════════════════
// 9. REMOVER SETAS NATIVAS
// ═══════════════════════════════════════════════════════════════════════

add_action( 'admin_print_styles', 'hoost_remover_setas_nativas', 99999 );
function hoost_remover_setas_nativas() {
    echo '<style id="hoost-no-arrows">
    #adminmenu .wp-menu-arrow, #adminmenu .wp-menu-arrow div,
    #adminmenu li.wp-has-submenu::after,   #adminmenu li.wp-has-submenu a::after,
    #adminmenu li.wp-has-current-submenu::after, #adminmenu li.wp-menu-open::after,
    #adminmenu li.opensub::after,          #adminmenu li:hover::after,
    #adminmenu li > a::after,              #adminmenu li:hover > a::after,
    #adminmenu li.opensub > a::after,      #adminmenu li.wp-has-current-submenu > a::after {
        display: none !important; content: none !important; opacity: 0 !important;
        visibility: hidden !important; border: 0 !important;
        width: 0 !important; height: 0 !important;
        overflow: hidden !important; box-shadow: none !important; background: transparent !important;
    }
    </style>';
}

add_action( 'admin_footer', 'hoost_js_remover_setas', 99999 );
function hoost_js_remover_setas() {
    echo '<script>
    (function() {
        function killArrows() {
            document.querySelectorAll(".wp-menu-arrow").forEach(function(el) { el.remove(); });
        }
        if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", killArrows);
        else killArrows();

        new MutationObserver(function(m) {
            m.forEach(function(mutation) {
                mutation.addedNodes.forEach(function(node) {
                    if (node.classList && node.classList.contains("wp-menu-arrow")) node.remove();
                    if (node.querySelectorAll) node.querySelectorAll(".wp-menu-arrow").forEach(function(el) { el.remove(); });
                });
            });
        }).observe(document.body || document.documentElement, { childList: true, subtree: true });

        function bloquearFolded() { document.body.classList.remove("folded", "auto-fold"); }
        bloquearFolded();
        try {
            localStorage.removeItem("twc");
            Object.defineProperty(window, "wpNavMenuResizeHappened", { get: function(){ return false; }, set: function(){} });
        } catch(e) {}
        new MutationObserver(function() { bloquearFolded(); })
            .observe(document.body, { attributes: true, attributeFilter: ["class"] });
        window.addEventListener("resize", bloquearFolded, true);
    })();
    </script>';
}

// ═══════════════════════════════════════════════════════════════════════
// 10. DASHBOARD HTML
// ═══════════════════════════════════════════════════════════════════════

function renderizar_painel_customizado() {
    if ( ! current_user_can( 'manage_options' ) ) {
        wp_die( esc_html__( 'Acesso negado.', 'hoost' ) );
    }
    
    if ( ! hoost_is_main() ) return;
    ?>
    <div class="wrap wrap-hoost">
        <div class="defaultBox apresentacaoHoost">
            <h3>Bem Vindo ao Seu Painel de Controle!</h3>
            <p class="intro-text">Aqui você poderá administrar seu site de forma prática e rápida, separamos alguns passos iniciais para você começar:</p>
            <ul class="helpHoots">
                <li><a href="#"><i class="fa fa-angle-right"></i> Passo 01: Adicione seu logotipo</a></li>
                <li><a href="#"><i class="fa fa-angle-right"></i> Passo 02: Altere as cores do seu site</a></li>
                <li><a href="#"><i class="fa fa-angle-right"></i> Passo 03: Adicione imagens no slider principal</a></li>
                <li><a href="#"><i class="fa fa-angle-right"></i> Passo 04: Configure o player de seu site</a></li>
                <li><a href="#"><i class="fa fa-angle-right"></i> Passo 05: Edite Módulos em sua página inicial</a></li>
                <li><a href="#"><i class="fa fa-angle-right"></i> Passo 06: Adicione widgets em sua página inicial</a></li>
                <li><a href="#"><i class="fa fa-angle-right"></i> Passo 07: Editando as páginas</a></li>
                <li><a href="#"><i class="fa fa-angle-right"></i> Passo 08: Crie uma notícia</a></li>
                <li><a href="#"><i class="fa fa-angle-right"></i> Passo 09: Crie uma galeria de fotos</a></li>
                <li><a href="#"><i class="fa fa-angle-right"></i> Passo 10: Atualizando as DNS de seu domínio no registro.br</a></li>
            </ul>
            <p class="central-link">Tem mais tutoriais como esses em nossa <a href="#">Central de Ajuda</a> ;)</p>
        </div>
        <div class="hoost-cards">
            <div class="hoost-card"><div class="tinyBox colorPurple">
                <i class="fa fa-play-circle-o"></i>
                <h3>Central de aplicativos</h3>
                <p>Você sabia que a Hoost criou um gerador de players exclusivo só para você? Com poucos cliques você terá players incríveis. <a href="#">Saiba mais</a></p>
            </div></div>
            <div class="hoost-card"><div class="tinyBox colorYellow">
                <i class="fa fa-envelope"></i>
                <h3>Contas de E-mail</h3>
                <p>Na Hoost você conta com emails ilimitados, crie quantas contas necessitar e torne seu contato ainda mais profissional. <a href="#">Saiba mais</a></p>
            </div></div>
            <div class="hoost-card"><div class="tinyBox colorGreen">
                <i class="fa fa-question-circle"></i>
                <h3>Central de ajuda</h3>
                <p>Na Central de Ajuda você tem acesso a vários tutoriais para tirar todo proveito de nossa plataforma. <a href="#">Saiba mais</a></p>
            </div></div>
            <div class="hoost-card"><div class="tinyBox colorBlue">
                <i class="fa fa-life-ring"></i>
                <h3>Suporte Técnico</h3>
                <p>Pintou aquela dúvida? Conte com nossa equipe — abra um ticket no Suporte Técnico em sua área do cliente. <a href="#">Abra um ticket</a></p>
            </div></div>
        </div>
        <div class="hoost-footer">
            <span>© <?php echo esc_html( date('Y') ); ?> DaniloRamos serviços para internet, feito com <span style="color:#e74c3c;">❤</span></span>
            <span>Versão do sistema: 3.2, Build 3.6.0</span>
        </div>
    </div>
    <?php
}

// ═══════════════════════════════════════════════════════════════════════
// 11. LIMPEZA DE CACHE AO PUBLICAR
// ═══════════════════════════════════════════════════════════════════════

add_action( 'save_post', 'hoost_limpar_cache_admin' );
add_action( 'publish_post', 'hoost_limpar_cache_admin' );
add_action( 'delete_post', 'hoost_limpar_cache_admin' );
add_action( 'transition_post_status', 'hoost_limpar_cache_admin' );
add_action( 'wp_insert_comment', 'hoost_limpar_cache_admin' );
add_action( 'delete_comment', 'hoost_limpar_cache_admin' );
add_action( 'user_register', 'hoost_limpar_cache_admin' );
add_action( 'profile_update', 'hoost_limpar_cache_admin' );

function hoost_limpar_cache_admin() {
    delete_transient( 'hoost_admin_stats' );
}

// ═══════════════════════════════════════════════════════════════════════
// FIM DO PLUGIN
// ═══════════════════════════════════════════════════════════════════════
