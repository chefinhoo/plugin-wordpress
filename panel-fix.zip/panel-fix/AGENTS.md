# AGENTS.md — Panel Administrativo Danilo Ramos (v3.2)

Sempre responda em **português brasileiro**.

WordPress plugin — no npm, no build tools, no tests, no autoloader. PHP procedural com uma classe helper.

## Entrypoint

- `panel-administrativo.php` — plugin file, colocado em `wp-content/plugins/panel-administrativo/`
- `Network: true` no header — ativação **apenas via Network Admin** no Multisite
- Plugin se esconde da lista de plugins de subsites (`hoost_ocultar_plugin_subsites`) — normal
- Já instancia `$hoost_admin_pages` global (linhas 42-43) — não precisa recriar

## Arquitetura

- **`includes/class-admin-pages.php`** — classe `HOOST_Admin_Pages` que carrega templates + CSS/JS específicos
- **`includes/pages/`** — 13 templates: `config-*.php`, `person-*.php`
- **`assets/css/admin-style.css`** — estilos principais
- **`assets/js/admin-script.js`** — JS principal (defer + in_footer), dados via `hoostData` (`wp_localize_script`)
- **`assets/css/pages/admin-pages.css`** — estilos compartilhados entre páginas
- **`assets/css/pages/{slug}.css`** — CSS específico por página (auto-enfileirado se existir)
- **`assets/js/pages/`** — diretório vazio; infraestrutura para JS por página já pronta

## Páginas admin — padrão de template

Todas em `includes/pages/` seguem o mesmo padrão:
1. `if ( ! defined( 'ABSPATH' ) ) exit;`
2. `if ( ! current_user_can( 'manage_options' ) ) wp_die(...);`
3. Nonce: `hoost_{slug}_nonce` / `hoost_{slug}_save` — verificar com `wp_verify_nonce()`
4. Campos salvos como `hoost_{slug}_{field}` via `update_option()` / `get_option()`
5. CSS inline no final do arquivo PHP (específico da página)
6. Classes CSS: `.wrap-hoost`, `.config-card`, `.config-form`

## Post types & taxonomias

9 CPTs registrados em `registrar_funcionalidades_hoost()` em **todos os sites** (sem guard `hoost_is_main()` desde v3.2):
`noticias`, `blog`, `programacao`, `galeria_de_fotos`, `eventos`, `videos`, `equipe`, `promocoes`, `poll`

2 taxonomias hierárquicas: `categoria_noticias` (p/ `noticias`), `categoria_blog` (p/ `blog`)

## Menu — quirks importantes

- `configurar_menu_painel_hoost()` executa em `admin_menu` priority **5**
- `limpeza_extrema_menu_hoost()` executa em `admin_menu` priority **99999** — só menus na whitelist sobrevivem
- `plugins.php` e `update-core.php` são removidos explicitamente dos submenus (linhas 260-262)
- Ordenação fixa via filtro `menu_order` em `ordenar_menu_exato_hoost()` (apenas main site)
- Separadores custom injetados nas posições: 3, 21, 26, 61, 71
- Subsites têm dropdown "Novo" simplificado (sem CPTs) — via `hoost_preparar_dados_admin()`
- Plugin bloqueia menu folded (`folded`/`auto-fold` removidos via MutationObserver nas linhas 561-563)
- Dashboard redirect: `index.php` → `index.php?page=hoost-dashboard` (só no main site)

## Helper `hoost_is_main()`

Usado como guarda em várias funções (dashboard redirect, menu cleanup, reordenamento, dados JS). Retorna `true` se não for Multisite ou se for o site principal.

## Cache

- Transient: `hoost_admin_stats` — comentários/mídia/usuários (6h / 21600s)
- Invalidado em: `save_post`, `publish_post`, `delete_post`, `transition_post_status`, `wp_insert_comment`, `delete_comment`, `user_register`, `profile_update`
- Limpeza manual: `delete_transient( 'hoost_admin_stats' )`

## JS `hoostData` (via `wp_localize_script`)

Chaves disponíveis em `admin-script.js`: `adminUrl`, `avatarUrl`, `userName`, `numComments`, `numMedia`, `numUsers`, `isMain`, `siteName`, `novoLinks`, `logoutUrl`

## Dependências CDN

Bootstrap Grid 4.5.2, Font Awesome 4.7.0, Google Fonts Lato — enfileiradas em `hoost_enfileirar_estilos()`

## Após ativação

Flush rewrite rules: **Settings → Permalinks → Salvar** (ou programaticamente: option `hoost_flush_rewrite` → `'pending'`)

## Arquivos obsoletos

`README.md`, `00_INICIO_AQUI.md`, `COMECE_AQUI_PRIMEIRO.md`, `GUIA_IMPLEMENTACAO.md`, `GUIA_INTEGRACAO_COMPLETO.md`, `EXEMPLOS_SEGURANCA.md`, `RESUMO_FINAL_TUDO.txt`, `COMO_USAR_AGORA.txt`, `ARQUIVOS_CUSTOMIZACAO.md` — documentação da migração v3.1→3.2. Podem ser ignorados; o AGENTS.md é a fonte confiável.
