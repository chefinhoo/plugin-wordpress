<?php
/**
 * Template: Streaming
 * 
 * Configurações de streaming ao vivo
 * Arquivo: /includes/pages/config-streaming.php
 * 
 * @package Panel_Administrativo_Danilo_Ramos
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

if ( ! current_user_can( 'manage_options' ) ) {
    wp_die( esc_html__( 'Acesso negado.', 'hoost' ) );
}

// Salvar configurações
if ( isset( $_POST['hoost_streaming_nonce'] ) ) {
    if ( ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['hoost_streaming_nonce'] ) ), 'hoost_streaming_save' ) ) {
        wp_die( esc_html__( 'Verificação de segurança falhou.', 'hoost' ) );
    }

    $stream_url = isset( $_POST['stream_url'] ) ? esc_url_raw( wp_unslash( $_POST['stream_url'] ) ) : '';
    $stream_status = isset( $_POST['stream_status'] ) ? 1 : 0;
    $player_width = isset( $_POST['player_width'] ) ? intval( $_POST['player_width'] ) : 640;
    $player_height = isset( $_POST['player_height'] ) ? intval( $_POST['player_height'] ) : 360;
    $autoplay = isset( $_POST['autoplay'] ) ? 1 : 0;
    $mute = isset( $_POST['mute'] ) ? 1 : 0;

    update_option( 'hoost_stream_url', $stream_url );
    update_option( 'hoost_stream_status', $stream_status );
    update_option( 'hoost_player_width', $player_width );
    update_option( 'hoost_player_height', $player_height );
    update_option( 'hoost_autoplay', $autoplay );
    update_option( 'hoost_mute', $mute );

    echo '<div class="notice notice-success is-dismissible"><p>' .
        esc_html__( 'Configurações de streaming salvas com sucesso!', 'hoost' ) .
        '</p></div>';
}

$stream_url = get_option( 'hoost_stream_url', '' );
$stream_status = get_option( 'hoost_stream_status', 0 );
$player_width = get_option( 'hoost_player_width', 640 );
$player_height = get_option( 'hoost_player_height', 360 );
$autoplay = get_option( 'hoost_autoplay', 0 );
$mute = get_option( 'hoost_mute', 0 );
?>

<div class="wrap wrap-hoost config-streaming">
    <h1 class="page-title">
        <i class="dashicons dashicons-video-alt3"></i>
        <?php esc_html_e( 'Streaming ao Vivo', 'hoost' ); ?>
    </h1>

    <form method="POST" class="config-form">
        <?php wp_nonce_field( 'hoost_streaming_save', 'hoost_streaming_nonce' ); ?>

        <!-- Card: Status do Streaming -->
        <div class="config-card">
            <div class="card-header">
                <h3><?php esc_html_e( 'Status do Streaming', 'hoost' ); ?></h3>
                <p class="card-desc"><?php esc_html_e( 'Ative ou desative o streaming ao vivo no site', 'hoost' ); ?></p>
            </div>

            <div class="card-body">
                <div class="checkbox-group">
                    <div class="checkbox-item">
                        <input 
                            type="checkbox" 
                            id="stream_status" 
                            name="stream_status"
                            value="1"
                            <?php checked( $stream_status, 1 ); ?>
                        >
                        <label for="stream_status">
                            <span class="checkbox-label"><?php esc_html_e( 'Streaming Ativo', 'hoost' ); ?></span>
                            <span class="checkbox-desc"><?php esc_html_e( 'Habilitar transmissão ao vivo no site', 'hoost' ); ?></span>
                        </label>
                    </div>
                </div>

                <?php if ( $stream_status ) : ?>
                    <div class="status-indicator" style="margin-top: 15px;">
                        <span class="status-badge status-active">
                            <i class="fa fa-circle"></i>
                            <?php esc_html_e( 'Streaming está ativo', 'hoost' ); ?>
                        </span>
                    </div>
                <?php else : ?>
                    <div class="status-indicator" style="margin-top: 15px;">
                        <span class="status-badge status-inactive">
                            <i class="fa fa-circle"></i>
                            <?php esc_html_e( 'Streaming está inativo', 'hoost' ); ?>
                        </span>
                    </div>
                <?php endif; ?>
            </div>
        </div>

        <!-- Card: URL do Stream -->
        <div class="config-card">
            <div class="card-header">
                <h3><?php esc_html_e( 'URL do Stream', 'hoost' ); ?></h3>
                <p class="card-desc"><?php esc_html_e( 'Configure a URL da transmissão ao vivo', 'hoost' ); ?></p>
            </div>

            <div class="card-body">
                <div class="form-group">
                    <label for="stream_url">
                        <?php esc_html_e( 'URL do Streaming', 'hoost' ); ?>
                    </label>
                    <input 
                        type="url" 
                        id="stream_url" 
                        name="stream_url" 
                        class="form-control" 
                        value="<?php echo esc_attr( $stream_url ); ?>"
                        placeholder="https://www.youtube.com/watch?v=..."
                    >
                    <small class="form-text"><?php esc_html_e( 'URL do YouTube, Twitch ou outra plataforma de streaming', 'hoost' ); ?></small>
                </div>
            </div>
        </div>

        <!-- Card: Player Settings -->
        <div class="config-card">
            <div class="card-header">
                <h3><?php esc_html_e( 'Configurações do Player', 'hoost' ); ?></h3>
                <p class="card-desc"><?php esc_html_e( 'Ajuste as dimensões e comportamento do player', 'hoost' ); ?></p>
            </div>

            <div class="card-body">
                <div class="form-row">
                    <div class="form-group">
                        <label for="player_width">
                            <?php esc_html_e( 'Largura (px)', 'hoost' ); ?>
                        </label>
                        <input 
                            type="number" 
                            id="player_width" 
                            name="player_width" 
                            class="form-control" 
                            value="<?php echo intval( $player_width ); ?>"
                            min="320"
                            max="1920"
                        >
                    </div>

                    <div class="form-group">
                        <label for="player_height">
                            <?php esc_html_e( 'Altura (px)', 'hoost' ); ?>
                        </label>
                        <input 
                            type="number" 
                            id="player_height" 
                            name="player_height" 
                            class="form-control" 
                            value="<?php echo intval( $player_height ); ?>"
                            min="180"
                            max="1080"
                        >
                    </div>
                </div>

                <div class="checkbox-group" style="margin-top: 20px;">
                    <div class="checkbox-item">
                        <input 
                            type="checkbox" 
                            id="autoplay" 
                            name="autoplay"
                            value="1"
                            <?php checked( $autoplay, 1 ); ?>
                        >
                        <label for="autoplay">
                            <span class="checkbox-label"><?php esc_html_e( 'Reprodução Automática', 'hoost' ); ?></span>
                            <span class="checkbox-desc"><?php esc_html_e( 'Iniciar reprodução automaticamente ao carregar a página', 'hoost' ); ?></span>
                        </label>
                    </div>

                    <div class="checkbox-item">
                        <input 
                            type="checkbox" 
                            id="mute" 
                            name="mute"
                            value="1"
                            <?php checked( $mute, 1 ); ?>
                        >
                        <label for="mute">
                            <span class="checkbox-label"><?php esc_html_e( 'Mudo', 'hoost' ); ?></span>
                            <span class="checkbox-desc"><?php esc_html_e( 'Iniciar player no modo mudo', 'hoost' ); ?></span>
                        </label>
                    </div>
                </div>
            </div>
        </div>

        <!-- Card: Salvar -->
        <div class="config-card">
            <div class="card-body">
                <button type="submit" class="btn btn-primary">
                    <i class="fa fa-save"></i>
                    <?php esc_html_e( 'Salvar Configurações', 'hoost' ); ?>
                </button>
            </div>
        </div>
    </form>
</div>

<style>
.form-row {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 20px;
}

.status-badge {
    display: inline-flex;
    align-items: center;
    gap: 8px;
    padding: 8px 16px;
    border-radius: 20px;
    font-size: 13px;
    font-weight: 500;
}

.status-active {
    background: #e8f5e9;
    color: #2e7d32;
}

.status-active i {
    color: #4caf50;
    font-size: 10px;
}

.status-inactive {
    background: #fbe9e7;
    color: #c62828;
}

.status-inactive i {
    color: #ef5350;
    font-size: 10px;
}
</style>
