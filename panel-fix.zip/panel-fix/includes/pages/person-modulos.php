<?php
/**
 * Template: Módulos
 * 
 * Gerenciamento de módulos do site
 * Arquivo: /includes/pages/person-modulos.php
 * 
 * @package Panel_Administrativo_Danilo_Ramos
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

if ( ! current_user_can( 'manage_options' ) ) {
    wp_die( esc_html__( 'Acesso negado.', 'hoost' ) );
}

// Salvar configurações
if ( isset( $_POST['hoost_modulos_nonce'] ) ) {
    if ( ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['hoost_modulos_nonce'] ) ), 'hoost_modulos_save' ) ) {
        wp_die( esc_html__( 'Verificação de segurança falhou.', 'hoost' ) );
    }

    $mod_noticias = isset( $_POST['mod_noticias'] ) ? 1 : 0;
    $mod_blog = isset( $_POST['mod_blog'] ) ? 1 : 0;
    $mod_programacao = isset( $_POST['mod_programacao'] ) ? 1 : 0;
    $mod_galeria = isset( $_POST['mod_galeria'] ) ? 1 : 0;
    $mod_eventos = isset( $_POST['mod_eventos'] ) ? 1 : 0;
    $mod_videos = isset( $_POST['mod_videos'] ) ? 1 : 0;
    $mod_equipe = isset( $_POST['mod_equipe'] ) ? 1 : 0;
    $mod_promocoes = isset( $_POST['mod_promocoes'] ) ? 1 : 0;
    $mod_poll = isset( $_POST['mod_poll'] ) ? 1 : 0;
    $mod_streaming = isset( $_POST['mod_streaming'] ) ? 1 : 0;

    update_option( 'hoost_mod_noticias', $mod_noticias );
    update_option( 'hoost_mod_blog', $mod_blog );
    update_option( 'hoost_mod_programacao', $mod_programacao );
    update_option( 'hoost_mod_galeria', $mod_galeria );
    update_option( 'hoost_mod_eventos', $mod_eventos );
    update_option( 'hoost_mod_videos', $mod_videos );
    update_option( 'hoost_mod_equipe', $mod_equipe );
    update_option( 'hoost_mod_promocoes', $mod_promocoes );
    update_option( 'hoost_mod_poll', $mod_poll );
    update_option( 'hoost_mod_streaming', $mod_streaming );

    echo '<div class="notice notice-success is-dismissible"><p>' .
        esc_html__( 'Módulos atualizados com sucesso!', 'hoost' ) .
        '</p></div>';
}

$mod_noticias = get_option( 'hoost_mod_noticias', 1 );
$mod_blog = get_option( 'hoost_mod_blog', 1 );
$mod_programacao = get_option( 'hoost_mod_programacao', 1 );
$mod_galeria = get_option( 'hoost_mod_galeria', 1 );
$mod_eventos = get_option( 'hoost_mod_eventos', 1 );
$mod_videos = get_option( 'hoost_mod_videos', 1 );
$mod_equipe = get_option( 'hoost_mod_equipe', 1 );
$mod_promocoes = get_option( 'hoost_mod_promocoes', 0 );
$mod_poll = get_option( 'hoost_mod_poll', 0 );
$mod_streaming = get_option( 'hoost_mod_streaming', 0 );
?>

<div class="wrap wrap-hoost person-modulos">
    <h1 class="page-title">
        <i class="dashicons dashicons-admin-plugins"></i>
        <?php esc_html_e( 'Módulos do Site', 'hoost' ); ?>
    </h1>

    <form method="POST" class="config-form">
        <?php wp_nonce_field( 'hoost_modulos_save', 'hoost_modulos_nonce' ); ?>

        <!-- Card: Módulos de Conteúdo -->
        <div class="config-card">
            <div class="card-header">
                <h3><?php esc_html_e( 'Módulos de Conteúdo', 'hoost' ); ?></h3>
                <p class="card-desc"><?php esc_html_e_('Ative ou desative os módulos de conteúdo do site', 'hoost' ); ?></p>
            </div>

            <div class="card-body">
                <div class="modulos-grid">
                    <div class="modulo-item">
                        <div class="modulo-info">
                            <i class="fa fa-newspaper"></i>
                            <div>
                                <h4><?php esc_html_e( 'Notícias', 'hoost' ); ?></h4>
                                <p><?php esc_html_e( 'Gerenciamento de notícias', 'hoost' ); ?></p>
                            </div>
                        </div>
                        <label class="toggle-switch">
                            <input type="checkbox" name="mod_noticias" value="1" <?php checked( $mod_noticias, 1 ); ?>>
                            <span class="toggle-slider"></span>
                        </label>
                    </div>

                    <div class="modulo-item">
                        <div class="modulo-info">
                            <i class="fa fa-pencil-square"></i>
                            <div>
                                <h4><?php esc_html_e( 'Blog', 'hoost' ); ?></h4>
                                <p><?php esc_html_e( 'Gerenciamento de posts do blog', 'hoost' ); ?></p>
                            </div>
                        </div>
                        <label class="toggle-switch">
                            <input type="checkbox" name="mod_blog" value="1" <?php checked( $mod_blog, 1 ); ?>>
                            <span class="toggle-slider"></span>
                        </label>
                    </div>

                    <div class="modulo-item">
                        <div class="modulo-info">
                            <i class="fa fa-calendar"></i>
                            <div>
                                <h4><?php esc_html_e( 'Programação', 'hoost' ); ?></h4>
                                <p><?php esc_html_e( 'Gerenciamento de programação', 'hoost' ); ?></p>
                            </div>
                        </div>
                        <label class="toggle-switch">
                            <input type="checkbox" name="mod_programacao" value="1" <?php checked( $mod_programacao, 1 ); ?>>
                            <span class="toggle-slider"></span>
                        </label>
                    </div>

                    <div class="modulo-item">
                        <div class="modulo-info">
                            <i class="fa fa-images"></i>
                            <div>
                                <h4><?php esc_html_e( 'Galeria de Fotos', 'hoost' ); ?></h4>
                                <p><?php esc_html_e( 'Gerenciamento de galerias', 'hoost' ); ?></p>
                            </div>
                        </div>
                        <label class="toggle-switch">
                            <input type="checkbox" name="mod_galeria" value="1" <?php checked( $mod_galeria, 1 ); ?>>
                            <span class="toggle-slider"></span>
                        </label>
                    </div>

                    <div class="modulo-item">
                        <div class="modulo-info">
                            <i class="fa fa-calendar-check"></i>
                            <div>
                                <h4><?php esc_html_e( 'Eventos', 'hoost' ); ?></h4>
                                <p><?php esc_html_e( 'Gerenciamento de eventos', 'hoost' ); ?></p>
                            </div>
                        </div>
                        <label class="toggle-switch">
                            <input type="checkbox" name="mod_eventos" value="1" <?php checked( $mod_eventos, 1 ); ?>>
                            <span class="toggle-slider"></span>
                        </label>
                    </div>

                    <div class="modulo-item">
                        <div class="modulo-info">
                            <i class="fa fa-video"></i>
                            <div>
                                <h4><?php esc_html_e( 'Vídeos', 'hoost' ); ?></h4>
                                <p><?php esc_html_e( 'Gerenciamento de vídeos', 'hoost' ); ?></p>
                            </div>
                        </div>
                        <label class="toggle-switch">
                            <input type="checkbox" name="mod_videos" value="1" <?php checked( $mod_videos, 1 ); ?>>
                            <span class="toggle-slider"></span>
                        </label>
                    </div>
                </div>
            </div>
        </div>

        <!-- Card: Módulos Extras -->
        <div class="config-card">
            <div class="card-header">
                <h3><?php esc_html_e( 'Módulos Extras', 'hoost' ); ?></h3>
                <p class="card-desc"><?php esc_html_e( 'Módulos adicionais do site', 'hoost' ); ?></p>
            </div>

            <div class="card-body">
                <div class="modulos-grid">
                    <div class="modulo-item">
                        <div class="modulo-info">
                            <i class="fa fa-users"></i>
                            <div>
                                <h4><?php esc_html_e( 'Equipe', 'hoost' ); ?></h4>
                                <p><?php esc_html_e( 'Gerenciamento de equipe', 'hoost' ); ?></p>
                            </div>
                        </div>
                        <label class="toggle-switch">
                            <input type="checkbox" name="mod_equipe" value="1" <?php checked( $mod_equipe, 1 ); ?>>
                            <span class="toggle-slider"></span>
                        </label>
                    </div>

                    <div class="modulo-item">
                        <div class="modulo-info">
                            <i class="fa fa-gift"></i>
                            <div>
                                <h4><?php esc_html_e( 'Promoções', 'hoost' ); ?></h4>
                                <p><?php esc_html_e( 'Gerenciamento de promoções', 'hoost' ); ?></p>
                            </div>
                        </div>
                        <label class="toggle-switch">
                            <input type="checkbox" name="mod_promocoes" value="1" <?php checked( $mod_promocoes, 1 ); ?>>
                            <span class="toggle-slider"></span>
                        </label>
                    </div>

                    <div class="modulo-item">
                        <div class="modulo-info">
                            <i class="fa fa-chart-bar"></i>
                            <div>
                                <h4><?php esc_html_e( 'Enquetes', 'hoost' ); ?></h4>
                                <p><?php esc_html_e( 'Gerenciamento de enquetes', 'hoost' ); ?></p>
                            </div>
                        </div>
                        <label class="toggle-switch">
                            <input type="checkbox" name="mod_poll" value="1" <?php checked( $mod_poll, 1 ); ?>>
                            <span class="toggle-slider"></span>
                        </label>
                    </div>

                    <div class="modulo-item">
                        <div class="modulo-info">
                            <i class="fa fa-broadcast-tower"></i>
                            <div>
                                <h4><?php esc_html_e( 'Streaming', 'hoost' ); ?></h4>
                                <p><?php esc_html_e( 'Transmissão ao vivo', 'hoost' ); ?></p>
                            </div>
                        </div>
                        <label class="toggle-switch">
                            <input type="checkbox" name="mod_streaming" value="1" <?php checked( $mod_streaming, 1 ); ?>>
                            <span class="toggle-slider"></span>
                        </label>
                    </div>
                </div>
            </div>
        </div>

        <!-- Card: Salvar -->
        <div class="config-card">
            <div class="card-body">
                <button type="submit" class="btn btn-primary">
                    <i class="fa fa-save"></i>
                    <?php esc_html_e( 'Salvar Módulos', 'hoost' ); ?>
                </button>
            </div>
        </div>
    </form>
</div>

<style>
.modulos-grid {
    display: grid;
    grid-template-columns: 1fr;
    gap: 5px;
}

.modulo-item {
    display: flex;
    align-items: center;
    justify-content: space-between;
    padding: 15px;
    background: #f9f9f9;
    border: 1px solid #e0e0e0;
    border-radius: 6px;
}

.modulo-info {
    display: flex;
    align-items: center;
    gap: 15px;
}

.modulo-info i {
    font-size: 24px;
    color: #f39c12;
    width: 30px;
    text-align: center;
}

.modulo-info h4 {
    margin: 0 0 3px;
    font-size: 14px;
    color: #333;
}

.modulo-info p {
    margin: 0;
    font-size: 12px;
    color: #888;
}

.toggle-switch {
    position: relative;
    display: inline-block;
    width: 44px;
    height: 24px;
    cursor: pointer;
}

.toggle-switch input {
    display: none;
}

.toggle-slider {
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    background: #ccc;
    border-radius: 24px;
    transition: 0.3s;
}

.toggle-slider::before {
    content: "";
    position: absolute;
    width: 18px;
    height: 18px;
    left: 3px;
    bottom: 3px;
    background: #fff;
    border-radius: 50%;
    transition: 0.3s;
}

.toggle-switch input:checked + .toggle-slider {
    background: #27ae60;
}

.toggle-switch input:checked + .toggle-slider::before {
    transform: translateX(20px);
}
</style>
