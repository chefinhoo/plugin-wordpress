<?php
/**
 * Template: Avançado
 * 
 * Configurações avançadas do site
 * Arquivo: /includes/pages/config-avancado.php
 * 
 * @package Panel_Administrativo_Danilo_Ramos
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

if ( ! current_user_can( 'manage_options' ) ) {
    wp_die( esc_html__( 'Acesso negado.', 'hoost' ) );
}

// Salvar configurações
if ( isset( $_POST['hoost_avancado_nonce'] ) ) {
    if ( ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['hoost_avancado_nonce'] ) ), 'hoost_avancado_save' ) ) {
        wp_die( esc_html__( 'Verificação de segurança falhou.', 'hoost' ) );
    }

    $seo_description = isset( $_POST['seo_description'] ) ? sanitize_textarea_field( wp_unslash( $_POST['seo_description'] ) ) : '';
    $seo_keywords = isset( $_POST['seo_keywords'] ) ? sanitize_text_field( wp_unslash( $_POST['seo_keywords'] ) ) : '';
    $habilitar_seo = isset( $_POST['habilitar_seo'] ) ? 1 : 0;
    $habilitar_cache = isset( $_POST['habilitar_cache'] ) ? 1 : 0;
    $habilitar_gzip = isset( $_POST['habilitar_gzip'] ) ? 1 : 0;
    $habilitar_ssl = isset( $_POST['habilitar_ssl'] ) ? 1 : 0;
    $desabilitar_xmlrpc = isset( $_POST['desabilitar_xmlrpc'] ) ? 1 : 0;
    $desabilitar_wp_rest_api = isset( $_POST['desabilitar_wp_rest_api'] ) ? 1 : 0;

    update_option( 'hoost_seo_description', $seo_description );
    update_option( 'hoost_seo_keywords', $seo_keywords );
    update_option( 'hoost_habilitar_seo', $habilitar_seo );
    update_option( 'hoost_habilitar_cache', $habilitar_cache );
    update_option( 'hoost_habilitar_gzip', $habilitar_gzip );
    update_option( 'hoost_habilitar_ssl', $habilitar_ssl );
    update_option( 'hoost_desabilitar_xmlrpc', $desabilitar_xmlrpc );
    update_option( 'hoost_desabilitar_wp_rest_api', $desabilitar_wp_rest_api );

    echo '<div class="notice notice-success is-dismissible"><p>' .
        esc_html__( 'Configurações avançadas salvas com sucesso!', 'hoost' ) .
        '</p></div>';
}

$seo_description = get_option( 'hoost_seo_description', '' );
$seo_keywords = get_option( 'hoost_seo_keywords', '' );
$habilitar_seo = get_option( 'hoost_habilitar_seo', 1 );
$habilitar_cache = get_option( 'hoost_habilitar_cache', 0 );
$habilitar_gzip = get_option( 'hoost_habilitar_gzip', 0 );
$habilitar_ssl = get_option( 'hoost_habilitar_ssl', 0 );
$desabilitar_xmlrpc = get_option( 'hoost_desabilitar_xmlrpc', 0 );
$desabilitar_wp_rest_api = get_option( 'hoost_desabilitar_wp_rest_api', 0 );
?>

<div class="wrap wrap-hoost config-avancado">
    <h1 class="page-title">
        <i class="dashicons dashicons-admin-generic"></i>
        <?php esc_html_e( 'Configurações Avançadas', 'hoost' ); ?>
    </h1>

    <form method="POST" class="config-form">
        <?php wp_nonce_field( 'hoost_avancado_save', 'hoost_avancado_nonce' ); ?>

        <!-- Card: SEO -->
        <div class="config-card">
            <div class="card-header">
                <h3><?php esc_html_e( 'Configurações de SEO', 'hoost' ); ?></h3>
                <p class="card-desc"><?php esc_html_e( 'Configure as meta tags e otimizações para mecanismos de busca', 'hoost' ); ?></p>
            </div>

            <div class="card-body">
                <div class="checkbox-group">
                    <div class="checkbox-item">
                        <input 
                            type="checkbox" 
                            id="habilitar_seo" 
                            name="habilitar_seo"
                            value="1"
                            <?php checked( $habilitar_seo, 1 ); ?>
                        >
                        <label for="habilitar_seo">
                            <span class="checkbox-label"><?php esc_html_e( 'Habilitar SEO', 'hoost' ); ?></span>
                            <span class="checkbox-desc"><?php esc_html_e( 'Ativar funcionalidades básicas de SEO', 'hoost' ); ?></span>
                        </label>
                    </div>
                </div>

                <div class="form-group" style="margin-top: 20px;">
                    <label for="seo_description">
                        <?php esc_html_e( 'Meta Description Padrão', 'hoost' ); ?>
                    </label>
                    <textarea 
                        id="seo_description" 
                        name="seo_description" 
                        class="form-control" 
                        rows="3"
                    ><?php echo esc_textarea( $seo_description ); ?></textarea>
                    <small class="form-text"><?php esc_html_e( 'Descrição padrão para páginas que não possuem meta description própria', 'hoost' ); ?></small>
                </div>

                <div class="form-group" style="margin-top: 20px;">
                    <label for="seo_keywords">
                        <?php esc_html_e( 'Palavras-chave', 'hoost' ); ?>
                    </label>
                    <input 
                        type="text" 
                        id="seo_keywords" 
                        name="seo_keywords" 
                        class="form-control" 
                        value="<?php echo esc_attr( $seo_keywords ); ?>"
                        placeholder="palavra1, palavra2, palavra3"
                    >
                    <small class="form-text"><?php esc_html_e( 'Palavras-chave separadas por vírgula', 'hoost' ); ?></small>
                </div>
            </div>
        </div>

        <!-- Card: Performance -->
        <div class="config-card">
            <div class="card-header">
                <h3><?php esc_html_e( 'Performance', 'hoost' ); ?></h3>
                <p class="card-desc"><?php esc_html_e( 'Otimizações de performance do site', 'hoost' ); ?></p>
            </div>

            <div class="card-body">
                <div class="checkbox-group">
                    <div class="checkbox-item">
                        <input 
                            type="checkbox" 
                            id="habilitar_cache" 
                            name="habilitar_cache"
                            value="1"
                            <?php checked( $habilitar_cache, 1 ); ?>
                        >
                        <label for="habilitar_cache">
                            <span class="checkbox-label"><?php esc_html_e( 'Habilitar Cache', 'hoost' ); ?></span>
                            <span class="checkbox-desc"><?php esc_html_e( 'Ativar cache para melhorar velocidade de carregamento', 'hoost' ); ?></span>
                        </label>
                    </div>

                    <div class="checkbox-item">
                        <input 
                            type="checkbox" 
                            id="habilitar_gzip" 
                            name="habilitar_gzip"
                            value="1"
                            <?php checked( $habilitar_gzip, 1 ); ?>
                        >
                        <label for="habilitar_gzip">
                            <span class="checkbox-label"><?php esc_html_e( 'Compressão Gzip', 'hoost' ); ?></span>
                            <span class="checkbox-desc"><?php esc_html_e( 'Comprimir arquivos para reduzir largura de banda', 'hoost' ); ?></span>
                        </label>
                    </div>
                </div>
            </div>
        </div>

        <!-- Card: Segurança -->
        <div class="config-card">
            <div class="card-header">
                <h3><?php esc_html_e( 'Segurança', 'hoost' ); ?></h3>
                <p class="card-desc"><?php esc_html_e( 'Configurações de segurança do site', 'hoost' ); ?></p>
            </div>

            <div class="card-body">
                <div class="checkbox-group">
                    <div class="checkbox-item">
                        <input 
                            type="checkbox" 
                            id="habilitar_ssl" 
                            name="habilitar_ssl"
                            value="1"
                            <?php checked( $habilitar_ssl, 1 ); ?>
                        >
                        <label for="habilitar_ssl">
                            <span class="checkbox-label"><?php esc_html_e( 'Forçar SSL/HTTPS', 'hoost' ); ?></span>
                            <span class="checkbox-desc"><?php esc_html_e( 'Redirecionar todo o tráfego para HTTPS', 'hoost' ); ?></span>
                        </label>
                    </div>

                    <div class="checkbox-item">
                        <input 
                            type="checkbox" 
                            id="desabilitar_xmlrpc" 
                            name="desabilitar_xmlrpc"
                            value="1"
                            <?php checked( $desabilitar_xmlrpc, 1 ); ?>
                        >
                        <label for="desabilitar_xmlrpc">
                            <span class="checkbox-label"><?php esc_html_e( 'Desabilitar XML-RPC', 'hoost' ); ?></span>
                            <span class="checkbox-desc"><?php esc_html_e( 'Desativar XML-RPC para maior segurança', 'hoost' ); ?></span>
                        </label>
                    </div>

                    <div class="checkbox-item">
                        <input 
                            type="checkbox" 
                            id="desabilitar_wp_rest_api" 
                            name="desabilitar_wp_rest_api"
                            value="1"
                            <?php checked( $desabilitar_wp_rest_api, 1 ); ?>
                        >
                        <label for="desabilitar_wp_rest_api">
                            <span class="checkbox-label"><?php esc_html_e( 'Restringir REST API', 'hoost' ); ?></span>
                            <span class="checkbox-desc"><?php esc_html_e( 'Restringir acesso à REST API apenas para usuários autenticados', 'hoost' ); ?></span>
                        </label>
                    </div>
                </div>
            </div>
        </div>

        <!-- Card: Salvar -->
        <div class="config-card">
            <div class="card-body">
                <button type="submit" class="btn btn-primary">
                    <i class="fa fa-save"></i>
                    <?php esc_html_e( 'Salvar Configurações', 'hoost' ); ?>
                </button>
            </div>
        </div>
    </form>
</div>

<style>
.config-avancado .checkbox-group {
    display: flex;
    flex-direction: column;
    gap: 5px;
}
</style>
