<?php
/**
 * Template: Slider
 * 
 * Configurações do slider principal
 * Arquivo: /includes/pages/person-slider.php
 * 
 * @package Panel_Administrativo_Danilo_Ramos
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

if ( ! current_user_can( 'manage_options' ) ) {
    wp_die( esc_html__( 'Acesso negado.', 'hoost' ) );
}

// Salvar configurações
if ( isset( $_POST['hoost_slider_nonce'] ) ) {
    if ( ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['hoost_slider_nonce'] ) ), 'hoost_slider_save' ) ) {
        wp_die( esc_html__( 'Verificação de segurança falhou.', 'hoost' ) );
    }

    $slider_altura = isset( $_POST['slider_altura'] ) ? intval( $_POST['slider_altura'] ) : 400;
    $slider_velocidade = isset( $_POST['slider_velocidade'] ) ? intval( $_POST['slider_velocidade'] ) : 5000;
    $slider_autoplay = isset( $_POST['slider_autoplay'] ) ? 1 : 0;
    $slider_pausar_hover = isset( $_POST['slider_pausar_hover'] ) ? 1 : 0;
    $slider_navegacao = isset( $_POST['slider_navegacao'] ) ? 1 : 0;
    $slider_paginacao = isset( $_POST['slider_paginacao'] ) ? 1 : 0;
    $slider_efeito = isset( $_POST['slider_efeito'] ) ? sanitize_text_field( wp_unslash( $_POST['slider_efeito'] ) ) : 'fade';
    $slider_limit = isset( $_POST['slider_limit'] ) ? intval( $_POST['slider_limit'] ) : 5;

    update_option( 'hoost_slider_altura', $slider_altura );
    update_option( 'hoost_slider_velocidade', $slider_velocidade );
    update_option( 'hoost_slider_autoplay', $slider_autoplay );
    update_option( 'hoost_slider_pausar_hover', $slider_pausar_hover );
    update_option( 'hoost_slider_navegacao', $slider_navegacao );
    update_option( 'hoost_slider_paginacao', $slider_paginacao );
    update_option( 'hoost_slider_efeito', $slider_efeito );
    update_option( 'hoost_slider_limit', $slider_limit );

    echo '<div class="notice notice-success is-dismissible"><p>' .
        esc_html__( 'Configurações do slider salvas com sucesso!', 'hoost' ) .
        '</p></div>';
}

$slider_altura = get_option( 'hoost_slider_altura', 400 );
$slider_velocidade = get_option( 'hoost_slider_velocidade', 5000 );
$slider_autoplay = get_option( 'hoost_slider_autoplay', 1 );
$slider_pausar_hover = get_option( 'hoost_slider_pausar_hover', 1 );
$slider_navegacao = get_option( 'hoost_slider_navegacao', 1 );
$slider_paginacao = get_option( 'hoost_slider_paginacao', 1 );
$slider_efeito = get_option( 'hoost_slider_efeito', 'fade' );
$slider_limit = get_option( 'hoost_slider_limit', 5 );
?>

<div class="wrap wrap-hoost person-slider">
    <h1 class="page-title">
        <i class="dashicons dashicons-slides"></i>
        <?php esc_html_e( 'Slider Principal', 'hoost' ); ?>
    </h1>

    <form method="POST" class="config-form">
        <?php wp_nonce_field( 'hoost_slider_save', 'hoost_slider_nonce' ); ?>

        <!-- Card: Configurações de Exibição -->
        <div class="config-card">
            <div class="card-header">
                <h3><?php esc_html_e( 'Configurações de Exibição', 'hoost' ); ?></h3>
                <p class="card-desc"><?php esc_html_e( 'Ajuste a aparência e comportamento do slider', 'hoost' ); ?></p>
            </div>

            <div class="card-body">
                <div class="form-row">
                    <div class="form-group">
                        <label for="slider_altura">
                            <?php esc_html_e( 'Altura (px)', 'hoost' ); ?>
                        </label>
                        <input 
                            type="number" 
                            id="slider_altura" 
                            name="slider_altura" 
                            class="form-control" 
                            value="<?php echo intval( $slider_altura ); ?>"
                            min="200"
                            max="800"
                            step="10"
                        >
                        <small class="form-text"><?php esc_html_e( 'Altura máxima do slider', 'hoost' ); ?></small>
                    </div>

                    <div class="form-group">
                        <label for="slider_velocidade">
                            <?php esc_html_e( 'Velocidade (ms)', 'hoost' ); ?>
                        </label>
                        <input 
                            type="number" 
                            id="slider_velocidade" 
                            name="slider_velocidade" 
                            class="form-control" 
                            value="<?php echo intval( $slider_velocidade ); ?>"
                            min="1000"
                            max="15000"
                            step="500"
                        >
                        <small class="form-text"><?php esc_html_e( 'Tempo entre cada transição em milissegundos', 'hoost' ); ?></small>
                    </div>
                </div>

                <div class="form-group" style="margin-top: 20px;">
                    <label for="slider_limit">
                        <?php esc_html_e( 'Limite de Slides', 'hoost' ); ?>
                    </label>
                    <input 
                        type="number" 
                        id="slider_limit" 
                        name="slider_limit" 
                        class="form-control" 
                        value="<?php echo intval( $slider_limit ); ?>"
                        min="1"
                        max="20"
                        style="width: 100px;"
                    >
                    <small class="form-text"><?php esc_html_e( 'Número máximo de slides a serem exibidos', 'hoost' ); ?></small>
                </div>
            </div>
        </div>

        <!-- Card: Efeito e Transição -->
        <div class="config-card">
            <div class="card-header">
                <h3><?php esc_html_e( 'Efeito e Transição', 'hoost' ); ?></h3>
                <p class="card-desc"><?php esc_html_e( 'Escolha o efeito de transição entre slides', 'hoost' ); ?></p>
            </div>

            <div class="card-body">
                <div class="form-group">
                    <label for="slider_efeito">
                        <?php esc_html_e( 'Efeito de Transição', 'hoost' ); ?>
                    </label>
                    <select id="slider_efeito" name="slider_efeito" class="form-control" style="width: 200px;">
                        <option value="fade" <?php selected( $slider_efeito, 'fade' ); ?>><?php esc_html_e( 'Fade', 'hoost' ); ?></option>
                        <option value="slide" <?php selected( $slider_efeito, 'slide' ); ?>><?php esc_html_e( 'Slide', 'hoost' ); ?></option>
                        <option value="zoom" <?php selected( $slider_efeito, 'zoom' ); ?>><?php esc_html_e( 'Zoom', 'hoost' ); ?></option>
                    </select>
                </div>
            </div>
        </div>

        <!-- Card: Comportamento -->
        <div class="config-card">
            <div class="card-header">
                <h3><?php esc_html_e( 'Comportamento', 'hoost' ); ?></h3>
                <p class="card-desc"><?php esc_html_e( 'Configure o comportamento automático do slider', 'hoost' ); ?></p>
            </div>

            <div class="card-body">
                <div class="checkbox-group">
                    <div class="checkbox-item">
                        <input 
                            type="checkbox" 
                            id="slider_autoplay" 
                            name="slider_autoplay"
                            value="1"
                            <?php checked( $slider_autoplay, 1 ); ?>
                        >
                        <label for="slider_autoplay">
                            <span class="checkbox-label"><?php esc_html_e( 'Autoplay', 'hoost' ); ?></span>
                            <span class="checkbox-desc"><?php esc_html_e( 'Iniciar reprodução automática do slider', 'hoost' ); ?></span>
                        </label>
                    </div>

                    <div class="checkbox-item">
                        <input 
                            type="checkbox" 
                            id="slider_pausar_hover" 
                            name="slider_pausar_hover"
                            value="1"
                            <?php checked( $slider_pausar_hover, 1 ); ?>
                        >
                        <label for="slider_pausar_hover">
                            <span class="checkbox-label"><?php esc_html_e( 'Pausar ao Passar o Mouse', 'hoost' ); ?></span>
                            <span class="checkbox-desc"><?php esc_html_e( 'Pausar o slider quando o mouse estiver sobre ele', 'hoost' ); ?></span>
                        </label>
                    </div>

                    <div class="checkbox-item">
                        <input 
                            type="checkbox" 
                            id="slider_navegacao" 
                            name="slider_navegacao"
                            value="1"
                            <?php checked( $slider_navegacao, 1 ); ?>
                        >
                        <label for="slider_navegacao">
                            <span class="checkbox-label"><?php esc_html_e( 'Setas de Navegação', 'hoost' ); ?></span>
                            <span class="checkbox-desc"><?php esc_html_e( 'Exibir setas de navegação (anterior/próximo)', 'hoost' ); ?></span>
                        </label>
                    </div>

                    <div class="checkbox-item">
                        <input 
                            type="checkbox" 
                            id="slider_paginacao" 
                            name="slider_paginacao"
                            value="1"
                            <?php checked( $slider_paginacao, 1 ); ?>
                        >
                        <label for="slider_paginacao">
                            <span class="checkbox-label"><?php esc_html_e( 'Paginação', 'hoost' ); ?></span>
                            <span class="checkbox-desc"><?php esc_html_e( 'Exibir indicadores de paginação (bolinhas)', 'hoost' ); ?></span>
                        </label>
                    </div>
                </div>
            </div>
        </div>

        <!-- Card: Salvar -->
        <div class="config-card">
            <div class="card-body">
                <button type="submit" class="btn btn-primary">
                    <i class="fa fa-save"></i>
                    <?php esc_html_e( 'Salvar Configurações', 'hoost' ); ?>
                </button>
            </div>
        </div>
    </form>
</div>

<style>
.form-row {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 20px;
}

.person-slider .checkbox-group {
    display: flex;
    flex-direction: column;
    gap: 5px;
}
</style>
