<?php
/**
 * Template: Cores
 * 
 * Gerenciamento de cores do tema
 * Arquivo: /includes/pages/person-cores.php
 * 
 * @package Panel_Administrativo_Danilo_Ramos
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

if ( ! current_user_can( 'manage_options' ) ) {
    wp_die( esc_html__( 'Acesso negado.', 'hoost' ) );
}

// Salvar configurações
if ( isset( $_POST['hoost_cores_nonce'] ) ) {
    if ( ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['hoost_cores_nonce'] ) ), 'hoost_cores_save' ) ) {
        wp_die( esc_html__( 'Verificação de segurança falhou.', 'hoost' ) );
    }

    $cor_primaria = isset( $_POST['cor_primaria'] ) ? sanitize_hex_color( wp_unslash( $_POST['cor_primaria'] ) ) : '#f39c12';
    $cor_secundaria = isset( $_POST['cor_secundaria'] ) ? sanitize_hex_color( wp_unslash( $_POST['cor_secundaria'] ) ) : '#e74c3c';
    $cor_acento = isset( $_POST['cor_acento'] ) ? sanitize_hex_color( wp_unslash( $_POST['cor_acento'] ) ) : '#3498db';
    $cor_texto = isset( $_POST['cor_texto'] ) ? sanitize_hex_color( wp_unslash( $_POST['cor_texto'] ) ) : '#333333';
    $cor_fundo = isset( $_POST['cor_fundo'] ) ? sanitize_hex_color( wp_unslash( $_POST['cor_fundo'] ) ) : '#ffffff';
    $cor_rodape = isset( $_POST['cor_rodape'] ) ? sanitize_hex_color( wp_unslash( $_POST['cor_rodape'] ) ) : '#2c3e50';

    update_option( 'hoost_cor_primaria', $cor_primaria );
    update_option( 'hoost_cor_secundaria', $cor_secundaria );
    update_option( 'hoost_cor_acento', $cor_acento );
    update_option( 'hoost_cor_texto', $cor_texto );
    update_option( 'hoost_cor_fundo', $cor_fundo );
    update_option( 'hoost_cor_rodape', $cor_rodape );

    echo '<div class="notice notice-success is-dismissible"><p>' .
        esc_html__( 'Cores salvas com sucesso!', 'hoost' ) .
        '</p></div>';
}

$cor_primaria = get_option( 'hoost_cor_primaria', '#f39c12' );
$cor_secundaria = get_option( 'hoost_cor_secundaria', '#e74c3c' );
$cor_acento = get_option( 'hoost_cor_acento', '#3498db' );
$cor_texto = get_option( 'hoost_cor_texto', '#333333' );
$cor_fundo = get_option( 'hoost_cor_fundo', '#ffffff' );
$cor_rodape = get_option( 'hoost_cor_rodape', '#2c3e50' );
?>

<div class="wrap wrap-hoost person-cores">
    <h1 class="page-title">
        <i class="dashicons dashicons-art"></i>
        <?php esc_html_e( 'Cores do Tema', 'hoost' ); ?>
    </h1>

    <form method="POST" class="config-form">
        <?php wp_nonce_field( 'hoost_cores_save', 'hoost_cores_nonce' ); ?>

        <!-- Card: Cores Principais -->
        <div class="config-card">
            <div class="card-header">
                <h3><?php esc_html_e( 'Cores Principais', 'hoost' ); ?></h3>
                <p class="card-desc"><?php esc_html_e( 'Defina as cores principais do seu site', 'hoost' ); ?></p>
            </div>

            <div class="card-body">
                <div class="color-grid">
                    <div class="color-item">
                        <label for="cor_primaria">
                            <?php esc_html_e( 'Cor Primária', 'hoost' ); ?>
                        </label>
                        <div class="color-input-wrapper">
                            <input 
                                type="color" 
                                id="cor_primaria" 
                                name="cor_primaria" 
                                value="<?php echo esc_attr( $cor_primaria ); ?>"
                            >
                            <input 
                                type="text" 
                                class="color-hex" 
                                value="<?php echo esc_attr( $cor_primaria ); ?>"
                                readonly
                            >
                        </div>
                    </div>

                    <div class="color-item">
                        <label for="cor_secundaria">
                            <?php esc_html_e( 'Cor Secundária', 'hoost' ); ?>
                        </label>
                        <div class="color-input-wrapper">
                            <input 
                                type="color" 
                                id="cor_secundaria" 
                                name="cor_secundaria" 
                                value="<?php echo esc_attr( $cor_secundaria ); ?>"
                            >
                            <input 
                                type="text" 
                                class="color-hex" 
                                value="<?php echo esc_attr( $cor_secundaria ); ?>"
                                readonly
                            >
                        </div>
                    </div>

                    <div class="color-item">
                        <label for="cor_acento">
                            <?php esc_html_e( 'Cor de Acento', 'hoost' ); ?>
                        </label>
                        <div class="color-input-wrapper">
                            <input 
                                type="color" 
                                id="cor_acento" 
                                name="cor_acento" 
                                value="<?php echo esc_attr( $cor_acento ); ?>"
                            >
                            <input 
                                type="text" 
                                class="color-hex" 
                                value="<?php echo esc_attr( $cor_acento ); ?>"
                                readonly
                            >
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Card: Cores de Fundo e Texto -->
        <div class="config-card">
            <div class="card-header">
                <h3><?php esc_html_e( 'Cores de Fundo e Texto', 'hoost' ); ?></h3>
                <p class="card-desc"><?php esc_html_e( 'Configure as cores de fundo e texto do site', 'hoost' ); ?></p>
            </div>

            <div class="card-body">
                <div class="color-grid">
                    <div class="color-item">
                        <label for="cor_texto">
                            <?php esc_html_e( 'Cor do Texto', 'hoost' ); ?>
                        </label>
                        <div class="color-input-wrapper">
                            <input 
                                type="color" 
                                id="cor_texto" 
                                name="cor_texto" 
                                value="<?php echo esc_attr( $cor_texto ); ?>"
                            >
                            <input 
                                type="text" 
                                class="color-hex" 
                                value="<?php echo esc_attr( $cor_texto ); ?>"
                                readonly
                            >
                        </div>
                    </div>

                    <div class="color-item">
                        <label for="cor_fundo">
                            <?php esc_html_e( 'Cor de Fundo', 'hoost' ); ?>
                        </label>
                        <div class="color-input-wrapper">
                            <input 
                                type="color" 
                                id="cor_fundo" 
                                name="cor_fundo" 
                                value="<?php echo esc_attr( $cor_fundo ); ?>"
                            >
                            <input 
                                type="text" 
                                class="color-hex" 
                                value="<?php echo esc_attr( $cor_fundo ); ?>"
                                readonly
                            >
                        </div>
                    </div>

                    <div class="color-item">
                        <label for="cor_rodape">
                            <?php esc_html_e( 'Cor do Rodapé', 'hoost' ); ?>
                        </label>
                        <div class="color-input-wrapper">
                            <input 
                                type="color" 
                                id="cor_rodape" 
                                name="cor_rodape" 
                                value="<?php echo esc_attr( $cor_rodape ); ?>"
                            >
                            <input 
                                type="text" 
                                class="color-hex" 
                                value="<?php echo esc_attr( $cor_rodape ); ?>"
                                readonly
                            >
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Card: Preview -->
        <div class="config-card">
            <div class="card-header">
                <h3><?php esc_html_e( 'Preview de Cores', 'hoost' ); ?></h3>
                <p class="card-desc"><?php esc_html_e( 'Visualize as cores selecionadas', 'hoost' ); ?></p>
            </div>

            <div class="card-body">
                <div class="color-preview">
                    <div class="preview-box" style="background: <?php echo esc_attr( $cor_primaria ); ?>;">
                        <span><?php esc_html_e( 'Primária', 'hoost' ); ?></span>
                    </div>
                    <div class="preview-box" style="background: <?php echo esc_attr( $cor_secundaria ); ?>;">
                        <span><?php esc_html_e( 'Secundária', 'hoost' ); ?></span>
                    </div>
                    <div class="preview-box" style="background: <?php echo esc_attr( $cor_acento ); ?>;">
                        <span><?php esc_html_e( 'Acento', 'hoost' ); ?></span>
                    </div>
                    <div class="preview-box" style="background: <?php echo esc_attr( $cor_texto ); ?>;">
                        <span style="color: #fff;"><?php esc_html_e( 'Texto', 'hoost' ); ?></span>
                    </div>
                    <div class="preview-box" style="background: <?php echo esc_attr( $cor_fundo ); ?>; border: 1px solid #ddd;">
                        <span style="color: <?php echo esc_attr( $cor_texto ); ?>;"><?php esc_html_e( 'Fundo', 'hoost' ); ?></span>
                    </div>
                    <div class="preview-box" style="background: <?php echo esc_attr( $cor_rodape ); ?>;">
                        <span style="color: #fff;"><?php esc_html_e( 'Rodapé', 'hoost' ); ?></span>
                    </div>
                </div>
            </div>
        </div>

        <!-- Card: CSS Custom Properties -->
        <div class="config-card">
            <div class="card-header">
                <h3><?php esc_html_e( 'CSS Custom Properties', 'hoost' ); ?></h3>
                <p class="card-desc"><?php esc_html_e( 'As cores são aplicadas via variáveis CSS', 'hoost' ); ?></p>
            </div>

            <div class="card-body">
                <p><?php esc_html_e( 'As cores definidas aqui são injetadas como variáveis CSS no front-end:', 'hoost' ); ?></p>
                <pre class="css-vars-preview">
:root {
    --hoost-cor-primaria: <?php echo esc_html( $cor_primaria ); ?>;
    --hoost-cor-secundaria: <?php echo esc_html( $cor_secundaria ); ?>;
    --hoost-cor-acento: <?php echo esc_html( $cor_acento ); ?>;
    --hoost-cor-texto: <?php echo esc_html( $cor_texto ); ?>;
    --hoost-cor-fundo: <?php echo esc_html( $cor_fundo ); ?>;
    --hoost-cor-rodape: <?php echo esc_html( $cor_rodape ); ?>;
}
                </pre>
            </div>
        </div>

        <!-- Card: Salvar -->
        <div class="config-card">
            <div class="card-body">
                <button type="submit" class="btn btn-primary">
                    <i class="fa fa-save"></i>
                    <?php esc_html_e( 'Salvar Cores', 'hoost' ); ?>
                </button>
            </div>
        </div>
    </form>
</div>

<style>
.color-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
    gap: 20px;
}

.color-item label {
    display: block;
    font-size: 13px;
    font-weight: 600;
    color: #333;
    margin-bottom: 8px;
}

.color-input-wrapper {
    display: flex;
    align-items: center;
    gap: 10px;
}

.color-input-wrapper input[type="color"] {
    width: 50px;
    height: 40px;
    padding: 2px;
    border: 1px solid #ddd;
    border-radius: 4px;
    cursor: pointer;
}

.color-hex {
    width: 90px !important;
    font-family: monospace;
    font-size: 12px;
    background: #f5f5f5;
}

.color-preview {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(120px, 1fr));
    gap: 15px;
}

.preview-box {
    height: 80px;
    border-radius: 6px;
    display: flex;
    align-items: center;
    justify-content: center;
}

.preview-box span {
    font-size: 12px;
    font-weight: 600;
    color: #fff;
    text-shadow: 0 1px 2px rgba(0,0,0,0.3);
}

.css-vars-preview {
    background: #2d2d2d;
    color: #f8f8f2;
    padding: 20px;
    border-radius: 6px;
    font-size: 13px;
    line-height: 1.8;
    overflow-x: auto;
}
</style>
