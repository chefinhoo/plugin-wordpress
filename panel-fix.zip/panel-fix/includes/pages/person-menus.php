<?php
/**
 * Template: Menus
 * 
 * Configurações de menus do site
 * Arquivo: /includes/pages/person-menus.php
 * 
 * @package Panel_Administrativo_Danilo_Ramos
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

if ( ! current_user_can( 'manage_options' ) ) {
    wp_die( esc_html__( 'Acesso negado.', 'hoost' ) );
}

// Salvar configurações
if ( isset( $_POST['hoost_menus_nonce'] ) ) {
    if ( ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['hoost_menus_nonce'] ) ), 'hoost_menus_save' ) ) {
        wp_die( esc_html__( 'Verificação de segurança falhou.', 'hoost' ) );
    }

    $menu_style = isset( $_POST['menu_style'] ) ? sanitize_text_field( wp_unslash( $_POST['menu_style'] ) ) : 'horizontal';
    $menu_animation = isset( $_POST['menu_animation'] ) ? sanitize_text_field( wp_unslash( $_POST['menu_animation'] ) ) : 'fade';
    $menu_sticky = isset( $_POST['menu_sticky'] ) ? 1 : 0;
    $menu_mobile_hamburger = isset( $_POST['menu_mobile_hamburger'] ) ? 1 : 0;
    $exibir_submenus = isset( $_POST['exibir_submenus'] ) ? 1 : 0;
    $menu_velocidade = isset( $_POST['menu_velocidade'] ) ? intval( $_POST['menu_velocidade'] ) : 300;
    $menu_fonte_size = isset( $_POST['menu_fonte_size'] ) ? intval( $_POST['menu_fonte_size'] ) : 14;
    $menu_altura_item = isset( $_POST['menu_altura_item'] ) ? intval( $_POST['menu_altura_item'] ) : 50;

    update_option( 'hoost_menu_style', $menu_style );
    update_option( 'hoost_menu_animation', $menu_animation );
    update_option( 'hoost_menu_sticky', $menu_sticky );
    update_option( 'hoost_menu_mobile_hamburger', $menu_mobile_hamburger );
    update_option( 'hoost_exibir_submenus', $exibir_submenus );
    update_option( 'hoost_menu_velocidade', $menu_velocidade );
    update_option( 'hoost_menu_fonte_size', $menu_fonte_size );
    update_option( 'hoost_menu_altura_item', $menu_altura_item );

    echo '<div class="notice notice-success is-dismissible"><p>' .
        esc_html__( 'Configurações de menus salvas com sucesso!', 'hoost' ) .
        '</p></div>';
}

$menu_style = get_option( 'hoost_menu_style', 'horizontal' );
$menu_animation = get_option( 'hoost_menu_animation', 'fade' );
$menu_sticky = get_option( 'hoost_menu_sticky', 1 );
$menu_mobile_hamburger = get_option( 'hoost_menu_mobile_hamburger', 1 );
$exibir_submenus = get_option( 'hoost_exibir_submenus', 1 );
$menu_velocidade = get_option( 'hoost_menu_velocidade', 300 );
$menu_fonte_size = get_option( 'hoost_menu_fonte_size', 14 );
$menu_altura_item = get_option( 'hoost_menu_altura_item', 50 );
?>

<div class="wrap wrap-hoost person-menus">
    <h1 class="page-title">
        <i class="dashicons dashicons-menu"></i>
        <?php esc_html_e( 'Menus', 'hoost' ); ?>
    </h1>

    <form method="POST" class="config-form">
        <?php wp_nonce_field( 'hoost_menus_save', 'hoost_menus_nonce' ); ?>

        <!-- Card: Estilo do Menu -->
        <div class="config-card">
            <div class="card-header">
                <h3><?php esc_html_e( 'Estilo do Menu', 'hoost' ); ?></h3>
                <p class="card-desc"><?php esc_html_e( 'Escolha o estilo principal de navegação', 'hoost' ); ?></p>
            </div>

            <div class="card-body">
                <div class="layout-selector">
                    <label class="layout-option <?php echo $menu_style === 'horizontal' ? 'selected' : ''; ?>">
                        <input type="radio" name="menu_style" value="horizontal" <?php checked( $menu_style, 'horizontal' ); ?>>
                        <i class="fa fa-bars"></i>
                        <span><?php esc_html_e( 'Horizontal', 'hoost' ); ?></span>
                    </label>
                    <label class="layout-option <?php echo $menu_style === 'vertical' ? 'selected' : ''; ?>">
                        <input type="radio" name="menu_style" value="vertical" <?php checked( $menu_style, 'vertical' ); ?>>
                        <i class="fa fa-align-justify"></i>
                        <span><?php esc_html_e( 'Vertical', 'hoost' ); ?></span>
                    </label>
                    <label class="layout-option <?php echo $menu_style === 'compact' ? 'selected' : ''; ?>">
                        <input type="radio" name="menu_style" value="compact" <?php checked( $menu_style, 'compact' ); ?>>
                        <i class="fa fa-compress"></i>
                        <span><?php esc_html_e( 'Compacto', 'hoost' ); ?></span>
                    </label>
                </div>
            </div>
        </div>

        <!-- Card: Animação -->
        <div class="config-card">
            <div class="card-header">
                <h3><?php esc_html_e( 'Animação do Menu', 'hoost' ); ?></h3>
                <p class="card-desc"><?php esc_html_e( 'Configure as animações do menu', 'hoost' ); ?></p>
            </div>

            <div class="card-body">
                <div class="form-group">
                    <label for="menu_animation">
                        <?php esc_html_e( 'Tipo de Animação', 'hoost' ); ?>
                    </label>
                    <select id="menu_animation" name="menu_animation" class="form-control" style="width: 200px;">
                        <option value="fade" <?php selected( $menu_animation, 'fade' ); ?>><?php esc_html_e( 'Fade', 'hoost' ); ?></option>
                        <option value="slide" <?php selected( $menu_animation, 'slide' ); ?>><?php esc_html_e( 'Slide', 'hoost' ); ?></option>
                        <option value="scale" <?php selected( $menu_animation, 'scale' ); ?>><?php esc_html_e( 'Scale', 'hoost' ); ?></option>
                        <option value="none" <?php selected( $menu_animation, 'none' ); ?>><?php esc_html_e( 'Sem Animação', 'hoost' ); ?></option>
                    </select>
                </div>

                <div class="form-group" style="margin-top: 20px;">
                    <label for="menu_velocidade">
                        <?php esc_html_e( 'Velocidade da Animação (ms)', 'hoost' ); ?>
                    </label>
                    <input 
                        type="number" 
                        id="menu_velocidade" 
                        name="menu_velocidade" 
                        class="form-control" 
                        value="<?php echo intval( $menu_velocidade ); ?>"
                        min="100"
                        max="1000"
                        step="50"
                        style="width: 120px;"
                    >
                </div>

                <div class="checkbox-group" style="margin-top: 20px;">
                    <div class="checkbox-item">
                        <input 
                            type="checkbox" 
                            id="exibir_submenus" 
                            name="exibir_submenus"
                            value="1"
                            <?php checked( $exibir_submenus, 1 ); ?>
                        >
                        <label for="exibir_submenus">
                            <span class="checkbox-label"><?php esc_html_e( 'Exibir Submenus', 'hoost' ); ?></span>
                            <span class="checkbox-desc"><?php esc_html_e( 'Mostrar submenus com animação ao passar o mouse', 'hoost' ); ?></span>
                        </label>
                    </div>
                </div>
            </div>
        </div>

        <!-- Card: Comportamento -->
        <div class="config-card">
            <div class="card-header">
                <h3><?php esc_html_e( 'Comportamento', 'hoost' ); ?></h3>
                <p class="card-desc"><?php esc_html_e( 'Configure o comportamento do menu', 'hoost' ); ?></p>
            </div>

            <div class="card-body">
                <div class="checkbox-group">
                    <div class="checkbox-item">
                        <input 
                            type="checkbox" 
                            id="menu_sticky" 
                            name="menu_sticky"
                            value="1"
                            <?php checked( $menu_sticky, 1 ); ?>
                        >
                        <label for="menu_sticky">
                            <span class="checkbox-label"><?php esc_html_e( 'Menu Fixo (Sticky)', 'hoost' ); ?></span>
                            <span class="checkbox-desc"><?php esc_html_e( 'Menu permanece fixo no topo ao rolar a página', 'hoost' ); ?></span>
                        </label>
                    </div>

                    <div class="checkbox-item">
                        <input 
                            type="checkbox" 
                            id="menu_mobile_hamburger" 
                            name="menu_mobile_hamburger"
                            value="1"
                            <?php checked( $menu_mobile_hamburger, 1 ); ?>
                        >
                        <label for="menu_mobile_hamburger">
                            <span class="checkbox-label"><?php esc_html_e( 'Menu Mobile Hamburger', 'hoost' ); ?></span>
                            <span class="checkbox-desc"><?php esc_html_e( 'Usar ícone de hamburger para menu em dispositivos móveis', 'hoost' ); ?></span>
                        </label>
                    </div>
                </div>
            </div>
        </div>

        <!-- Card: Aparência -->
        <div class="config-card">
            <div class="card-header">
                <h3><?php esc_html_e( 'Aparência', 'hoost' ); ?></h3>
                <p class="card-desc"><?php esc_html_e( 'Configure dimensões dos itens do menu', 'hoost' ); ?></p>
            </div>

            <div class="card-body">
                <div class="form-row">
                    <div class="form-group">
                        <label for="menu_fonte_size">
                            <?php esc_html_e( 'Tamanho da Fonte (px)', 'hoost' ); ?>
                        </label>
                        <input 
                            type="number" 
                            id="menu_fonte_size" 
                            name="menu_fonte_size" 
                            class="form-control" 
                            value="<?php echo intval( $menu_fonte_size ); ?>"
                            min="11"
                            max="24"
                        >
                    </div>

                    <div class="form-group">
                        <label for="menu_altura_item">
                            <?php esc_html_e( 'Altura do Item (px)', 'hoost' ); ?>
                        </label>
                        <input 
                            type="number" 
                            id="menu_altura_item" 
                            name="menu_altura_item" 
                            class="form-control" 
                            value="<?php echo intval( $menu_altura_item ); ?>"
                            min="30"
                            max="80"
                        >
                    </div>
                </div>
            </div>
        </div>

        <!-- Card: Gerenciar Menus -->
        <div class="config-card">
            <div class="card-header">
                <h3><?php esc_html_e( 'Gerenciar Menus', 'hoost' ); ?></h3>
                <p class="card-desc"><?php esc_html_e( 'Acesse o gerenciador de menus do WordPress', 'hoost' ); ?></p>
            </div>

            <div class="card-body">
                <a href="<?php echo admin_url( 'nav-menus.php' ); ?>" class="btn btn-primary" target="_blank">
                    <i class="fa fa-external-link-alt"></i>
                    <?php esc_html_e( 'Ir para Menus', 'hoost' ); ?>
                </a>
                <span style="margin-left: 10px; font-size: 12px; color: #888;">
                    <?php esc_html_e( 'Abra o gerenciador de menus do WordPress', 'hoost' ); ?>
                </span>
            </div>
        </div>

        <!-- Card: Salvar -->
        <div class="config-card">
            <div class="card-body">
                <button type="submit" class="btn btn-primary">
                    <i class="fa fa-save"></i>
                    <?php esc_html_e( 'Salvar Configurações', 'hoost' ); ?>
                </button>
            </div>
        </div>
    </form>
</div>

<style>
.form-row {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 20px;
}

.layout-selector {
    display: grid;
    grid-template-columns: repeat(3, 1fr);
    gap: 15px;
}

.layout-option {
    display: flex;
    flex-direction: column;
    align-items: center;
    gap: 10px;
    padding: 25px 15px;
    background: #f9f9f9;
    border: 2px solid #e0e0e0;
    border-radius: 8px;
    cursor: pointer;
    transition: all 0.3s;
}

.layout-option:hover {
    border-color: #f39c12;
    background: #fffef9;
}

.layout-option.selected {
    border-color: #f39c12;
    background: #fffef9;
}

.layout-option input[type="radio"] {
    display: none;
}

.layout-option i {
    font-size: 36px;
    color: #333;
}

.layout-option span {
    font-size: 14px;
    font-weight: 600;
    color: #333;
}

.layout-option.selected i,
.layout-option.selected span {
    color: #f39c12;
}
</style>
