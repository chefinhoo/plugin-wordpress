<?php
/**
 * Template: Geral
 * 
 * Configurações gerais do site
 * Arquivo: /includes/pages/config-geral.php
 * 
 * @package Panel_Administrativo_Danilo_Ramos
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

if ( ! current_user_can( 'manage_options' ) ) {
    wp_die( esc_html__( 'Acesso negado.', 'hoost' ) );
}

// Salvar configurações
if ( isset( $_POST['hoost_geral_nonce'] ) ) {
    if ( ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['hoost_geral_nonce'] ) ), 'hoost_geral_save' ) ) {
        wp_die( esc_html__( 'Verificação de segurança falhou.', 'hoost' ) );
    }

    $site_title = isset( $_POST['site_title'] ) ? sanitize_text_field( wp_unslash( $_POST['site_title'] ) ) : '';
    $site_description = isset( $_POST['site_description'] ) ? sanitize_textarea_field( wp_unslash( $_POST['site_description'] ) ) : '';
    $contact_email = isset( $_POST['contact_email'] ) ? sanitize_email( wp_unslash( $_POST['contact_email'] ) ) : '';
    $exibir_wp_info = isset( $_POST['exibir_wp_info'] ) ? 1 : 0;

    update_option( 'hoost_site_title', $site_title );
    update_option( 'hoost_site_description', $site_description );
    update_option( 'hoost_contact_email', $contact_email );
    update_option( 'hoost_exibir_wp_info', $exibir_wp_info );

    echo '<div class="notice notice-success is-dismissible"><p>' .
        esc_html__( 'Configurações gerais salvas com sucesso!', 'hoost' ) .
        '</p></div>';
}

$site_title = get_option( 'hoost_site_title', get_bloginfo( 'name' ) );
$site_description = get_option( 'hoost_site_description', get_bloginfo( 'description' ) );
$contact_email = get_option( 'hoost_contact_email', get_option( 'admin_email' ) );
$exibir_wp_info = get_option( 'hoost_exibir_wp_info', 0 );
?>

<div class="wrap wrap-hoost config-geral">
    <h1 class="page-title">
        <i class="dashicons dashicons-admin-settings"></i>
        <?php esc_html_e( 'Configurações Gerais', 'hoost' ); ?>
    </h1>

    <form method="POST" class="config-form">
        <?php wp_nonce_field( 'hoost_geral_save', 'hoost_geral_nonce' ); ?>

        <!-- Card: Informações do Site -->
        <div class="config-card">
            <div class="card-header">
                <h3><?php esc_html_e( 'Informações do Site', 'hoost' ); ?></h3>
                <p class="card-desc"><?php esc_html_e( 'Configure as informações básicas do seu site', 'hoost' ); ?></p>
            </div>

            <div class="card-body">
                <div class="form-group">
                    <label for="site_title">
                        <?php esc_html_e( 'Título do Site', 'hoost' ); ?>
                    </label>
                    <input 
                        type="text" 
                        id="site_title" 
                        name="site_title" 
                        class="form-control" 
                        value="<?php echo esc_attr( $site_title ); ?>"
                    >
                    <small class="form-text"><?php esc_html_e( 'O nome do seu site', 'hoost' ); ?></small>
                </div>

                <div class="form-group" style="margin-top: 20px;">
                    <label for="site_description">
                        <?php esc_html_e( 'Descrição do Site', 'hoost' ); ?>
                    </label>
                    <textarea 
                        id="site_description" 
                        name="site_description" 
                        class="form-control" 
                        rows="3"
                    ><?php echo esc_textarea( $site_description ); ?></textarea>
                    <small class="form-text"><?php esc_html_e( 'Uma breve descrição do seu site', 'hoost' ); ?></small>
                </div>

                <div class="form-group" style="margin-top: 20px;">
                    <label for="contact_email">
                        <?php esc_html_e( 'Email de Contato', 'hoost' ); ?>
                    </label>
                    <input 
                        type="email" 
                        id="contact_email" 
                        name="contact_email" 
                        class="form-control" 
                        value="<?php echo esc_attr( $contact_email ); ?>"
                    >
                    <small class="form-text"><?php esc_html_e( 'Email principal de contato do site', 'hoost' ); ?></small>
                </div>
            </div>
        </div>

        <!-- Card: Exibição -->
        <div class="config-card">
            <div class="card-header">
                <h3><?php esc_html_e( 'Opções de Exibição', 'hoost' ); ?></h3>
                <p class="card-desc"><?php esc_html_e( 'Configure como as informações são exibidas', 'hoost' ); ?></p>
            </div>

            <div class="card-body">
                <div class="checkbox-group">
                    <div class="checkbox-item">
                        <input 
                            type="checkbox" 
                            id="exibir_wp_info" 
                            name="exibir_wp_info"
                            value="1"
                            <?php checked( $exibir_wp_info, 1 ); ?>
                        >
                        <label for="exibir_wp_info">
                            <span class="checkbox-label"><?php esc_html_e( 'Exibir Informações do WordPress', 'hoost' ); ?></span>
                            <span class="checkbox-desc"><?php esc_html_e( 'Mostrar versão do WordPress e informações do sistema no rodapé', 'hoost' ); ?></span>
                        </label>
                    </div>
                </div>
            </div>
        </div>

        <!-- Card: Informações do WordPress -->
        <div class="config-card">
            <div class="card-header">
                <h3><?php esc_html_e( 'Informações do Sistema', 'hoost' ); ?></h3>
                <p class="card-desc"><?php esc_html_e( 'Informações sobre sua instalação WordPress', 'hoost' ); ?></p>
            </div>

            <div class="card-body">
                <div class="info-grid">
                    <div class="info-item">
                        <span class="info-label"><?php esc_html_e( 'Versão do WordPress:', 'hoost' ); ?></span>
                        <span class="info-value"><?php echo esc_html( get_bloginfo( 'version' ) ); ?></span>
                    </div>
                    <div class="info-item">
                        <span class="info-label"><?php esc_html_e( 'Idioma do Site:', 'hoost' ); ?></span>
                        <span class="info-value"><?php echo esc_html( get_bloginfo( 'language' ) ); ?></span>
                    </div>
                    <div class="info-item">
                        <span class="info-label"><?php esc_html_e( 'URL do Site:', 'hoost' ); ?></span>
                        <span class="info-value"><?php echo esc_html( get_bloginfo( 'url' ) ); ?></span>
                    </div>
                    <div class="info-item">
                        <span class="info-label"><?php esc_html_e( 'Admin Email:', 'hoost' ); ?></span>
                        <span class="info-value"><?php echo esc_html( get_option( 'admin_email' ) ); ?></span>
                    </div>
                    <div class="info-item">
                        <span class="info-label"><?php esc_html_e( 'Timezone:', 'hoost' ); ?></span>
                        <span class="info-value"><?php echo esc_html( get_option( 'timezone_string' ) ?: 'UTC' ); ?></span>
                    </div>
                    <div class="info-item">
                        <span class="info-label"><?php esc_html_e( 'Formato de Data:', 'hoost' ); ?></span>
                        <span class="info-value"><?php echo esc_html( get_option( 'date_format' ) ); ?></span>
                    </div>
                </div>
            </div>
        </div>

        <!-- Card: Salvar -->
        <div class="config-card">
            <div class="card-body">
                <button type="submit" class="btn btn-primary">
                    <i class="fa fa-save"></i>
                    <?php esc_html_e( 'Salvar Configurações', 'hoost' ); ?>
                </button>
            </div>
        </div>
    </form>
</div>

<style>
.info-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
    gap: 15px;
}

.info-item {
    padding: 12px 15px;
    background: #f9f9f9;
    border-radius: 6px;
    border: 1px solid #e0e0e0;
}

.info-label {
    display: block;
    font-size: 12px;
    color: #888;
    margin-bottom: 4px;
}

.info-value {
    display: block;
    font-size: 14px;
    color: #333;
    font-weight: 500;
}
</style>
