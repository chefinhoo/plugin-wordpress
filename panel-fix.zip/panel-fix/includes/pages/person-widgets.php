<?php
/**
 * Template: Widgets
 * 
 * Configurações de áreas de widgets
 * Arquivo: /includes/pages/person-widgets.php
 * 
 * @package Panel_Administrativo_Danilo_Ramos
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

if ( ! current_user_can( 'manage_options' ) ) {
    wp_die( esc_html__( 'Acesso negado.', 'hoost' ) );
}

// Salvar configurações
if ( isset( $_POST['hoost_widgets_nonce'] ) ) {
    if ( ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['hoost_widgets_nonce'] ) ), 'hoost_widgets_save' ) ) {
        wp_die( esc_html__( 'Verificação de segurança falhou.', 'hoost' ) );
    }

    $widget_sidebar = isset( $_POST['widget_sidebar'] ) ? 1 : 0;
    $widget_footer = isset( $_POST['widget_footer'] ) ? 1 : 0;
    $widget_home = isset( $_POST['widget_home'] ) ? 1 : 0;
    $footer_columns = isset( $_POST['footer_columns'] ) ? intval( $_POST['footer_columns'] ) : 3;
    $widget_style = isset( $_POST['widget_style'] ) ? sanitize_text_field( wp_unslash( $_POST['widget_style'] ) ) : 'default';
    $exibir_titulo = isset( $_POST['exibir_titulo'] ) ? 1 : 0;
    $widget_padding = isset( $_POST['widget_padding'] ) ? intval( $_POST['widget_padding'] ) : 15;

    update_option( 'hoost_widget_sidebar', $widget_sidebar );
    update_option( 'hoost_widget_footer', $widget_footer );
    update_option( 'hoost_widget_home', $widget_home );
    update_option( 'hoost_footer_columns', $footer_columns );
    update_option( 'hoost_widget_style', $widget_style );
    update_option( 'hoost_exibir_titulo_widget', $exibir_titulo );
    update_option( 'hoost_widget_padding', $widget_padding );

    echo '<div class="notice notice-success is-dismissible"><p>' .
        esc_html__( 'Configurações de widgets salvas com sucesso!', 'hoost' ) .
        '</p></div>';
}

$widget_sidebar = get_option( 'hoost_widget_sidebar', 1 );
$widget_footer = get_option( 'hoost_widget_footer', 1 );
$widget_home = get_option( 'hoost_widget_home', 0 );
$footer_columns = get_option( 'hoost_footer_columns', 3 );
$widget_style = get_option( 'hoost_widget_style', 'default' );
$exibir_titulo = get_option( 'hoost_exibir_titulo_widget', 1 );
$widget_padding = get_option( 'hoost_widget_padding', 15 );
?>

<div class="wrap wrap-hoost person-widgets">
    <h1 class="page-title">
        <i class="dashicons dashicons-layout"></i>
        <?php esc_html_e( 'Áreas de Widgets', 'hoost' ); ?>
    </h1>

    <form method="POST" class="config-form">
        <?php wp_nonce_field( 'hoost_widgets_save', 'hoost_widgets_nonce' ); ?>

        <!-- Card: Áreas de Widget -->
        <div class="config-card">
            <div class="card-header">
                <h3><?php esc_html_e( 'Ativar Áreas de Widget', 'hoost' ); ?></h3>
                <p class="card-desc"><?php esc_html_e( 'Ative ou desative as áreas de widgets do site', 'hoost' ); ?></p>
            </div>

            <div class="card-body">
                <div class="checkbox-group">
                    <div class="checkbox-item">
                        <input 
                            type="checkbox" 
                            id="widget_sidebar" 
                            name="widget_sidebar"
                            value="1"
                            <?php checked( $widget_sidebar, 1 ); ?>
                        >
                        <label for="widget_sidebar">
                            <span class="checkbox-label"><?php esc_html_e( 'Sidebar', 'hoost' ); ?></span>
                            <span class="checkbox-desc"><?php esc_html_e( 'Ativar área de widgets na sidebar', 'hoost' ); ?></span>
                        </label>
                    </div>

                    <div class="checkbox-item">
                        <input 
                            type="checkbox" 
                            id="widget_footer" 
                            name="widget_footer"
                            value="1"
                            <?php checked( $widget_footer, 1 ); ?>
                        >
                        <label for="widget_footer">
                            <span class="checkbox-label"><?php esc_html_e( 'Rodapé', 'hoost' ); ?></span>
                            <span class="checkbox-desc"><?php esc_html_e( 'Ativar área de widgets no rodapé', 'hoost' ); ?></span>
                        </label>
                    </div>

                    <div class="checkbox-item">
                        <input 
                            type="checkbox" 
                            id="widget_home" 
                            name="widget_home"
                            value="1"
                            <?php checked( $widget_home, 1 ); ?>
                        >
                        <label for="widget_home">
                            <span class="checkbox-label"><?php esc_html_e( 'Home (Topo)', 'hoost' ); ?></span>
                            <span class="checkbox-desc"><?php esc_html_e( 'Ativar área de widgets no topo da home', 'hoost' ); ?></span>
                        </label>
                    </div>
                </div>
            </div>
        </div>

        <!-- Card: Configurações do Rodapé -->
        <div class="config-card">
            <div class="card-header">
                <h3><?php esc_html_e( 'Configurações do Rodapé', 'hoost' ); ?></h3>
                <p class="card-desc"><?php esc_html_e( 'Configure as colunas de widgets do rodapé', 'hoost' ); ?></p>
            </div>

            <div class="card-body">
                <div class="form-group">
                    <label for="footer_columns">
                        <?php esc_html_e( 'Colunas no Rodapé', 'hoost' ); ?>
                    </label>
                    <select id="footer_columns" name="footer_columns" class="form-control" style="width: 100px;">
                        <option value="1" <?php selected( $footer_columns, 1 ); ?>>1</option>
                        <option value="2" <?php selected( $footer_columns, 2 ); ?>>2</option>
                        <option value="3" <?php selected( $footer_columns, 3 ); ?>>3</option>
                        <option value="4" <?php selected( $footer_columns, 4 ); ?>>4</option>
                    </select>
                    <small class="form-text"><?php esc_html_e( 'Número de colunas para exibir widgets no rodapé', 'hoost' ); ?></small>
                </div>
            </div>
        </div>

        <!-- Card: Estilo dos Widgets -->
        <div class="config-card">
            <div class="card-header">
                <h3><?php esc_html_e( 'Estilo dos Widgets', 'hoost' ); ?></h3>
                <p class="card-desc"><?php esc_html_e( 'Personalize a aparência dos widgets', 'hoost' ); ?></p>
            </div>

            <div class="card-body">
                <div class="form-group">
                    <label for="widget_style">
                        <?php esc_html_e( 'Estilo', 'hoost' ); ?>
                    </label>
                    <select id="widget_style" name="widget_style" class="form-control" style="width: 200px;">
                        <option value="default" <?php selected( $widget_style, 'default' ); ?>><?php esc_html_e( 'Padrão', 'hoost' ); ?></option>
                        <option value="boxed" <?php selected( $widget_style, 'boxed' ); ?>><?php esc_html_e( 'Com Borda', 'hoost' ); ?></option>
                        <option value="modern" <?php selected( $widget_style, 'modern' ); ?>><?php esc_html_e( 'Moderno', 'hoost' ); ?></option>
                        <option value="minimal" <?php selected( $widget_style, 'minimal' ); ?>><?php esc_html_e( 'Minimalista', 'hoost' ); ?></option>
                    </select>
                </div>

                <div class="form-group" style="margin-top: 20px;">
                    <label for="widget_padding">
                        <?php esc_html_e( 'Padding Interno (px)', 'hoost' ); ?>
                    </label>
                    <input 
                        type="number" 
                        id="widget_padding" 
                        name="widget_padding" 
                        class="form-control" 
                        value="<?php echo intval( $widget_padding ); ?>"
                        min="5"
                        max="40"
                        style="width: 100px;"
                    >
                </div>

                <div class="checkbox-group" style="margin-top: 20px;">
                    <div class="checkbox-item">
                        <input 
                            type="checkbox" 
                            id="exibir_titulo" 
                            name="exibir_titulo"
                            value="1"
                            <?php checked( $exibir_titulo, 1 ); ?>
                        >
                        <label for="exibir_titulo">
                            <span class="checkbox-label"><?php esc_html_e( 'Exibir Títulos dos Widgets', 'hoost' ); ?></span>
                            <span class="checkbox-desc"><?php esc_html_e( 'Mostrar o título dos widgets no front-end', 'hoost' ); ?></span>
                        </label>
                    </div>
                </div>
            </div>
        </div>

        <!-- Card: Salvar -->
        <div class="config-card">
            <div class="card-body">
                <button type="submit" class="btn btn-primary">
                    <i class="fa fa-save"></i>
                    <?php esc_html_e( 'Salvar Configurações', 'hoost' ); ?>
                </button>
            </div>
        </div>
    </form>
</div>

<style>
.person-widgets .checkbox-group {
    display: flex;
    flex-direction: column;
    gap: 5px;
}
</style>
