<?php
/**
 * Template: Redes Sociais
 * 
 * Configurações de redes sociais
 * Arquivo: /includes/pages/person-redes.php
 * 
 * @package Panel_Administrativo_Danilo_Ramos
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

if ( ! current_user_can( 'manage_options' ) ) {
    wp_die( esc_html__( 'Acesso negado.', 'hoost' ) );
}

// Salvar configurações
if ( isset( $_POST['hoost_redes_nonce'] ) ) {
    if ( ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['hoost_redes_nonce'] ) ), 'hoost_redes_save' ) ) {
        wp_die( esc_html__( 'Verificação de segurança falhou.', 'hoost' ) );
    }

    $facebook = isset( $_POST['facebook'] ) ? esc_url_raw( wp_unslash( $_POST['facebook'] ) ) : '';
    $instagram = isset( $_POST['instagram'] ) ? esc_url_raw( wp_unslash( $_POST['instagram'] ) ) : '';
    $twitter = isset( $_POST['twitter'] ) ? esc_url_raw( wp_unslash( $_POST['twitter'] ) ) : '';
    $youtube = isset( $_POST['youtube'] ) ? esc_url_raw( wp_unslash( $_POST['youtube'] ) ) : '';
    $whatsapp = isset( $_POST['whatsapp'] ) ? sanitize_text_field( wp_unslash( $_POST['whatsapp'] ) ) : '';
    $linkedin = isset( $_POST['linkedin'] ) ? esc_url_raw( wp_unslash( $_POST['linkedin'] ) ) : '';
    $tiktok = isset( $_POST['tiktok'] ) ? esc_url_raw( wp_unslash( $_POST['tiktok'] ) ) : '';
    $telegram = isset( $_POST['telegram'] ) ? esc_url_raw( wp_unslash( $_POST['telegram'] ) ) : '';
    $exibir_icones = isset( $_POST['exibir_icones'] ) ? 1 : 0;
    $icone_style = isset( $_POST['icone_style'] ) ? sanitize_text_field( wp_unslash( $_POST['icone_style'] ) ) : 'colored';

    update_option( 'hoost_facebook', $facebook );
    update_option( 'hoost_instagram', $instagram );
    update_option( 'hoost_twitter', $twitter );
    update_option( 'hoost_youtube', $youtube );
    update_option( 'hoost_whatsapp', $whatsapp );
    update_option( 'hoost_linkedin', $linkedin );
    update_option( 'hoost_tiktok', $tiktok );
    update_option( 'hoost_telegram', $telegram );
    update_option( 'hoost_exibir_icones', $exibir_icones );
    update_option( 'hoost_icone_style', $icone_style );

    echo '<div class="notice notice-success is-dismissible"><p>' .
        esc_html__( 'Redes sociais salvas com sucesso!', 'hoost' ) .
        '</p></div>';
}

$facebook = get_option( 'hoost_facebook', '' );
$instagram = get_option( 'hoost_instagram', '' );
$twitter = get_option( 'hoost_twitter', '' );
$youtube = get_option( 'hoost_youtube', '' );
$whatsapp = get_option( 'hoost_whatsapp', '' );
$linkedin = get_option( 'hoost_linkedin', '' );
$tiktok = get_option( 'hoost_tiktok', '' );
$telegram = get_option( 'hoost_telegram', '' );
$exibir_icones = get_option( 'hoost_exibir_icones', 1 );
$icone_style = get_option( 'hoost_icone_style', 'colored' );
?>

<div class="wrap wrap-hoost person-redes">
    <h1 class="page-title">
        <i class="dashicons dashicons-share"></i>
        <?php esc_html_e( 'Redes Sociais', 'hoost' ); ?>
    </h1>

    <form method="POST" class="config-form">
        <?php wp_nonce_field( 'hoost_redes_save', 'hoost_redes_nonce' ); ?>

        <!-- Card: URLs das Redes Sociais -->
        <div class="config-card">
            <div class="card-header">
                <h3><?php esc_html_e( 'URLs das Redes Sociais', 'hoost' ); ?></h3>
                <p class="card-desc"><?php esc_html_e( 'Insira as URLs dos perfis do seu site nas redes sociais', 'hoost' ); ?></p>
            </div>

            <div class="card-body">
                <div class="redes-grid">
                    <div class="rede-item">
                        <div class="rede-icon" style="background: #1877f2;">
                            <i class="fa fa-facebook-f"></i>
                        </div>
                        <div class="rede-input">
                            <label for="facebook">Facebook</label>
                            <input 
                                type="url" 
                                id="facebook" 
                                name="facebook" 
                                class="form-control" 
                                value="<?php echo esc_attr( $facebook ); ?>"
                                placeholder="https://facebook.com/seuperfil"
                            >
                        </div>
                    </div>

                    <div class="rede-item">
                        <div class="rede-icon" style="background: #e4405f;">
                            <i class="fa fa-instagram"></i>
                        </div>
                        <div class="rede-input">
                            <label for="instagram">Instagram</label>
                            <input 
                                type="url" 
                                id="instagram" 
                                name="instagram" 
                                class="form-control" 
                                value="<?php echo esc_attr( $instagram ); ?>"
                                placeholder="https://instagram.com/seuperfil"
                            >
                        </div>
                    </div>

                    <div class="rede-item">
                        <div class="rede-icon" style="background: #1da1f2;">
                            <i class="fa fa-twitter"></i>
                        </div>
                        <div class="rede-input">
                            <label for="twitter">Twitter / X</label>
                            <input 
                                type="url" 
                                id="twitter" 
                                name="twitter" 
                                class="form-control" 
                                value="<?php echo esc_attr( $twitter ); ?>"
                                placeholder="https://twitter.com/seuperfil"
                            >
                        </div>
                    </div>

                    <div class="rede-item">
                        <div class="rede-icon" style="background: #ff0000;">
                            <i class="fa fa-youtube"></i>
                        </div>
                        <div class="rede-input">
                            <label for="youtube">YouTube</label>
                            <input 
                                type="url" 
                                id="youtube" 
                                name="youtube" 
                                class="form-control" 
                                value="<?php echo esc_attr( $youtube ); ?>"
                                placeholder="https://youtube.com/seucanal"
                            >
                        </div>
                    </div>

                    <div class="rede-item">
                        <div class="rede-icon" style="background: #25d366;">
                            <i class="fa fa-whatsapp"></i>
                        </div>
                        <div class="rede-input">
                            <label for="whatsapp">WhatsApp</label>
                            <input 
                                type="text" 
                                id="whatsapp" 
                                name="whatsapp" 
                                class="form-control" 
                                value="<?php echo esc_attr( $whatsapp ); ?>"
                                placeholder="5511999999999"
                            >
                            <small class="form-text"><?php esc_html_e( 'Número com código do país (apenas números)', 'hoost' ); ?></small>
                        </div>
                    </div>

                    <div class="rede-item">
                        <div class="rede-icon" style="background: #0077b5;">
                            <i class="fa fa-linkedin"></i>
                        </div>
                        <div class="rede-input">
                            <label for="linkedin">LinkedIn</label>
                            <input 
                                type="url" 
                                id="linkedin" 
                                name="linkedin" 
                                class="form-control" 
                                value="<?php echo esc_attr( $linkedin ); ?>"
                                placeholder="https://linkedin.com/company/seuperfil"
                            >
                        </div>
                    </div>

                    <div class="rede-item">
                        <div class="rede-icon" style="background: #000000;">
                            <i class="fa fa-tiktok"></i>
                        </div>
                        <div class="rede-input">
                            <label for="tiktok">TikTok</label>
                            <input 
                                type="url" 
                                id="tiktok" 
                                name="tiktok" 
                                class="form-control" 
                                value="<?php echo esc_attr( $tiktok ); ?>"
                                placeholder="https://tiktok.com/@seuperfil"
                            >
                        </div>
                    </div>

                    <div class="rede-item">
                        <div class="rede-icon" style="background: #0088cc;">
                            <i class="fa fa-telegram"></i>
                        </div>
                        <div class="rede-input">
                            <label for="telegram">Telegram</label>
                            <input 
                                type="url" 
                                id="telegram" 
                                name="telegram" 
                                class="form-control" 
                                value="<?php echo esc_attr( $telegram ); ?>"
                                placeholder="https://t.me/seucanal"
                            >
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Card: Exibição dos Ícones -->
        <div class="config-card">
            <div class="card-header">
                <h3><?php esc_html_e( 'Exibição dos Ícones', 'hoost' ); ?></h3>
                <p class="card-desc"><?php esc_html_e( 'Configure como os ícones das redes sociais são exibidos', 'hoost' ); ?></p>
            </div>

            <div class="card-body">
                <div class="checkbox-group">
                    <div class="checkbox-item">
                        <input 
                            type="checkbox" 
                            id="exibir_icones" 
                            name="exibir_icones"
                            value="1"
                            <?php checked( $exibir_icones, 1 ); ?>
                        >
                        <label for="exibir_icones">
                            <span class="checkbox-label"><?php esc_html_e( 'Exibir Ícones das Redes Sociais', 'hoost' ); ?></span>
                            <span class="checkbox-desc"><?php esc_html_e( 'Mostrar ícones no rodapé e na barra lateral', 'hoost' ); ?></span>
                        </label>
                    </div>
                </div>

                <div class="form-group" style="margin-top: 20px;">
                    <label for="icone_style">
                        <?php esc_html_e( 'Estilo dos Ícones', 'hoost' ); ?>
                    </label>
                    <select id="icone_style" name="icone_style" class="form-control" style="width: 200px;">
                        <option value="colored" <?php selected( $icone_style, 'colored' ); ?>><?php esc_html_e( 'Colorido', 'hoost' ); ?></option>
                        <option value="monochrome" <?php selected( $icone_style, 'monochrome' ); ?>><?php esc_html_e( 'Monocromático', 'hoost' ); ?></option>
                        <option value="outline" <?php selected( $icone_style, 'outline' ); ?>><?php esc_html_e( 'Contorno', 'hoost' ); ?></option>
                    </select>
                    <small class="form-text"><?php esc_html_e( 'Estilo visual dos ícones das redes sociais no site', 'hoost' ); ?></small>
                </div>
            </div>
        </div>

        <!-- Card: Salvar -->
        <div class="config-card">
            <div class="card-body">
                <button type="submit" class="btn btn-primary">
                    <i class="fa fa-save"></i>
                    <?php esc_html_e( 'Salvar Redes Sociais', 'hoost' ); ?>
                </button>
            </div>
        </div>
    </form>
</div>

<style>
.redes-grid {
    display: grid;
    grid-template-columns: 1fr;
    gap: 15px;
}

.rede-item {
    display: flex;
    align-items: flex-start;
    gap: 15px;
    padding: 15px;
    background: #f9f9f9;
    border: 1px solid #e0e0e0;
    border-radius: 6px;
}

.rede-icon {
    width: 42px;
    height: 42px;
    border-radius: 6px;
    display: flex;
    align-items: center;
    justify-content: center;
    flex-shrink: 0;
}

.rede-icon i {
    color: #fff;
    font-size: 18px;
}

.rede-input {
    flex: 1;
}

.rede-input label {
    display: block;
    font-size: 13px;
    font-weight: 600;
    color: #333;
    margin-bottom: 5px;
}

.rede-input .form-text {
    margin-top: 4px;
}
</style>
