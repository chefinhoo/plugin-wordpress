<?php
/**
 * Template: Privacidade
 * 
 * Configurações de privacidade e LGPD
 * Arquivo: /includes/pages/config-privacidade.php
 * 
 * @package Panel_Administrativo_Danilo_Ramos
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

if ( ! current_user_can( 'manage_options' ) ) {
    wp_die( esc_html__( 'Acesso negado.', 'hoost' ) );
}

// Salvar configurações
if ( isset( $_POST['hoost_privacidade_nonce'] ) ) {
    if ( ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['hoost_privacidade_nonce'] ) ), 'hoost_privacidade_save' ) ) {
        wp_die( esc_html__( 'Verificação de segurança falhou.', 'hoost' ) );
    }

    $coleta_dados = isset( $_POST['coleta_dados'] ) ? 1 : 0;
    $cookies_terceiros = isset( $_POST['cookies_terceiros'] ) ? 1 : 0;
    $analíticos = isset( $_POST['analíticos'] ) ? 1 : 0;

    update_option( 'hoost_coleta_dados', $coleta_dados );
    update_option( 'hoost_cookies_terceiros', $cookies_terceiros );
    update_option( 'hoost_analíticos', $analíticos );

    echo '<div class="notice notice-success is-dismissible"><p>' .
        esc_html__( 'Configurações de privacidade salvas com sucesso!', 'hoost' ) .
        '</p></div>';
}

$coleta_dados = get_option( 'hoost_coleta_dados', 1 );
$cookies_terceiros = get_option( 'hoost_cookies_terceiros', 0 );
$analíticos = get_option( 'hoost_analíticos', 0 );
?>

<div class="wrap wrap-hoost config-privacidade">
    <h1 class="page-title">
        <i class="dashicons dashicons-lock"></i>
        <?php esc_html_e( 'Privacidade e LGPD', 'hoost' ); ?>
    </h1>

    <form method="POST" class="config-form">
        <?php wp_nonce_field( 'hoost_privacidade_save', 'hoost_privacidade_nonce' ); ?>

        <!-- Card: Aviso de Cookies -->
        <div class="config-card">
            <div class="card-header">
                <h3><?php esc_html_e( 'Aviso de Cookies', 'hoost' ); ?></h3>
                <p class="card-desc"><?php esc_html_e( 'Configure o aviso de cookies do seu site', 'hoost' ); ?></p>
            </div>

            <div class="card-body">
                <div class="checkbox-group">
                    <div class="checkbox-item">
                        <input 
                            type="checkbox" 
                            id="mostrar_aviso_cookies" 
                            name="mostrar_aviso_cookies"
                            checked
                        >
                        <label for="mostrar_aviso_cookies">
                            <span class="checkbox-label"><?php esc_html_e( 'Exibir Aviso de Cookies', 'hoost' ); ?></span>
                            <span class="checkbox-desc"><?php esc_html_e( 'Mostrar banner informando sobre uso de cookies', 'hoost' ); ?></span>
                        </label>
                    </div>
                </div>

                <div class="form-group" style="margin-top: 20px;">
                    <label for="texto_cookies">
                        <?php esc_html_e( 'Texto do Aviso', 'hoost' ); ?>
                    </label>
                    <textarea 
                        id="texto_cookies" 
                        class="form-control" 
                        rows="4"
                    ><?php esc_html_e( 'Este site usa cookies para melhorar sua experiência. Ao continuar navegando, você concorda com o uso de cookies.', 'hoost' ); ?></textarea>
                </div>
            </div>
        </div>

        <!-- Card: Coleta de Dados -->
        <div class="config-card">
            <div class="card-header">
                <h3><?php esc_html_e( 'Coleta de Dados', 'hoost' ); ?></h3>
                <p class="card-desc"><?php esc_html_e( 'Configure como seu site coleta dados dos usuários', 'hoost' ); ?></p>
            </div>

            <div class="card-body">
                <div class="checkbox-group">
                    <div class="checkbox-item">
                        <input 
                            type="checkbox" 
                            id="coleta_dados" 
                            name="coleta_dados"
                            value="1"
                            <?php checked( $coleta_dados, 1 ); ?>
                        >
                        <label for="coleta_dados">
                            <span class="checkbox-label"><?php esc_html_e( 'Coletar Dados de Usuários', 'hoost' ); ?></span>
                            <span class="checkbox-desc"><?php esc_html_e( 'Coletar informações como email e dados de formulários', 'hoost' ); ?></span>
                        </label>
                    </div>

                    <div class="checkbox-item">
                        <input 
                            type="checkbox" 
                            id="cookies_terceiros" 
                            name="cookies_terceiros"
                            value="1"
                            <?php checked( $cookies_terceiros, 1 ); ?>
                        >
                        <label for="cookies_terceiros">
                            <span class="checkbox-label"><?php esc_html_e( 'Permitir Cookies de Terceiros', 'hoost' ); ?></span>
                            <span class="checkbox-desc"><?php esc_html_e( 'Permitir cookies de redes sociais, publicidade, etc', 'hoost' ); ?></span>
                        </label>
                    </div>

                    <div class="checkbox-item">
                        <input 
                            type="checkbox" 
                            id="analíticos" 
                            name="analíticos"
                            value="1"
                            <?php checked( $analíticos, 1 ); ?>
                        >
                        <label for="analíticos">
                            <span class="checkbox-label"><?php esc_html_e( 'Analíticos', 'hoost' ); ?></span>
                            <span class="checkbox-desc"><?php esc_html_e( 'Coletar dados de análise do comportamento do usuário', 'hoost' ); ?></span>
                        </label>
                    </div>
                </div>

                <div style="margin-top: 20px;">
                    <button type="submit" class="btn btn-primary">
                        <i class="fa fa-save"></i>
                        <?php esc_html_e( 'Salvar Configurações', 'hoost' ); ?>
                    </button>
                </div>
            </div>
        </div>

        <!-- Card: Política de Privacidade -->
        <div class="config-card">
            <div class="card-header">
                <h3><?php esc_html_e( 'Política de Privacidade', 'hoost' ); ?></h3>
                <p class="card-desc"><?php esc_html_e( 'Configure a página de política de privacidade', 'hoost' ); ?></p>
            </div>

            <div class="card-body">
                <div class="form-group">
                    <label for="pagina_privacidade">
                        <?php esc_html_e( 'Página de Privacidade', 'hoost' ); ?>
                    </label>
                    <select id="pagina_privacidade" class="form-control">
                        <option><?php esc_html_e( 'Selecione uma página', 'hoost' ); ?></option>
                        <?php
                            $pages = get_pages();
                            foreach ( $pages as $page ) {
                                echo '<option value="' . intval( $page->ID ) . '">' . esc_html( $page->post_title ) . '</option>';
                            }
                        ?>
                    </select>
                    <small class="form-text"><?php esc_html_e( 'A página selecionada será usada como Política de Privacidade', 'hoost' ); ?></small>
                </div>

                <div class="form-group" style="margin-top: 20px;">
                    <a href="<?php echo admin_url( 'admin.php?page=person-internas' ); ?>" class="btn btn-secondary">
                        <i class="fa fa-plus"></i>
                        <?php esc_html_e( 'Criar Página de Privacidade', 'hoost' ); ?>
                    </a>
                </div>
            </div>
        </div>

        <!-- Card: Direitos do Usuário (LGPD) -->
        <div class="config-card">
            <div class="card-header">
                <h3><?php esc_html_e( 'Direitos dos Usuários (LGPD)', 'hoost' ); ?></h3>
                <p class="card-desc"><?php esc_html_e( 'Implemente funcionalidades de LGPD', 'hoost' ); ?></p>
            </div>

            <div class="card-body">
                <div class="checkbox-group">
                    <div class="checkbox-item">
                        <input type="checkbox" id="direito_acesso" checked>
                        <label for="direito_acesso">
                            <span class="checkbox-label"><?php esc_html_e( 'Direito de Acesso', 'hoost' ); ?></span>
                            <span class="checkbox-desc"><?php esc_html_e( 'Permitir usuários acessarem seus dados pessoais', 'hoost' ); ?></span>
                        </label>
                    </div>

                    <div class="checkbox-item">
                        <input type="checkbox" id="direito_correcao" checked>
                        <label for="direito_correcao">
                            <span class="checkbox-label"><?php esc_html_e( 'Direito de Retificação', 'hoost' ); ?></span>
                            <span class="checkbox-desc"><?php esc_html_e( 'Permitir correção de dados pessoais', 'hoost' ); ?></span>
                        </label>
                    </div>

                    <div class="checkbox-item">
                        <input type="checkbox" id="direito_delecao" checked>
                        <label for="direito_delecao">
                            <span class="checkbox-label"><?php esc_html_e( 'Direito ao Esquecimento', 'hoost' ); ?></span>
                            <span class="checkbox-desc"><?php esc_html_e( 'Permitir exclusão de dados pessoais', 'hoost' ); ?></span>
                        </label>
                    </div>

                    <div class="checkbox-item">
                        <input type="checkbox" id="direito_portabilidade" checked>
                        <label for="direito_portabilidade">
                            <span class="checkbox-label"><?php esc_html_e( 'Portabilidade de Dados', 'hoost' ); ?></span>
                            <span class="checkbox-desc"><?php esc_html_e( 'Permitir exportação dos dados pessoais', 'hoost' ); ?></span>
                        </label>
                    </div>
                </div>
            </div>
        </div>

        <!-- Card: Informações sobre LGPD -->
        <div class="config-card">
            <div class="card-header">
                <h3><?php esc_html_e( 'Sobre LGPD', 'hoost' ); ?></h3>
            </div>

            <div class="card-body">
                <p>
                    <strong><?php esc_html_e( 'LGPD - Lei Geral de Proteção de Dados', 'hoost' ); ?></strong>
                </p>
                <p>
                    <?php esc_html_e( 'A LGPD é a legislação brasileira que regula o tratamento de dados pessoais por pessoas físicas ou jurídicas. É importante estar em conformidade com a LGPD para:' ); ?>
                </p>
                <ul class="info-list">
                    <li><?php esc_html_e( 'Proteger os dados pessoais dos usuários', 'hoost' ); ?></li>
                    <li><?php esc_html_e( 'Estar em conformidade legal', 'hoost' ); ?></li>
                    <li><?php esc_html_e( 'Manter a confiança dos usuários', 'hoost' ); ?></li>
                    <li><?php esc_html_e( 'Evitar multas e penalidades', 'hoost' ); ?></li>
                </ul>
                <p>
                    <a href="https://www.gov.br/cidadania/pt-br/acesso-a-informacao/lgpd" target="_blank" class="btn btn-secondary">
                        <i class="fa fa-external-link"></i>
                        <?php esc_html_e( 'Saiba mais sobre LGPD', 'hoost' ); ?>
                    </a>
                </p>
            </div>
        </div>
    </form>
</div>

<style>
.info-list {
    list-style: none;
    padding: 0;
    margin: 0;
}

.info-list li {
    padding: 8px 0;
    padding-left: 25px;
    position: relative;
}

.info-list li::before {
    content: "✓";
    position: absolute;
    left: 0;
    color: #27ae60;
    font-weight: bold;
}
</style>
