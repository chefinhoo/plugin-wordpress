<?php
/**
 * Template: Internas
 * 
 * Configurações de páginas internas
 * Arquivo: /includes/pages/person-internas.php
 * 
 * @package Panel_Administrativo_Danilo_Ramos
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

if ( ! current_user_can( 'manage_options' ) ) {
    wp_die( esc_html__( 'Acesso negado.', 'hoost' ) );
}

// Salvar configurações
if ( isset( $_POST['hoost_internas_nonce'] ) ) {
    if ( ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['hoost_internas_nonce'] ) ), 'hoost_internas_save' ) ) {
        wp_die( esc_html__( 'Verificação de segurança falhou.', 'hoost' ) );
    }

    $sidebar_layout = isset( $_POST['sidebar_layout'] ) ? sanitize_text_field( wp_unslash( $_POST['sidebar_layout'] ) ) : 'right';
    $exibir_breadcrumb = isset( $_POST['exibir_breadcrumb'] ) ? 1 : 0;
    $exibir_titulo_pagina = isset( $_POST['exibir_titulo_pagina'] ) ? 1 : 0;
    $exibir_data = isset( $_POST['exibir_data'] ) ? 1 : 0;
    $exibir_autor = isset( $_POST['exibir_autor'] ) ? 1 : 0;
    $largura_conteudo = isset( $_POST['largura_conteudo'] ) ? intval( $_POST['largura_conteudo'] ) : 800;
    $exibir_comentarios = isset( $_POST['exibir_comentarios'] ) ? 1 : 0;
    $template_padrao = isset( $_POST['template_padrao'] ) ? sanitize_text_field( wp_unslash( $_POST['template_padrao'] ) ) : 'default';

    update_option( 'hoost_sidebar_layout', $sidebar_layout );
    update_option( 'hoost_exibir_breadcrumb', $exibir_breadcrumb );
    update_option( 'hoost_exibir_titulo_pagina', $exibir_titulo_pagina );
    update_option( 'hoost_exibir_data', $exibir_data );
    update_option( 'hoost_exibir_autor', $exibir_autor );
    update_option( 'hoost_largura_conteudo', $largura_conteudo );
    update_option( 'hoost_exibir_comentarios', $exibir_comentarios );
    update_option( 'hoost_template_padrao', $template_padrao );

    echo '<div class="notice notice-success is-dismissible"><p>' .
        esc_html__( 'Configurações de páginas internas salvas com sucesso!', 'hoost' ) .
        '</p></div>';
}

$sidebar_layout = get_option( 'hoost_sidebar_layout', 'right' );
$exibir_breadcrumb = get_option( 'hoost_exibir_breadcrumb', 1 );
$exibir_titulo_pagina = get_option( 'hoost_exibir_titulo_pagina', 1 );
$exibir_data = get_option( 'hoost_exibir_data', 1 );
$exibir_autor = get_option( 'hoost_exibir_autor', 1 );
$largura_conteudo = get_option( 'hoost_largura_conteudo', 800 );
$exibir_comentarios = get_option( 'hoost_exibir_comentarios', 1 );
$template_padrao = get_option( 'hoost_template_padrao', 'default' );
?>

<div class="wrap wrap-hoost person-internas">
    <h1 class="page-title">
        <i class="dashicons dashicons-welcome-write-blog"></i>
        <?php esc_html_e( 'Páginas Internas', 'hoost' ); ?>
    </h1>

    <form method="POST" class="config-form">
        <?php wp_nonce_field( 'hoost_internas_save', 'hoost_internas_nonce' ); ?>

        <!-- Card: Layout Sidebar -->
        <div class="config-card">
            <div class="card-header">
                <h3><?php esc_html_e( 'Layout da Sidebar', 'hoost' ); ?></h3>
                <p class="card-desc"><?php esc_html_e( 'Configure a posição da sidebar nas páginas internas', 'hoost' ); ?></p>
            </div>

            <div class="card-body">
                <div class="layout-selector">
                    <label class="layout-option <?php echo $sidebar_layout === 'left' ? 'selected' : ''; ?>">
                        <input type="radio" name="sidebar_layout" value="left" <?php checked( $sidebar_layout, 'left' ); ?>>
                        <i class="fa fa-indent"></i>
                        <span><?php esc_html_e( 'Esquerda', 'hoost' ); ?></span>
                    </label>
                    <label class="layout-option <?php echo $sidebar_layout === 'right' ? 'selected' : ''; ?>">
                        <input type="radio" name="sidebar_layout" value="right" <?php checked( $sidebar_layout, 'right' ); ?>>
                        <i class="fa fa-dedent"></i>
                        <span><?php esc_html_e( 'Direita', 'hoost' ); ?></span>
                    </label>
                    <label class="layout-option <?php echo $sidebar_layout === 'none' ? 'selected' : ''; ?>">
                        <input type="radio" name="sidebar_layout" value="none" <?php checked( $sidebar_layout, 'none' ); ?>>
                        <i class="fa fa-align-center"></i>
                        <span><?php esc_html_e( 'Sem Sidebar', 'hoost' ); ?></span>
                    </label>
                </div>

                <div class="form-group" style="margin-top: 20px;">
                    <label for="largura_conteudo">
                        <?php esc_html_e( 'Largura do Conteúdo (px)', 'hoost' ); ?>
                    </label>
                    <input 
                        type="number" 
                        id="largura_conteudo" 
                        name="largura_conteudo" 
                        class="form-control" 
                        value="<?php echo intval( $largura_conteudo ); ?>"
                        min="600"
                        max="1400"
                        step="10"
                        style="width: 120px;"
                    >
                    <small class="form-text"><?php esc_html_e( 'Largura máxima da área de conteúdo', 'hoost' ); ?></small>
                </div>
            </div>
        </div>

        <!-- Card: Elementos da Página -->
        <div class="config-card">
            <div class="card-header">
                <h3><?php esc_html_e( 'Elementos da Página', 'hoost' ); ?></h3>
                <p class="card-desc"><?php esc_html_e( 'Configure quais elementos aparecem nas páginas internas', 'hoost' ); ?></p>
            </div>

            <div class="card-body">
                <div class="checkbox-group">
                    <div class="checkbox-item">
                        <input 
                            type="checkbox" 
                            id="exibir_breadcrumb" 
                            name="exibir_breadcrumb"
                            value="1"
                            <?php checked( $exibir_breadcrumb, 1 ); ?>
                        >
                        <label for="exibir_breadcrumb">
                            <span class="checkbox-label"><?php esc_html_e( 'Breadcrumb', 'hoost' ); ?></span>
                            <span class="checkbox-desc"><?php esc_html_e( 'Exibir navegação estrutural (breadcrumb)', 'hoost' ); ?></span>
                        </label>
                    </div>

                    <div class="checkbox-item">
                        <input 
                            type="checkbox" 
                            id="exibir_titulo_pagina" 
                            name="exibir_titulo_pagina"
                            value="1"
                            <?php checked( $exibir_titulo_pagina, 1 ); ?>
                        >
                        <label for="exibir_titulo_pagina">
                            <span class="checkbox-label"><?php esc_html_e( 'Título da Página', 'hoost' ); ?></span>
                            <span class="checkbox-desc"><?php esc_html_e( 'Exibir o título no topo da página', 'hoost' ); ?></span>
                        </label>
                    </div>

                    <div class="checkbox-item">
                        <input 
                            type="checkbox" 
                            id="exibir_data" 
                            name="exibir_data"
                            value="1"
                            <?php checked( $exibir_data, 1 ); ?>
                        >
                        <label for="exibir_data">
                            <span class="checkbox-label"><?php esc_html_e( 'Data de Publicação', 'hoost' ); ?></span>
                            <span class="checkbox-desc"><?php esc_html_e( 'Exibir data de publicação nos posts', 'hoost' ); ?></span>
                        </label>
                    </div>

                    <div class="checkbox-item">
                        <input 
                            type="checkbox" 
                            id="exibir_autor" 
                            name="exibir_autor"
                            value="1"
                            <?php checked( $exibir_autor, 1 ); ?>
                        >
                        <label for="exibir_autor">
                            <span class="checkbox-label"><?php esc_html_e( 'Autor', 'hoost' ); ?></span>
                            <span class="checkbox-desc"><?php esc_html_e( 'Exibir nome do autor nos posts', 'hoost' ); ?></span>
                        </label>
                    </div>

                    <div class="checkbox-item">
                        <input 
                            type="checkbox" 
                            id="exibir_comentarios" 
                            name="exibir_comentarios"
                            value="1"
                            <?php checked( $exibir_comentarios, 1 ); ?>
                        >
                        <label for="exibir_comentarios">
                            <span class="checkbox-label"><?php esc_html_e( 'Comentários', 'hoost' ); ?></span>
                            <span class="checkbox-desc"><?php esc_html_e( 'Exibir seção de comentários nas páginas', 'hoost' ); ?></span>
                        </label>
                    </div>
                </div>
            </div>
        </div>

        <!-- Card: Template Padrão -->
        <div class="config-card">
            <div class="card-header">
                <h3><?php esc_html_e( 'Template Padrão', 'hoost' ); ?></h3>
                <p class="card-desc"><?php esc_html_e( 'Selecione o template padrão para novas páginas', 'hoost' ); ?></p>
            </div>

            <div class="card-body">
                <div class="form-group">
                    <label for="template_padrao">
                        <?php esc_html_e( 'Template', 'hoost' ); ?>
                    </label>
                    <select id="template_padrao" name="template_padrao" class="form-control" style="width: 250px;">
                        <option value="default" <?php selected( $template_padrao, 'default' ); ?>><?php esc_html_e( 'Padrão', 'hoost' ); ?></option>
                        <option value="full-width" <?php selected( $template_padrao, 'full-width' ); ?>><?php esc_html_e( 'Largura Total', 'hoost' ); ?></option>
                        <option value="narrow" <?php selected( $template_padrao, 'narrow' ); ?>><?php esc_html_e( 'Estreito', 'hoost' ); ?></option>
                        <option value="landing" <?php selected( $template_padrao, 'landing' ); ?>><?php esc_html_e( 'Landing Page', 'hoost' ); ?></option>
                    </select>
                    <small class="form-text"><?php esc_html_e( 'Template atribuído automaticamente a novas páginas', 'hoost' ); ?></small>
                </div>
            </div>
        </div>

        <!-- Card: Salvar -->
        <div class="config-card">
            <div class="card-body">
                <button type="submit" class="btn btn-primary">
                    <i class="fa fa-save"></i>
                    <?php esc_html_e( 'Salvar Configurações', 'hoost' ); ?>
                </button>
            </div>
        </div>
    </form>
</div>

<style>
.layout-selector {
    display: grid;
    grid-template-columns: repeat(3, 1fr);
    gap: 15px;
}

.layout-option {
    display: flex;
    flex-direction: column;
    align-items: center;
    gap: 10px;
    padding: 25px 15px;
    background: #f9f9f9;
    border: 2px solid #e0e0e0;
    border-radius: 8px;
    cursor: pointer;
    transition: all 0.3s;
}

.layout-option:hover {
    border-color: #f39c12;
    background: #fffef9;
}

.layout-option.selected {
    border-color: #f39c12;
    background: #fffef9;
}

.layout-option input[type="radio"] {
    display: none;
}

.layout-option i {
    font-size: 36px;
    color: #333;
}

.layout-option span {
    font-size: 14px;
    font-weight: 600;
    color: #333;
}

.layout-option.selected i,
.layout-option.selected span {
    color: #f39c12;
}
</style>
