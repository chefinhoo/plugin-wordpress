<?php
/**
 * Template: Utilidades
 * 
 * Ferramentas úteis para administração do site
 * Arquivo: /includes/pages/config-utilidades.php
 * 
 * @package Panel_Administrativo_Danilo_Ramos
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

if ( ! current_user_can( 'manage_options' ) ) {
    wp_die( esc_html__( 'Acesso negado.', 'hoost' ) );
}
?>

<div class="wrap wrap-hoost config-utilidades">
    <h1 class="page-title">
        <i class="dashicons dashicons-admin-tools"></i>
        <?php esc_html_e( 'Utilidades', 'hoost' ); ?>
    </h1>

    <div class="utilidades-container">
        <!-- Card: Importar/Exportar -->
        <div class="config-card">
            <div class="card-header">
                <h3><?php esc_html_e( 'Importar/Exportar', 'hoost' ); ?></h3>
                <p class="card-desc"><?php esc_html_e( 'Faça backup ou importe dados do seu site', 'hoost' ); ?></p>
            </div>

            <div class="card-body">
                <div class="utilidade-item">
                    <h4><?php esc_html_e( 'Exportar Dados', 'hoost' ); ?></h4>
                    <p><?php esc_html_e( 'Fazer download dos posts, páginas e configurações', 'hoost' ); ?></p>
                    <a href="<?php echo admin_url( 'export.php' ); ?>" class="btn btn-primary">
                        <i class="fa fa-download"></i>
                        <?php esc_html_e( 'Exportar Dados', 'hoost' ); ?>
                    </a>
                </div>

                <div class="utilidade-item" style="border-top: 1px solid #e0e0e0; padding-top: 20px; margin-top: 20px;">
                    <h4><?php esc_html_e( 'Importar Dados', 'hoost' ); ?></h4>
                    <p><?php esc_html_e( 'Importar dados de outro site ou arquivo XML', 'hoost' ); ?></p>
                    <a href="<?php echo admin_url( 'import.php' ); ?>" class="btn btn-primary">
                        <i class="fa fa-upload"></i>
                        <?php esc_html_e( 'Importar Dados', 'hoost' ); ?>
                    </a>
                </div>
            </div>
        </div>

        <!-- Card: Limpeza -->
        <div class="config-card">
            <div class="card-header">
                <h3><?php esc_html_e( 'Limpeza e Manutenção', 'hoost' ); ?></h3>
                <p class="card-desc"><?php esc_html_e( 'Limpe o site de dados desnecessários', 'hoost' ); ?></p>
            </div>

            <div class="card-body">
                <div class="utilidade-item">
                    <h4><?php esc_html_e( 'Limpar Cache', 'hoost' ); ?></h4>
                    <p><?php esc_html_e( 'Remover cache temporário do site', 'hoost' ); ?></p>
                    <button class="btn btn-warning">
                        <i class="fa fa-trash"></i>
                        <?php esc_html_e( 'Limpar Cache', 'hoost' ); ?>
                    </button>
                </div>

                <div class="utilidade-item" style="border-top: 1px solid #e0e0e0; padding-top: 20px; margin-top: 20px;">
                    <h4><?php esc_html_e( 'Limpar Revisões', 'hoost' ); ?></h4>
                    <p><?php esc_html_e( 'Remover revisões antigas de posts', 'hoost' ); ?></p>
                    <button class="btn btn-warning">
                        <i class="fa fa-history"></i>
                        <?php esc_html_e( 'Limpar Revisões', 'hoost' ); ?>
                    </button>
                </div>

                <div class="utilidade-item" style="border-top: 1px solid #e0e0e0; padding-top: 20px; margin-top: 20px;">
                    <h4><?php esc_html_e( 'Otimizar Banco de Dados', 'hoost' ); ?></h4>
                    <p><?php esc_html_e( 'Otimizar tabelas do banco de dados', 'hoost' ); ?></p>
                    <button class="btn btn-warning">
                        <i class="fa fa-database"></i>
                        <?php esc_html_e( 'Otimizar', 'hoost' ); ?>
                    </button>
                </div>
            </div>
        </div>

        <!-- Card: Verificação -->
        <div class="config-card">
            <div class="card-header">
                <h3><?php esc_html_e( 'Verificação de Saúde', 'hoost' ); ?></h3>
                <p class="card-desc"><?php esc_html_e( 'Diagnosticar problemas do site', 'hoost' ); ?></p>
            </div>

            <div class="card-body">
                <div class="health-check">
                    <div class="health-item">
                        <i class="fa fa-check-circle" style="color: #27ae60; font-size: 24px;"></i>
                        <div class="health-info">
                            <h4><?php esc_html_e( 'WordPress', 'hoost' ); ?></h4>
                            <p><?php esc_html_e( 'Versão ', 'hoost' ); echo esc_html( get_bloginfo( 'version' ) ); ?></p>
                        </div>
                    </div>

                    <div class="health-item">
                        <i class="fa fa-check-circle" style="color: #27ae60; font-size: 24px;"></i>
                        <div class="health-info">
                            <h4><?php esc_html_e( 'PHP', 'hoost' ); ?></h4>
                            <p><?php esc_html_e( 'Versão ', 'hoost' ); echo esc_html( phpversion() ); ?></p>
                        </div>
                    </div>

                    <div class="health-item">
                        <i class="fa fa-check-circle" style="color: #27ae60; font-size: 24px;"></i>
                        <div class="health-info">
                            <h4><?php esc_html_e( 'SSL/HTTPS', 'hoost' ); ?></h4>
                            <p><?php echo is_ssl() ? esc_html__( 'Ativo', 'hoost' ) : esc_html__( 'Inativo', 'hoost' ); ?></p>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Card: Suporte -->
        <div class="config-card">
            <div class="card-header">
                <h3><?php esc_html_e( 'Suporte', 'hoost' ); ?></h3>
                <p class="card-desc"><?php esc_html_e( 'Obtenha ajuda quando precisar', 'hoost' ); ?></p>
            </div>

            <div class="card-body">
                <div class="support-links">
                    <a href="https://daniloramos.dev.br" target="_blank" class="support-item">
                        <i class="fa fa-globe"></i>
                        <h4><?php esc_html_e( 'Website', 'hoost' ); ?></h4>
                        <p><?php esc_html_e( 'Visitar o site oficial', 'hoost' ); ?></p>
                    </a>

                    <a href="https://daniloramos.dev.br/suporte" target="_blank" class="support-item">
                        <i class="fa fa-life-ring"></i>
                        <h4><?php esc_html_e( 'Centro de Ajuda', 'hoost' ); ?></h4>
                        <p><?php esc_html_e( 'Acessar tutoriais e documentação', 'hoost' ); ?></p>
                    </a>

                    <a href="mailto:suporte@daniloramos.dev.br" class="support-item">
                        <i class="fa fa-envelope"></i>
                        <h4><?php esc_html_e( 'Email de Suporte', 'hoost' ); ?></h4>
                        <p><?php esc_html_e( 'Entrar em contato conosco', 'hoost' ); ?></p>
                    </a>
                </div>
            </div>
        </div>
    </div>
</div>

<style>
.utilidade-item {
    padding: 20px 0;
}

.utilidade-item h4 {
    margin: 0 0 5px;
    font-size: 15px;
    color: #333;
}

.utilidade-item p {
    margin: 0 0 15px;
    font-size: 13px;
    color: #666;
}

.health-check {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
    gap: 20px;
}

.health-item {
    display: flex;
    gap: 15px;
    padding: 15px;
    background: #f9f9f9;
    border-radius: 6px;
}

.health-item i {
    flex-shrink: 0;
}

.health-info h4 {
    margin: 0 0 5px;
    font-size: 14px;
    color: #333;
}

.health-info p {
    margin: 0;
    font-size: 12px;
    color: #666;
}

.support-links {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
    gap: 15px;
}

.support-item {
    padding: 20px;
    background: #f9f9f9;
    border: 1px solid #e0e0e0;
    border-radius: 6px;
    text-align: center;
    text-decoration: none;
    color: inherit;
    transition: all 0.3s;
}

.support-item:hover {
    border-color: #f39c12;
    background: #fffef9;
}

.support-item i {
    font-size: 32px;
    color: #f39c12;
    display: block;
    margin-bottom: 10px;
}

.support-item h4 {
    margin: 0 0 5px;
    font-size: 14px;
    color: #333;
}

.support-item p {
    margin: 0;
    font-size: 12px;
    color: #666;
}
</style>
