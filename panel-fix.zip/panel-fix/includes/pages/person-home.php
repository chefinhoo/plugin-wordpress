<?php
/**
 * Template: Home
 * 
 * Configurações da página inicial
 * Arquivo: /includes/pages/person-home.php
 * 
 * @package Panel_Administrativo_Danilo_Ramos
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

if ( ! current_user_can( 'manage_options' ) ) {
    wp_die( esc_html__( 'Acesso negado.', 'hoost' ) );
}

// Salvar configurações
if ( isset( $_POST['hoost_home_nonce'] ) ) {
    if ( ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['hoost_home_nonce'] ) ), 'hoost_home_save' ) ) {
        wp_die( esc_html__( 'Verificação de segurança falhou.', 'hoost' ) );
    }

    $layout_home = isset( $_POST['layout_home'] ) ? sanitize_text_field( wp_unslash( $_POST['layout_home'] ) ) : 'grid';
    $exibir_destaques = isset( $_POST['exibir_destaques'] ) ? 1 : 0;
    $exibir_noticias = isset( $_POST['exibir_noticias'] ) ? 1 : 0;
    $exibir_blog = isset( $_POST['exibir_blog'] ) ? 1 : 0;
    $exibir_eventos = isset( $_POST['exibir_eventos'] ) ? 1 : 0;
    $posts_por_pagina = isset( $_POST['posts_por_pagina'] ) ? intval( $_POST['posts_por_pagina'] ) : 12;
    $destaques_id = isset( $_POST['destaques_id'] ) ? intval( $_POST['destaques_id'] ) : 0;

    update_option( 'hoost_layout_home', $layout_home );
    update_option( 'hoost_exibir_destaques', $exibir_destaques );
    update_option( 'hoost_exibir_noticias', $exibir_noticias );
    update_option( 'hoost_exibir_blog', $exibir_blog );
    update_option( 'hoost_exibir_eventos', $exibir_eventos );
    update_option( 'hoost_posts_por_pagina', $posts_por_pagina );
    update_option( 'hoost_destaques_id', $destaques_id );

    echo '<div class="notice notice-success is-dismissible"><p>' .
        esc_html__( 'Configurações da página inicial salvas com sucesso!', 'hoost' ) .
        '</p></div>';
}

$layout_home = get_option( 'hoost_layout_home', 'grid' );
$exibir_destaques = get_option( 'hoost_exibir_destaques', 1 );
$exibir_noticias = get_option( 'hoost_exibir_noticias', 1 );
$exibir_blog = get_option( 'hoost_exibir_blog', 1 );
$exibir_eventos = get_option( 'hoost_exibir_eventos', 1 );
$posts_por_pagina = get_option( 'hoost_posts_por_pagina', 12 );
$destaques_id = get_option( 'hoost_destaques_id', 0 );
?>

<div class="wrap wrap-hoost person-home">
    <h1 class="page-title">
        <i class="dashicons dashicons-admin-home"></i>
        <?php esc_html_e( 'Página Inicial', 'hoost' ); ?>
    </h1>

    <form method="POST" class="config-form">
        <?php wp_nonce_field( 'hoost_home_save', 'hoost_home_nonce' ); ?>

        <!-- Card: Layout da Home -->
        <div class="config-card">
            <div class="card-header">
                <h3><?php esc_html_e( 'Layout da Página Inicial', 'hoost' ); ?></h3>
                <p class="card-desc"><?php esc_html_e( 'Escolha o layout principal da sua home', 'hoost' ); ?></p>
            </div>

            <div class="card-body">
                <div class="layout-selector">
                    <label class="layout-option <?php echo $layout_home === 'grid' ? 'selected' : ''; ?>">
                        <input type="radio" name="layout_home" value="grid" <?php checked( $layout_home, 'grid' ); ?>>
                        <i class="fa fa-th-large"></i>
                        <span><?php esc_html_e( 'Grid', 'hoost' ); ?></span>
                    </label>
                    <label class="layout-option <?php echo $layout_home === 'list' ? 'selected' : ''; ?>">
                        <input type="radio" name="layout_home" value="list" <?php checked( $layout_home, 'list' ); ?>>
                        <i class="fa fa-list"></i>
                        <span><?php esc_html_e( 'Lista', 'hoost' ); ?></span>
                    </label>
                    <label class="layout-option <?php echo $layout_home === 'masonry' ? 'selected' : ''; ?>">
                        <input type="radio" name="layout_home" value="masonry" <?php checked( $layout_home, 'masonry' ); ?>>
                        <i class="fa fa-columns"></i>
                        <span><?php esc_html_e( 'Masonry', 'hoost' ); ?></span>
                    </label>
                </div>

                <div class="form-group" style="margin-top: 20px;">
                    <label for="posts_por_pagina">
                        <?php esc_html_e( 'Posts por Página', 'hoost' ); ?>
                    </label>
                    <input 
                        type="number" 
                        id="posts_por_pagina" 
                        name="posts_por_pagina" 
                        class="form-control" 
                        value="<?php echo intval( $posts_por_pagina ); ?>"
                        min="3"
                        max="60"
                        style="width: 100px;"
                    >
                    <small class="form-text"><?php esc_html_e( 'Quantidade de itens exibidos por página', 'hoost' ); ?></small>
                </div>
            </div>
        </div>

        <!-- Card: Seções da Home -->
        <div class="config-card">
            <div class="card-header">
                <h3><?php esc_html_e( 'Seções da Home', 'hoost' ); ?></h3>
                <p class="card-desc"><?php esc_html_e( 'Ative ou desative as seções da página inicial', 'hoost' ); ?></p>
            </div>

            <div class="card-body">
                <div class="checkbox-group">
                    <div class="checkbox-item">
                        <input 
                            type="checkbox" 
                            id="exibir_destaques" 
                            name="exibir_destaques"
                            value="1"
                            <?php checked( $exibir_destaques, 1 ); ?>
                        >
                        <label for="exibir_destaques">
                            <span class="checkbox-label"><?php esc_html_e( 'Seção de Destaques', 'hoost' ); ?></span>
                            <span class="checkbox-desc"><?php esc_html_e( 'Exibir banner ou slideshow de destaques', 'hoost' ); ?></span>
                        </label>
                    </div>

                    <div class="checkbox-item">
                        <input 
                            type="checkbox" 
                            id="exibir_noticias" 
                            name="exibir_noticias"
                            value="1"
                            <?php checked( $exibir_noticias, 1 ); ?>
                        >
                        <label for="exibir_noticias">
                            <span class="checkbox-label"><?php esc_html_e( 'Seção de Notícias', 'hoost' ); ?></span>
                            <span class="checkbox-desc"><?php esc_html_e( 'Exibir últimas notícias na home', 'hoost' ); ?></span>
                        </label>
                    </div>

                    <div class="checkbox-item">
                        <input 
                            type="checkbox" 
                            id="exibir_blog" 
                            name="exibir_blog"
                            value="1"
                            <?php checked( $exibir_blog, 1 ); ?>
                        >
                        <label for="exibir_blog">
                            <span class="checkbox-label"><?php esc_html_e( 'Seção do Blog', 'hoost' ); ?></span>
                            <span class="checkbox-desc"><?php esc_html_e( 'Exibir posts do blog na home', 'hoost' ); ?></span>
                        </label>
                    </div>

                    <div class="checkbox-item">
                        <input 
                            type="checkbox" 
                            id="exibir_eventos" 
                            name="exibir_eventos"
                            value="1"
                            <?php checked( $exibir_eventos, 1 ); ?>
                        >
                        <label for="exibir_eventos">
                            <span class="checkbox-label"><?php esc_html_e( 'Seção de Eventos', 'hoost' ); ?></span>
                            <span class="checkbox-desc"><?php esc_html_e( 'Exibir próximos eventos na home', 'hoost' ); ?></span>
                        </label>
                    </div>
                </div>
            </div>
        </div>

        <!-- Card: Conteúdo em Destaque -->
        <div class="config-card">
            <div class="card-header">
                <h3><?php esc_html_e( 'Conteúdo em Destaque', 'hoost' ); ?></h3>
                <p class="card-desc"><?php esc_html_e( 'Selecione qual conteúdo aparecerá como destaque principal', 'hoost' ); ?></p>
            </div>

            <div class="card-body">
                <div class="form-group">
                    <label for="destaques_id">
                        <?php esc_html_e( 'Destaque Principal', 'hoost' ); ?>
                    </label>
                    <select id="destaques_id" name="destaques_id" class="form-control">
                        <option value="0"><?php esc_html_e( 'Nenhum', 'hoost' ); ?></option>
                        <?php
                            $posts_destaque = get_posts( array(
                                'post_type' => 'noticias',
                                'numberposts' => 10,
                            ) );
                            foreach ( $posts_destaque as $post_item ) {
                                $selected = selected( $destaques_id, $post_item->ID, false );
                                echo '<option value="' . intval( $post_item->ID ) . '" ' . $selected . '>' .
                                    esc_html( $post_item->post_title ) . '</option>';
                            }
                        ?>
                    </select>
                    <small class="form-text"><?php esc_html_e( 'Selecione uma notícia para ser o destaque principal', 'hoost' ); ?></small>
                </div>
            </div>
        </div>

        <!-- Card: Salvar -->
        <div class="config-card">
            <div class="card-body">
                <button type="submit" class="btn btn-primary">
                    <i class="fa fa-save"></i>
                    <?php esc_html_e( 'Salvar Configurações', 'hoost' ); ?>
                </button>
            </div>
        </div>
    </form>
</div>

<style>
.layout-selector {
    display: grid;
    grid-template-columns: repeat(3, 1fr);
    gap: 15px;
}

.layout-option {
    display: flex;
    flex-direction: column;
    align-items: center;
    gap: 10px;
    padding: 25px 15px;
    background: #f9f9f9;
    border: 2px solid #e0e0e0;
    border-radius: 8px;
    cursor: pointer;
    transition: all 0.3s;
}

.layout-option:hover {
    border-color: #f39c12;
    background: #fffef9;
}

.layout-option.selected {
    border-color: #f39c12;
    background: #fffef9;
}

.layout-option input[type="radio"] {
    display: none;
}

.layout-option i {
    font-size: 36px;
    color: #333;
}

.layout-option span {
    font-size: 14px;
    font-weight: 600;
    color: #333;
}

.layout-option.selected i,
.layout-option.selected span {
    color: #f39c12;
}
</style>
