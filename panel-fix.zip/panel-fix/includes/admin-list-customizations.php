<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Customizações da lista administrativa de Notícias e Blog
 * Integração completa com Yoast SEO (wpseo_linkdex, wpseo_content_score, etc.)
 * Visual idêntico ao painel de referência (imagens de design).
 */

// ── Registra filtros/actions para noticias e blog ────────────────────────────
function hoost_register_custom_columns_for_cpts() {
    foreach ( [ 'noticias', 'blog' ] as $cpt ) {
        add_filter( "manage_edit-{$cpt}_columns",          'hoost_cpt_columns' );
        add_action( "manage_{$cpt}_posts_custom_column",   'hoost_cpt_custom_column', 10, 2 );
        add_filter( "manage_edit-{$cpt}_sortable_columns", 'hoost_cpt_sortable_columns' );
    }

    add_action( 'restrict_manage_posts', 'hoost_render_filter_dropdowns' );
    add_action( 'pre_get_posts',         'hoost_apply_filter_to_query' );
    add_action( 'admin_enqueue_scripts', 'hoost_enqueue_list_assets' );
}
add_action( 'admin_init', 'hoost_register_custom_columns_for_cpts' );

// ── Enfileirar CSS + JS apenas nas telas corretas ────────────────────────────
function hoost_enqueue_list_assets( $hook ) {
    $screen = get_current_screen();
    if ( ! $screen ) return;

    // Página de lista de notícias/blog (edit.php?post_type=noticias)
    if ( in_array( $screen->post_type, [ 'noticias', 'blog' ], true ) && $screen->base === 'edit' ) {
        wp_enqueue_style(
            'hoost-edit-noticias',
            HOOST_PLUGIN_URL . 'assets/css/pages/edit-noticias.css',
            [ 'hoost-admin-style' ],
            HOOST_PLUGIN_VERSION
        );
        wp_enqueue_script(
            'hoost-edit-noticias-js',
            HOOST_PLUGIN_URL . 'assets/js/pages/edit-noticias.js',
            [],
            HOOST_PLUGIN_VERSION,
            true
        );
    }

    // Página de categorias (edit-tags.php) — taxonomias de notícias e blog
    $taxonomias_noticias = [ 'noticia', 'categoria_noticias', 'noticias' ];
    $taxonomias_blog     = [ 'categoria_blog', 'blog' ];
    $todas_taxonomias    = array_merge( $taxonomias_noticias, $taxonomias_blog );

    if ( $screen->base === 'edit-tags' && in_array( $screen->taxonomy, $todas_taxonomias, true ) ) {
        wp_enqueue_style(
            'hoost-edit-categorias',
            HOOST_PLUGIN_URL . 'assets/css/pages/edit-categorias.css',
            [ 'hoost-admin-style' ],
            HOOST_PLUGIN_VERSION
        );
        wp_enqueue_script(
            'hoost-edit-categorias-js',
            HOOST_PLUGIN_URL . 'assets/js/pages/edit-categorias.js',
            [],
            HOOST_PLUGIN_VERSION,
            true
        );
    }
}

// ── Definição das colunas ────────────────────────────────────────────────────
function hoost_cpt_columns( $columns ) {
    $new = [];

    if ( isset( $columns['cb'] ) )    $new['cb']    = $columns['cb'];
    if ( isset( $columns['title'] ) ) $new['title'] = $columns['title'];

    // Colunas de comentários (ícone de balão nativo do WP)
    $new['comments'] = isset( $columns['comments'] )
        ? $columns['comments']
        : '<span class="vers comment-grey-bubble" title="' . esc_attr__( 'Comentários' ) . '"><span class="screen-reader-text">' . esc_html__( 'Comentários' ) . '</span></span>';

    if ( isset( $columns['date'] ) )  $new['date']  = $columns['date'];

    // Colunas de links internos (entrada + saída) — ícones idênticos ao Yoast
    $new['wpseo_links'] = sprintf(
        '<span class="hoost-col-icon" title="%s"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path d="M12.293 5.293a1 1 0 0 1 1.414 0l5 5a1 1 0 0 1 0 1.414l-5 5a1 1 0 0 1-1.414-1.414L15.586 13H5a1 1 0 1 1 0-2h10.586l-3.293-3.293a1 1 0 0 1 0-1.414z"/></svg></span>',
        esc_attr__( 'Número de links internos apontados para este post. Consulte o texto "Yoast Columns" no menu de ajuda para obter mais informações.' )
    );
    $new['wpseo_linked'] = sprintf(
        '<span class="hoost-col-icon" title="%s"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path d="M11.707 5.293a1 1 0 0 1 0 1.414L8.414 10H19a1 1 0 1 1 0 2H8.414l3.293 3.293a1 1 0 0 1-1.414 1.414l-5-5a1 1 0 0 1 0-1.414l5-5a1 1 0 0 1 1.414 0z"/></svg></span>',
        esc_attr__( 'Número de links internos neste post. Consulte o texto "Yoast Columns" na aba do menu de ajuda para obter mais informações.' )
    );

    // Pontuação de SEO (semáforo colorido)
    $new['wpseo_score'] = sprintf(
        '<span class="hoost-col-icon yoast-score-icon" title="%s"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 500 500" aria-hidden="true" focusable="false"><circle cx="250" cy="250" r="200" fill="currentColor"/></svg></span>',
        esc_attr__( 'Pontuação de SEO' )
    );

    // Pontuação de legibilidade (ícone de pena/caneta)
    $new['wpseo_score_readability'] = sprintf(
        '<span class="hoost-col-icon yoast-read-icon" title="%s"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path d="M20.707 5.826l-3.535-3.533a.999.999 0 0 0-1.408 0l-.79.79 4.944 4.943.79-.79a.999.999 0 0 0 0-1.41zm-7.767 7.779l-1.793-1.793 5.337-5.337 1.792 1.791-5.336 5.339zm-1.506 1.123l-1.16 3.223 3.223-1.16.14-.141-2.062-2.063-.141.141zm7.557-9.403l-5.337 5.338-1.792-1.792 5.336-5.338 1.793 1.792zM3 17.25V21h3.75L17.81 9.94l-3.75-3.75L3 17.25zM5.92 19H5v-.92l9.06-9.06.92.92L5.92 19z"/></svg></span>',
        esc_attr__( 'Pontuação de legibilidade' )
    );

    return $new;
}

// ── Colunas ordenáveis ───────────────────────────────────────────────────────
function hoost_cpt_sortable_columns( $sortable ) {
    $sortable['wpseo_score']            = 'wpseo_score';
    $sortable['wpseo_score_readability'] = 'wpseo_score_readability';
    return $sortable;
}

// ── Conteúdo de cada coluna ──────────────────────────────────────────────────
function hoost_cpt_custom_column( $column, $post_id ) {
    switch ( $column ) {

        // Links apontando PARA este post
        case 'wpseo_links':
            $count = (int) get_post_meta( $post_id, '_yoast_wpseo_estimated-reading-time-minutes', true );
            // Yoast salva o número de links externos em _yoast_wpseo_focuskw_text_input
            // Links INTERNOS recebidos ficam em wpseo_incoming_internal_links (tabela de indexação)
            $incoming = hoost_get_incoming_links( $post_id );
            $tooltip  = esc_attr__( 'Número de links internos apontados para este post. Consulte o texto "Yoast Columns" no menu de ajuda para obter mais informações.' );
            printf(
                '<span class="hoost-link-count" title="%s" aria-label="%s">%d</span>',
                $tooltip,
                $tooltip,
                $incoming
            );
            break;

        // Links que SAEM deste post
        case 'wpseo_linked':
            $outgoing = hoost_get_outgoing_links( $post_id );
            $tooltip  = esc_attr__( 'Número de links internos neste post. Consulte o texto "Yoast Columns" na aba do menu de ajuda para obter mais informações.' );
            printf(
                '<span class="hoost-link-count" title="%s" aria-label="%s">%d</span>',
                $tooltip,
                $tooltip,
                $outgoing
            );
            break;

        // SEO Score (usa meta do Yoast: wpseo_linkdex / _yoast_wpseo_linkdex)
        case 'wpseo_score':
            $score_class = hoost_get_seo_score_class( $post_id );
            $label       = hoost_get_seo_score_label( $post_id );
            printf(
                '<span class="hoost-score-dot %s" title="%s" aria-label="%s"></span>',
                esc_attr( $score_class ),
                esc_attr( $label ),
                esc_attr( $label )
            );
            break;

        // Readability Score (usa meta do Yoast: _yoast_wpseo_content_score)
        case 'wpseo_score_readability':
            $score_class = hoost_get_readability_score_class( $post_id );
            $label       = hoost_get_readability_score_label( $post_id );
            printf(
                '<span class="hoost-score-dot %s" title="%s" aria-label="%s"></span>',
                esc_attr( $score_class ),
                esc_attr( $label ),
                esc_attr( $label )
            );
            break;
    }
}

// ── Helpers: pegar scores Yoast ──────────────────────────────────────────────

/**
 * Retorna a classe CSS do dot de SEO com base no meta do Yoast.
 * Yoast salva o score como inteiro 0-100 em _yoast_wpseo_linkdex.
 * Valores: 0 = sem keyword / não indexado; 1-40 = ruim; 41-70 = ok; 71-100 = bom.
 */
function hoost_get_seo_score_class( $post_id ) {
    $robots  = get_post_meta( $post_id, '_yoast_wpseo_meta-robots-noindex', true );
    if ( $robots === '1' ) return 'hoost-dot-na'; // Post não indexado — ponto cinza

    $keyword = get_post_meta( $post_id, '_yoast_wpseo_focuskw', true );
    if ( empty( $keyword ) ) return 'hoost-dot-na'; // Sem keyphrase — cinza

    $score = (int) get_post_meta( $post_id, '_yoast_wpseo_linkdex', true );

    if ( $score === 0 )  return 'hoost-dot-na';
    if ( $score < 41 )  return 'hoost-dot-bad';
    if ( $score < 71 )  return 'hoost-dot-ok';
    return 'hoost-dot-good';
}

function hoost_get_seo_score_label( $post_id ) {
    $robots  = get_post_meta( $post_id, '_yoast_wpseo_meta-robots-noindex', true );
    if ( $robots === '1' ) return __( 'SEO: Post não indexado', 'hoost' );

    $keyword = get_post_meta( $post_id, '_yoast_wpseo_focuskw', true );
    if ( empty( $keyword ) ) return __( 'SEO: No Focus Keyphrase', 'hoost' );

    $score = (int) get_post_meta( $post_id, '_yoast_wpseo_linkdex', true );

    if ( $score === 0 )  return __( 'SEO: No Focus Keyphrase', 'hoost' );
    if ( $score < 41 )  return __( 'SEO: Precisa melhorar', 'hoost' );
    if ( $score < 71 )  return __( 'SEO: OK', 'hoost' );
    return __( 'SEO: Bom', 'hoost' );
}

/**
 * Yoast salva o content score em _yoast_wpseo_content_score (0-100).
 */
function hoost_get_readability_score_class( $post_id ) {
    $score = (int) get_post_meta( $post_id, '_yoast_wpseo_content_score', true );

    if ( $score === 0 ) return 'hoost-dot-na';
    if ( $score < 41 )  return 'hoost-dot-bad';
    if ( $score < 71 )  return 'hoost-dot-ok';
    return 'hoost-dot-good';
}

function hoost_get_readability_score_label( $post_id ) {
    $score = (int) get_post_meta( $post_id, '_yoast_wpseo_content_score', true );

    if ( $score === 0 ) return __( 'Legibilidade: Não analisado', 'hoost' );
    if ( $score < 41 )  return __( 'Legibilidade: Precisa melhorar', 'hoost' );
    if ( $score < 71 )  return __( 'Legibilidade: OK', 'hoost' );
    return __( 'Legibilidade: Bom', 'hoost' );
}

// ── Helpers: contagem de links ───────────────────────────────────────────────

/**
 * Links internos que apontam para este post (incoming).
 * O Yoast Premium armazena isso na tabela wpseo_links com type='internal'.
 * Na versão gratuita pode ser 0. Fallback: contagem via postmeta se disponível.
 */
function hoost_get_incoming_links( $post_id ) {
    global $wpdb;
    $table = $wpdb->prefix . 'yoast_seo_links';
    if ( $wpdb->get_var( "SHOW TABLES LIKE '$table'" ) === $table ) {
        $count = (int) $wpdb->get_var(
            $wpdb->prepare(
                "SELECT COUNT(*) FROM {$table} WHERE target_post_id = %d AND type = 'internal'",
                $post_id
            )
        );
        return $count;
    }
    // Fallback: meta salvo pelo Yoast Free
    return (int) get_post_meta( $post_id, '_yoast_wpseo_incoming_internal_links', true );
}

/**
 * Links internos que SAEM deste post (outgoing).
 */
function hoost_get_outgoing_links( $post_id ) {
    global $wpdb;
    $table = $wpdb->prefix . 'yoast_seo_links';
    if ( $wpdb->get_var( "SHOW TABLES LIKE '$table'" ) === $table ) {
        $count = (int) $wpdb->get_var(
            $wpdb->prepare(
                "SELECT COUNT(*) FROM {$table} WHERE post_id = %d AND type = 'internal'",
                $post_id
            )
        );
        return $count;
    }
    return (int) get_post_meta( $post_id, '_yoast_wpseo_internal_link_count', true );
}

// ── Filtros (dropdowns acima da lista) ───────────────────────────────────────
function hoost_render_filter_dropdowns() {
    // Selects de SEO/legibilidade ocultados do tablenav.
    // O JS cuida da barra de filtros customizada (apenas data + categoria).
}

// ── Aplicar filtros na query ─────────────────────────────────────────────────
function hoost_apply_filter_to_query( $query ) {
    if ( ! is_admin() || ! $query->is_main_query() ) return;

    $screen = get_current_screen();
    if ( ! $screen || ! in_array( $screen->post_type, [ 'noticias', 'blog' ], true ) ) return;

    $seo_filter  = isset( $_GET['hoost_seo_score'] )  ? sanitize_text_field( $_GET['hoost_seo_score'] )  : '';
    $read_filter = isset( $_GET['hoost_read_score'] ) ? sanitize_text_field( $_GET['hoost_read_score'] ) : '';

    $meta_query = $query->get( 'meta_query' ) ?: [];

    // Filtro de SEO
    if ( ! empty( $seo_filter ) && $seo_filter !== 'all' ) {
        switch ( $seo_filter ) {
            case 'na':
                $meta_query[] = [
                    'key'   => '_yoast_wpseo_meta-robots-noindex',
                    'value' => '1',
                ];
                break;
            case 'nokey':
                $meta_query[] = [
                    'relation' => 'OR',
                    [ 'key' => '_yoast_wpseo_focuskw', 'compare' => 'NOT EXISTS' ],
                    [ 'key' => '_yoast_wpseo_focuskw', 'value' => '', 'compare' => '=' ],
                ];
                break;
            case 'bad':
                $meta_query[] = [ 'key' => '_yoast_wpseo_linkdex', 'value' => [ 1, 40 ], 'type' => 'NUMERIC', 'compare' => 'BETWEEN' ];
                break;
            case 'ok':
                $meta_query[] = [ 'key' => '_yoast_wpseo_linkdex', 'value' => [ 41, 70 ], 'type' => 'NUMERIC', 'compare' => 'BETWEEN' ];
                break;
            case 'good':
                $meta_query[] = [ 'key' => '_yoast_wpseo_linkdex', 'value' => 71, 'type' => 'NUMERIC', 'compare' => '>=' ];
                break;
        }
    }

    // Filtro de legibilidade
    if ( ! empty( $read_filter ) && $read_filter !== 'all' ) {
        switch ( $read_filter ) {
            case 'bad':
                $meta_query[] = [ 'key' => '_yoast_wpseo_content_score', 'value' => [ 1, 40 ], 'type' => 'NUMERIC', 'compare' => 'BETWEEN' ];
                break;
            case 'ok':
                $meta_query[] = [ 'key' => '_yoast_wpseo_content_score', 'value' => [ 41, 70 ], 'type' => 'NUMERIC', 'compare' => 'BETWEEN' ];
                break;
            case 'good':
                $meta_query[] = [ 'key' => '_yoast_wpseo_content_score', 'value' => 71, 'type' => 'NUMERIC', 'compare' => '>=' ];
                break;
        }
    }

    if ( ! empty( $meta_query ) ) {
        $query->set( 'meta_query', $meta_query );
    }
}
