<?php
/**
 * Class HOOST_Admin_Pages
 * 
 * Gerencia todas as páginas administrativas customizadas do plugin.
 * Cada página tem seu próprio arquivo de template.
 * 
 * @package Panel_Administrativo_Danilo_Ramos
 * @version 3.2
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class HOOST_Admin_Pages {

    /**
     * Diretório raiz do plugin
     * @var string
     */
    private $plugin_dir;

    /**
     * URL raiz do plugin
     * @var string
     */
    private $plugin_url;

    /**
     * Página atual sendo visualizada
     * @var string
     */
    private $current_page;

    /**
     * Constructor
     *
     * @param string $plugin_dir Caminho do plugin
     * @param string $plugin_url URL do plugin
     */
    public function __construct( $plugin_dir, $plugin_url ) {
        $this->plugin_dir = $plugin_dir;
        $this->plugin_url = $plugin_url;
        $this->current_page = isset( $_GET['page'] ) ? sanitize_text_field( $_GET['page'] ) : '';
        
        $this->init();
    }

    /**
     * Inicializar hooks
     */
    private function init() {
        // Carregar CSS específicos das páginas
        add_action( 'admin_enqueue_scripts', [ $this, 'enqueue_page_assets' ] );
    }

    /**
     * Enfileirar CSS específicos das páginas
     */
    public function enqueue_page_assets() {
        // Detectar página atual
        $page = isset( $_GET['page'] ) ? sanitize_text_field( $_GET['page'] ) : '';
        
        if ( empty( $page ) ) {
            return;
        }

        // CSS da página (se existir)
        $css_file = $this->plugin_dir . "assets/css/pages/{$page}.css";
        if ( file_exists( $css_file ) ) {
            wp_enqueue_style(
                "hoost-page-{$page}",
                $this->plugin_url . "assets/css/pages/{$page}.css",
                [ 'hoost-admin-style' ],
                HOOST_PLUGIN_VERSION
            );
        }

        // JS da página (se existir)
        $js_file = $this->plugin_dir . "assets/js/pages/{$page}.js";
        if ( file_exists( $js_file ) ) {
            wp_enqueue_script(
                "hoost-page-{$page}",
                $this->plugin_url . "assets/js/pages/{$page}.js",
                [ 'hoost-admin-script' ],
                HOOST_PLUGIN_VERSION,
                [ 'in_footer' => true, 'strategy' => 'defer' ]
            );
        }

        // Enfileirar CSS/JS para telas de listagem/edição de post_type (ex: edit.php?post_type=noticias)
        if ( function_exists( 'get_current_screen' ) ) {
            $screen = get_current_screen();
            if ( $screen && ! empty( $screen->post_type ) ) {
                $pt = sanitize_text_field( $screen->post_type );

                $css_pt = $this->plugin_dir . "assets/css/pages/edit-{$pt}.css";
                if ( file_exists( $css_pt ) ) {
                    wp_enqueue_style(
                        "hoost-edit-{$pt}",
                        $this->plugin_url . "assets/css/pages/edit-{$pt}.css",
                        [ 'hoost-admin-style' ],
                        HOOST_PLUGIN_VERSION
                    );
                }

                $js_pt = $this->plugin_dir . "assets/js/pages/edit-{$pt}.js";
                if ( file_exists( $js_pt ) ) {
                    wp_enqueue_script(
                        "hoost-edit-{$pt}",
                        $this->plugin_url . "assets/js/pages/edit-{$pt}.js",
                        [ 'hoost-admin-script' ],
                        HOOST_PLUGIN_VERSION,
                        [ 'in_footer' => true, 'strategy' => 'defer' ]
                    );
                }
            }
        }
    }

    /**
     * Renderizar página administrativa
     *
     * @param string $page_slug Slug da página
     * @return void
     */
    public function render_page( $page_slug ) {
        // Verificar permissão
        if ( ! current_user_can( 'manage_options' ) ) {
            wp_die( esc_html__( 'Acesso negado.', 'hoost' ) );
        }

        // Arquivo template da página
        $template_file = $this->plugin_dir . "includes/pages/{$page_slug}.php";
        
        if ( ! file_exists( $template_file ) ) {
            wp_die( 
                esc_html__( 'Página não encontrada.', 'hoost' ) . ' ' .
                esc_html( "({$page_slug})" )
            );
        }

        // Carregar template
        include $template_file;
    }

    /**
     * Obter URL de uma página
     *
     * @param string $page_slug Slug da página
     * @return string URL da página
     */
    public function get_page_url( $page_slug ) {
        return admin_url( "admin.php?page={$page_slug}" );
    }

    /**
     * Verificar se está na página específica
     *
     * @param string $page_slug Slug da página
     * @return bool
     */
    public function is_current_page( $page_slug ) {
        return $this->current_page === $page_slug;
    }

    /**
     * Adicionar classe "active" no link se for página atual
     *
     * @param string $page_slug Slug da página
     * @param string $class_name Nome da classe (padrão: "active")
     * @return string Classe ou vazio
     */
    public function get_active_class( $page_slug, $class_name = 'active' ) {
        return $this->is_current_page( $page_slug ) ? $class_name : '';
    }

}
